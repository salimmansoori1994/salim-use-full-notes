
$(document).ready(function(){
	
	//alert(base_url);
$(document).on("input", ".numeric", function() {
   this.value = this.value.replace(/[^0-9 .]/g, '');
});


	
	$("#submit_login").click(function(event){
		  event.preventDefault();
		 
		 var username = $('#Username').val();
		 var password_set = $('#Password').val();
		 var height = $( window ).height();
		 
		 if(!username){
			    new_alert("#massage","danger","Please enter username");
				return false ;
		 }
		 	 if(!password_set){
			    new_alert("#massage","danger","Please enter password.");
				return false ;
		 } 
		 
		// alert(username);
		   
		 //  alert('s');
				$.ajax({  
				type:"POST",
				url:base_url+"Admin/Loginform",   
				data:{password_set:password_set,username:username},
				success:function(data) {
						if($.trim(data) != "error"){
						$("body").html(""); 
						$("body").html("<div style='margin: 20%;' align='center'><img src='"+base_url+"assets/img/ajax-loaders/loader.gif' style='width: 100px; height:100px;' /> </div>");
						} 
						//return false ;
						if($.trim(data) == "admin"){
						var surl = base_url+'Admin/Admin_dashboard'; 
						window.setTimeout(function() { window.location = surl; }, 3000);
						}else if($.trim(data) == "operates"){
						var surl = base_url+'operates'; 
						window.setTimeout(function() { window.location = surl; }, 3000);
						}else if($.trim(data) == "error"){
							new_alert("#massage","danger","Invalid Username & Password");
						}
				}
				});  
				event.preventDefault();
		});		
		
		
		
		
			$("#general_form_submit").submit(function(event){
			var url = $(this).attr('action');
			$("#submit").hide();
			$.ajax({
				type:"POST",
				url:base_url+url, 
				data: new FormData(this),
				contentType: false,
				cache: false,
				processData: false,
				dataType: "json",  
				success:function(data) {
					if(data.mass_id){
						var mass=data.mass_id;
					}else{
						var mass= "#msg";
					} 
					
					if(data.status){ 		
					
				

						new_alert(mass,'success',data.mass);
						if(data.url == "reload"){
							setTimeout(function(){ reload(); }, 2000);
						}else if(data.url == "otp"){
							$("#otp_box").show();
							$("#school_registration_box").remove();
							$("#user_id").val(data.user_id);
						}else if(data.url != ""){
							setTimeout(function(){ window.location = data.url; }, 2000);
						}
						}else{				 
						new_alert(mass,'danger',data.mass);
							$("#submit").show();
						}
				}
				});  
				event.preventDefault();
		});
		 


	});



/*

	 <div class='col-12 cat_data_action'  style='    width: 100%;' onclick='active_inactive_user(<?php echo $row->product_vendors_items_id ; ?>,"active","Are you sure active the product?","product_vendors_items","product_vendors_items_id","product_status","product has been inactived.");' align='center'>
			  <i class="fa fa-eye-slash" aria-hidden="true"></i>
						</div>	

*/
 



function active_inactive_user(user_id,status_user,text,table,update_by_feild,update_feild,responce_text){
		
		
		bootbox.confirm(text, function(result){
    	if(result){
					//alert(ticket_number);
	$.ajax({
		type:"POST",
		url:base_url+'Comman_data/active_inactive_user', 
		data: {user_id:user_id,status_user:status_user,text:text,table:table,update_by_feild:update_by_feild,update_feild:update_feild,responce_text:responce_text}, 
		dataType:'json',
		success:function (data){
					if(data.status){
						new_alert("#mass",'success',data.mass);
								setTimeout(function(){ location.reload(); },1000);
					}else{
						new_alert("#mass",'danger',data.mass);
					}
					}
	});	
	event.preventDefault();	
				}
});
event.preventDefault();
		}






function new_alert(set_id,type,msg){
	$(set_id).html('<div class="alert alert-'+type+'"> <button type="button" class="close" data-dismiss="alert">&times;</button>'+msg+'</div>');
	}


	function reload(){
		window.close();
		location.reload();
		}