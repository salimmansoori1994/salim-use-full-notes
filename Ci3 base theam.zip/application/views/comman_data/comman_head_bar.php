
   <div class="navigation-trigger hidden-xl-up" data-sa-action="aside-open" data-sa-target=".sidebar">
                    <i class="zmdi zmdi-menu"></i>
                </div>

                <div class="logo hidden-sm-down">
                    <h1><a href="index-2.html"><?php echo PROJECTNAME ; ?></a></h1>
                </div>

                <form class="search">
                    <div class="search__inner">
                        <input type="text" class="search__text" placeholder="Search for people, files, documents...">
                        <i class="zmdi zmdi-search search__helper" data-sa-action="search-close"></i>
                    </div>
                </form>

                <ul class="top-nav">
                <li class="dropdown hidden-xs-down">
                        <a href="#" data-toggle="dropdown" aria-expanded="false"><i class="zmdi zmdi-more-vert"></i></a>

                        <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(50px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                            <a href="#" class="dropdown-item" data-sa-action="fullscreen">Fullscreen</a>
                            <!-- <a href="#" class="dropdown-item">Clear Local Storage</a> -->
                            <a href="<?php echo base_url('Admin/Admin_dashboard/logout'); ?>" class="dropdown-item">Logout</a>
                        </div>
                    </li>
                </ul>
             

                <div class="clock hidden-md-down">
                    <div class="time">
                        <span class="time__hours"></span>
                        <span class="time__min"></span>
                        <span class="time__sec"></span>
                    </div>
                </div>