        <script src="<?php echo base_url('assets/vendors/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/popper.js/dist/umd/popper.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js'); ?>"></script>

        <script src="<?php echo base_url('assets/vendors/bower_components/salvattore/dist/salvattore.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/flot/jquery.flot.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/flot/jquery.flot.resize.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/flot.curvedlines/curvedLines.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/jqvmap/dist/jquery.vmap.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/jqvmap/dist/maps/jquery.vmap.world.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/peity/jquery.peity.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/moment/min/moment.min.js'); ?>"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
  <script src="<?php echo base_url('assets/vendors/bower_components/select2/dist/js/select2.full.min.js'); ?>"></script>

        <!-- App functions and actions -->
        <script src="<?php echo base_url('assets/js/app.min.js'); ?>"></script>  
		
	
		<script src="<?php echo base_url('assets/sam_js.js'); ?>"></script>
		
		
		       <!-- Vendors: Data tables -->
			   <?php 
			   if(isset($datatable)){
			   ?>
        <script src="<?php echo base_url('assets/vendors/bower_components/datatables.net/js/jquery.dataTables.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/jszip/dist/jszip.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js'); ?>"></script>
		
			   <?php  } ?>
		
<script>
var base_url= '<?php echo  base_url(); ?>';
</script> 
