<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title> <?php echo  PROJECTNAME ;  ?> </title>
<!-- Vendor styles -->
<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/select2/dist/css/select2.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/animate.css/animate.min.css'); ?>">
<!-- App styles -->


<link rel="stylesheet" href="<?php echo base_url('assets/sam_css.css'); ?>">


<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/animate.css/animate.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/vendors/bower_components/jquery.scrollbar/jquery.scrollbar.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/app.min.css'); ?>">