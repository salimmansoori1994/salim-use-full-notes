<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

 function details($select_values,$table,$where=""){

			$ci=& get_instance();

			$ci->load->database();

			if($select_values!="")	{	$ci->db->select($select_values);}		

			if($where!="")	{				$ci->db->where($where,TRUE);}



			$query=$ci->db->get($table); //echo $str = $ci->db->last_query(); die;

			if($query->num_rows()){

			return $query->result();

			}else{

			return false; 

			}
    }


    if(! function_exists('generate_wild_where'))
{
    function generate_wild_where($name,$id)
    {
        return " ".$name." ='".$id."' OR ".$name." like '".$id.",%' OR ".$name." like '%,".$id."' OR ".$name." like '%,".$id.",%'";
    }
}

    
	

?>