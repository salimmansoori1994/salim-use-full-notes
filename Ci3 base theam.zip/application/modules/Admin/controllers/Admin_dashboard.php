<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends MX_Controller {


			  function __construct() {
			  parent::__construct();
			  if(!$this->session->userdata('user_key') && $this->session->userdata('user_type') != "admin" ){
					  redirect(base_url('Admin'), 'refresh');
		
	       }
			  }




				public function index()
				{
				$data['view_data']['bredcarm_head']='Dashboard';
				$data['view_data']['page']='Dashboard';
				$data['view_page']='admin_dashboard';
				$this->load->view('comman_data/view_template',$data);
				}

				public function logout()
				{  
					$this->session->unset_userdata('user_key');
					$this->session->unset_userdata('user_type');
					redirect(base_url(), 'refresh');
				}


}

?>