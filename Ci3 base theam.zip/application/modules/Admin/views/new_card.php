<div class='col-sm-12'>
<div class="row">
<div class='col-sm-8'>


<!-- table -->
     <div class="card">
                    <div class="card-body">
					<?php if(false){ ?>
                        <h4 class="card-title">All Course</h4>
     

                        <div class="table-responsive">
                            <table id="data-table" class="table">
                                <thead>
                                    <tr>
                                        <th>Sno.</th>
                                        <th>Name</th>
                                        <th>Add date</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
								<?php 
								$i=1;
									foreach($allCourse as $allCourse_row){
										echo '  <tr>
												<th>'.$i.'</th>
												<th>'.$allCourse_row->course_name.'</th>
												<th>'.$allCourse_row->course_status.'</th>
                                        
												</tr>';
									}
								?>
                                  
								  </tbody>	
						</table>
					</div>
					<?php }else{
						echo '<center><h3>No Course Avialable.</h3></center>';
					} ?>
			</div>
		</div>	
<!-- end table -->


</div>
<div class='col-sm-4'>
<div id='massage'></div>
<div class='card'>
<div class='card-body'>
<h4 class="card-title">Add new course</h4>
                              
                                <div class="col-sm-12">
								
								<form id='general_form_submit' action='Admin/Course/add_new' method='post'>
                                    <div class="form-group">
									      <label>Course name </label> <span class='required'>*</span>
                                        <input type="text" class="form-control" placeholder="Enter the name" name='course_name' required>
                                        <i class="form-group__bar"></i>
                                    </div>
									
								<button type='submit' id='submit'  class="btn btn-success active" >Create</button>
									</form>
                                </div>
                           
                            </div>
                            </div>
</div>
</div>

</div>