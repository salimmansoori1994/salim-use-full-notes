<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-21 13:24:17 --> Config Class Initialized
INFO - 2021-05-21 13:24:17 --> Hooks Class Initialized
DEBUG - 2021-05-21 13:24:18 --> UTF-8 Support Enabled
INFO - 2021-05-21 13:24:18 --> Utf8 Class Initialized
INFO - 2021-05-21 13:24:18 --> URI Class Initialized
DEBUG - 2021-05-21 13:24:18 --> No URI present. Default controller set.
INFO - 2021-05-21 13:24:18 --> Router Class Initialized
INFO - 2021-05-21 13:24:18 --> Output Class Initialized
INFO - 2021-05-21 13:24:18 --> Security Class Initialized
DEBUG - 2021-05-21 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 13:24:18 --> Input Class Initialized
INFO - 2021-05-21 13:24:18 --> Language Class Initialized
INFO - 2021-05-21 13:24:18 --> Language Class Initialized
INFO - 2021-05-21 13:24:18 --> Config Class Initialized
INFO - 2021-05-21 13:24:18 --> Loader Class Initialized
INFO - 2021-05-21 13:24:18 --> Helper loaded: url_helper
INFO - 2021-05-21 13:24:18 --> Helper loaded: file_helper
INFO - 2021-05-21 13:24:18 --> Helper loaded: common_helper
INFO - 2021-05-21 13:24:19 --> Database Driver Class Initialized
INFO - 2021-05-21 13:24:19 --> Email Class Initialized
INFO - 2021-05-21 13:24:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-05-21 13:24:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-21 13:24:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-21 13:24:19 --> Encryption Class Initialized
INFO - 2021-05-21 13:24:19 --> Model Class Initialized
INFO - 2021-05-21 13:24:19 --> Helper loaded: inflector_helper
INFO - 2021-05-21 13:24:19 --> Model Class Initialized
INFO - 2021-05-21 13:24:19 --> Model Class Initialized
INFO - 2021-05-21 13:24:19 --> Controller Class Initialized
DEBUG - 2021-05-21 13:24:19 --> Admin MX_Controller Initialized
DEBUG - 2021-05-21 13:24:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-05-21 13:24:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-05-21 13:24:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-05-21 13:24:19 --> Final output sent to browser
DEBUG - 2021-05-21 13:24:19 --> Total execution time: 1.8741
INFO - 2021-05-21 13:24:30 --> Config Class Initialized
INFO - 2021-05-21 13:24:30 --> Hooks Class Initialized
DEBUG - 2021-05-21 13:24:30 --> UTF-8 Support Enabled
INFO - 2021-05-21 13:24:30 --> Utf8 Class Initialized
INFO - 2021-05-21 13:24:30 --> URI Class Initialized
INFO - 2021-05-21 13:24:30 --> Router Class Initialized
INFO - 2021-05-21 13:24:30 --> Output Class Initialized
INFO - 2021-05-21 13:24:30 --> Security Class Initialized
DEBUG - 2021-05-21 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 13:24:30 --> Input Class Initialized
INFO - 2021-05-21 13:24:30 --> Language Class Initialized
INFO - 2021-05-21 13:24:30 --> Language Class Initialized
INFO - 2021-05-21 13:24:30 --> Config Class Initialized
INFO - 2021-05-21 13:24:30 --> Loader Class Initialized
INFO - 2021-05-21 13:24:30 --> Helper loaded: url_helper
INFO - 2021-05-21 13:24:30 --> Helper loaded: file_helper
INFO - 2021-05-21 13:24:30 --> Helper loaded: common_helper
INFO - 2021-05-21 13:24:30 --> Database Driver Class Initialized
INFO - 2021-05-21 13:24:30 --> Email Class Initialized
INFO - 2021-05-21 13:24:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-05-21 13:24:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-21 13:24:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-21 13:24:30 --> Encryption Class Initialized
INFO - 2021-05-21 13:24:30 --> Model Class Initialized
INFO - 2021-05-21 13:24:30 --> Helper loaded: inflector_helper
INFO - 2021-05-21 13:24:30 --> Model Class Initialized
INFO - 2021-05-21 13:24:30 --> Model Class Initialized
INFO - 2021-05-21 13:24:30 --> Controller Class Initialized
DEBUG - 2021-05-21 13:24:30 --> Admin MX_Controller Initialized
INFO - 2021-05-21 13:24:30 --> Final output sent to browser
DEBUG - 2021-05-21 13:24:30 --> Total execution time: 0.1181
INFO - 2021-05-21 13:24:33 --> Config Class Initialized
INFO - 2021-05-21 13:24:33 --> Hooks Class Initialized
DEBUG - 2021-05-21 13:24:33 --> UTF-8 Support Enabled
INFO - 2021-05-21 13:24:33 --> Utf8 Class Initialized
INFO - 2021-05-21 13:24:33 --> URI Class Initialized
INFO - 2021-05-21 13:24:33 --> Router Class Initialized
INFO - 2021-05-21 13:24:33 --> Output Class Initialized
INFO - 2021-05-21 13:24:33 --> Security Class Initialized
DEBUG - 2021-05-21 13:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 13:24:33 --> Input Class Initialized
INFO - 2021-05-21 13:24:33 --> Language Class Initialized
INFO - 2021-05-21 13:24:33 --> Language Class Initialized
INFO - 2021-05-21 13:24:33 --> Config Class Initialized
INFO - 2021-05-21 13:24:33 --> Loader Class Initialized
INFO - 2021-05-21 13:24:33 --> Helper loaded: url_helper
INFO - 2021-05-21 13:24:33 --> Helper loaded: file_helper
INFO - 2021-05-21 13:24:33 --> Helper loaded: common_helper
INFO - 2021-05-21 13:24:33 --> Database Driver Class Initialized
INFO - 2021-05-21 13:24:33 --> Email Class Initialized
INFO - 2021-05-21 13:24:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-05-21 13:24:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-21 13:24:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-21 13:24:33 --> Encryption Class Initialized
INFO - 2021-05-21 13:24:33 --> Model Class Initialized
INFO - 2021-05-21 13:24:33 --> Helper loaded: inflector_helper
INFO - 2021-05-21 13:24:33 --> Model Class Initialized
INFO - 2021-05-21 13:24:33 --> Model Class Initialized
INFO - 2021-05-21 13:24:33 --> Controller Class Initialized
DEBUG - 2021-05-21 13:24:33 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-05-21 13:24:33 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-05-21 13:24:33 --> Final output sent to browser
DEBUG - 2021-05-21 13:24:33 --> Total execution time: 0.2170
INFO - 2021-05-21 13:24:42 --> Config Class Initialized
INFO - 2021-05-21 13:24:42 --> Hooks Class Initialized
DEBUG - 2021-05-21 13:24:42 --> UTF-8 Support Enabled
INFO - 2021-05-21 13:24:42 --> Utf8 Class Initialized
INFO - 2021-05-21 13:24:42 --> URI Class Initialized
INFO - 2021-05-21 13:24:42 --> Router Class Initialized
INFO - 2021-05-21 13:24:42 --> Output Class Initialized
INFO - 2021-05-21 13:24:42 --> Security Class Initialized
DEBUG - 2021-05-21 13:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 13:24:42 --> Input Class Initialized
INFO - 2021-05-21 13:24:42 --> Language Class Initialized
INFO - 2021-05-21 13:24:42 --> Language Class Initialized
INFO - 2021-05-21 13:24:42 --> Config Class Initialized
INFO - 2021-05-21 13:24:42 --> Loader Class Initialized
INFO - 2021-05-21 13:24:42 --> Helper loaded: url_helper
INFO - 2021-05-21 13:24:42 --> Helper loaded: file_helper
INFO - 2021-05-21 13:24:42 --> Helper loaded: common_helper
INFO - 2021-05-21 13:24:42 --> Database Driver Class Initialized
INFO - 2021-05-21 13:24:42 --> Email Class Initialized
INFO - 2021-05-21 13:24:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-05-21 13:24:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-21 13:24:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-21 13:24:42 --> Encryption Class Initialized
INFO - 2021-05-21 13:24:42 --> Model Class Initialized
INFO - 2021-05-21 13:24:42 --> Helper loaded: inflector_helper
INFO - 2021-05-21 13:24:42 --> Model Class Initialized
INFO - 2021-05-21 13:24:42 --> Model Class Initialized
INFO - 2021-05-21 13:24:42 --> Controller Class Initialized
DEBUG - 2021-05-21 13:24:42 --> Admin_dashboard MX_Controller Initialized
INFO - 2021-05-21 13:24:43 --> Config Class Initialized
INFO - 2021-05-21 13:24:43 --> Hooks Class Initialized
DEBUG - 2021-05-21 13:24:43 --> UTF-8 Support Enabled
INFO - 2021-05-21 13:24:43 --> Utf8 Class Initialized
INFO - 2021-05-21 13:24:43 --> URI Class Initialized
DEBUG - 2021-05-21 13:24:43 --> No URI present. Default controller set.
INFO - 2021-05-21 13:24:43 --> Router Class Initialized
INFO - 2021-05-21 13:24:43 --> Output Class Initialized
INFO - 2021-05-21 13:24:43 --> Security Class Initialized
DEBUG - 2021-05-21 13:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 13:24:43 --> Input Class Initialized
INFO - 2021-05-21 13:24:43 --> Language Class Initialized
INFO - 2021-05-21 13:24:43 --> Language Class Initialized
INFO - 2021-05-21 13:24:43 --> Config Class Initialized
INFO - 2021-05-21 13:24:43 --> Loader Class Initialized
INFO - 2021-05-21 13:24:43 --> Helper loaded: url_helper
INFO - 2021-05-21 13:24:43 --> Helper loaded: file_helper
INFO - 2021-05-21 13:24:43 --> Helper loaded: common_helper
INFO - 2021-05-21 13:24:43 --> Database Driver Class Initialized
INFO - 2021-05-21 13:24:43 --> Email Class Initialized
INFO - 2021-05-21 13:24:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-05-21 13:24:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-21 13:24:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-21 13:24:43 --> Encryption Class Initialized
INFO - 2021-05-21 13:24:43 --> Model Class Initialized
INFO - 2021-05-21 13:24:43 --> Helper loaded: inflector_helper
INFO - 2021-05-21 13:24:43 --> Model Class Initialized
INFO - 2021-05-21 13:24:43 --> Model Class Initialized
INFO - 2021-05-21 13:24:43 --> Controller Class Initialized
DEBUG - 2021-05-21 13:24:43 --> Admin MX_Controller Initialized
DEBUG - 2021-05-21 13:24:43 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-05-21 13:24:43 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-05-21 13:24:43 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-05-21 13:24:43 --> Final output sent to browser
DEBUG - 2021-05-21 13:24:43 --> Total execution time: 0.0938
