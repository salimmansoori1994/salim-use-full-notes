<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 15:24:55 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 15:24:55 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 15:24:55 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Router Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Output Class Initialized
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Security Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:55 --> Input Class Initialized
INFO - 2020-11-07 15:24:55 --> Language Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:55 --> Config Class Initialized
INFO - 2020-11-07 15:24:55 --> Hooks Class Initialized
ERROR - 2020-11-07 15:24:55 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:55 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:55 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:56 --> Config Class Initialized
INFO - 2020-11-07 15:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:56 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:56 --> URI Class Initialized
INFO - 2020-11-07 15:24:56 --> Router Class Initialized
INFO - 2020-11-07 15:24:56 --> Output Class Initialized
INFO - 2020-11-07 15:24:56 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:56 --> Input Class Initialized
INFO - 2020-11-07 15:24:56 --> Language Class Initialized
ERROR - 2020-11-07 15:24:56 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:57 --> Config Class Initialized
INFO - 2020-11-07 15:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:57 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:57 --> URI Class Initialized
INFO - 2020-11-07 15:24:57 --> Router Class Initialized
INFO - 2020-11-07 15:24:57 --> Output Class Initialized
INFO - 2020-11-07 15:24:57 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:57 --> Input Class Initialized
INFO - 2020-11-07 15:24:57 --> Language Class Initialized
ERROR - 2020-11-07 15:24:57 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:57 --> Config Class Initialized
INFO - 2020-11-07 15:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:57 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:57 --> URI Class Initialized
INFO - 2020-11-07 15:24:57 --> Router Class Initialized
INFO - 2020-11-07 15:24:57 --> Output Class Initialized
INFO - 2020-11-07 15:24:57 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:57 --> Input Class Initialized
INFO - 2020-11-07 15:24:57 --> Language Class Initialized
ERROR - 2020-11-07 15:24:57 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:57 --> Config Class Initialized
INFO - 2020-11-07 15:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:57 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:57 --> URI Class Initialized
INFO - 2020-11-07 15:24:57 --> Router Class Initialized
INFO - 2020-11-07 15:24:57 --> Output Class Initialized
INFO - 2020-11-07 15:24:57 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:57 --> Input Class Initialized
INFO - 2020-11-07 15:24:57 --> Language Class Initialized
ERROR - 2020-11-07 15:24:57 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:57 --> Config Class Initialized
INFO - 2020-11-07 15:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:57 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:57 --> URI Class Initialized
INFO - 2020-11-07 15:24:57 --> Router Class Initialized
INFO - 2020-11-07 15:24:58 --> Output Class Initialized
INFO - 2020-11-07 15:24:58 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:58 --> Input Class Initialized
INFO - 2020-11-07 15:24:58 --> Language Class Initialized
ERROR - 2020-11-07 15:24:58 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:58 --> Config Class Initialized
INFO - 2020-11-07 15:24:58 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:58 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:58 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:58 --> URI Class Initialized
INFO - 2020-11-07 15:24:58 --> Router Class Initialized
INFO - 2020-11-07 15:24:58 --> Output Class Initialized
INFO - 2020-11-07 15:24:58 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:58 --> Input Class Initialized
INFO - 2020-11-07 15:24:58 --> Language Class Initialized
ERROR - 2020-11-07 15:24:58 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:58 --> Config Class Initialized
INFO - 2020-11-07 15:24:58 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:58 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:58 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:58 --> URI Class Initialized
INFO - 2020-11-07 15:24:58 --> Router Class Initialized
INFO - 2020-11-07 15:24:58 --> Output Class Initialized
INFO - 2020-11-07 15:24:58 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:58 --> Input Class Initialized
INFO - 2020-11-07 15:24:58 --> Language Class Initialized
ERROR - 2020-11-07 15:24:58 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:24:58 --> Config Class Initialized
INFO - 2020-11-07 15:24:58 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:24:58 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:24:58 --> Utf8 Class Initialized
INFO - 2020-11-07 15:24:58 --> URI Class Initialized
INFO - 2020-11-07 15:24:58 --> Router Class Initialized
INFO - 2020-11-07 15:24:58 --> Output Class Initialized
INFO - 2020-11-07 15:24:59 --> Security Class Initialized
DEBUG - 2020-11-07 15:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:24:59 --> Input Class Initialized
INFO - 2020-11-07 15:24:59 --> Language Class Initialized
ERROR - 2020-11-07 15:24:59 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:16 --> Config Class Initialized
INFO - 2020-11-07 15:25:16 --> Hooks Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
DEBUG - 2020-11-07 15:25:16 --> UTF-8 Support Enabled
INFO - 2020-11-07 15:25:16 --> Utf8 Class Initialized
INFO - 2020-11-07 15:25:16 --> URI Class Initialized
INFO - 2020-11-07 15:25:16 --> Router Class Initialized
INFO - 2020-11-07 15:25:16 --> Output Class Initialized
INFO - 2020-11-07 15:25:16 --> Security Class Initialized
DEBUG - 2020-11-07 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:16 --> Input Class Initialized
INFO - 2020-11-07 15:25:16 --> Language Class Initialized
ERROR - 2020-11-07 15:25:16 --> 404 Page Not Found: /index
INFO - 2020-11-07 15:25:17 --> Security Class Initialized
DEBUG - 2020-11-07 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 15:25:17 --> Input Class Initialized
INFO - 2020-11-07 15:25:17 --> Language Class Initialized
ERROR - 2020-11-07 15:25:17 --> 404 Page Not Found: /index
