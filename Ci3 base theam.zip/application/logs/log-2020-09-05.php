<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-05 18:13:28 --> Config Class Initialized
INFO - 2020-09-05 18:13:28 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:13:28 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:13:28 --> Utf8 Class Initialized
INFO - 2020-09-05 18:13:29 --> URI Class Initialized
DEBUG - 2020-09-05 18:13:29 --> No URI present. Default controller set.
INFO - 2020-09-05 18:13:29 --> Router Class Initialized
INFO - 2020-09-05 18:13:29 --> Output Class Initialized
INFO - 2020-09-05 18:13:29 --> Security Class Initialized
DEBUG - 2020-09-05 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:13:29 --> Input Class Initialized
INFO - 2020-09-05 18:13:29 --> Language Class Initialized
INFO - 2020-09-05 18:13:29 --> Language Class Initialized
INFO - 2020-09-05 18:13:29 --> Config Class Initialized
INFO - 2020-09-05 18:13:29 --> Loader Class Initialized
INFO - 2020-09-05 18:13:29 --> Helper loaded: url_helper
INFO - 2020-09-05 18:13:29 --> Helper loaded: file_helper
INFO - 2020-09-05 18:13:29 --> Database Driver Class Initialized
INFO - 2020-09-05 18:13:29 --> Email Class Initialized
INFO - 2020-09-05 18:13:29 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:13:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:13:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:13:29 --> Encryption Class Initialized
INFO - 2020-09-05 18:13:29 --> Model Class Initialized
INFO - 2020-09-05 18:13:29 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:13:29 --> Model Class Initialized
INFO - 2020-09-05 18:13:29 --> Model Class Initialized
INFO - 2020-09-05 18:13:30 --> Controller Class Initialized
DEBUG - 2020-09-05 18:13:30 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 18:13:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 18:13:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 18:13:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 18:13:30 --> Final output sent to browser
DEBUG - 2020-09-05 18:13:30 --> Total execution time: 1.3557
INFO - 2020-09-05 18:17:16 --> Config Class Initialized
INFO - 2020-09-05 18:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:17:16 --> Utf8 Class Initialized
INFO - 2020-09-05 18:17:16 --> URI Class Initialized
DEBUG - 2020-09-05 18:17:16 --> No URI present. Default controller set.
INFO - 2020-09-05 18:17:16 --> Router Class Initialized
INFO - 2020-09-05 18:17:16 --> Output Class Initialized
INFO - 2020-09-05 18:17:16 --> Security Class Initialized
DEBUG - 2020-09-05 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:17:16 --> Input Class Initialized
INFO - 2020-09-05 18:17:16 --> Language Class Initialized
INFO - 2020-09-05 18:17:16 --> Language Class Initialized
INFO - 2020-09-05 18:17:16 --> Config Class Initialized
INFO - 2020-09-05 18:17:16 --> Loader Class Initialized
INFO - 2020-09-05 18:17:16 --> Helper loaded: url_helper
INFO - 2020-09-05 18:17:16 --> Helper loaded: file_helper
INFO - 2020-09-05 18:17:16 --> Database Driver Class Initialized
INFO - 2020-09-05 18:17:16 --> Email Class Initialized
INFO - 2020-09-05 18:17:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:17:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:17:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:17:16 --> Encryption Class Initialized
INFO - 2020-09-05 18:17:16 --> Model Class Initialized
INFO - 2020-09-05 18:17:16 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:17:16 --> Model Class Initialized
INFO - 2020-09-05 18:17:16 --> Model Class Initialized
INFO - 2020-09-05 18:17:16 --> Controller Class Initialized
DEBUG - 2020-09-05 18:17:16 --> Admin MX_Controller Initialized
INFO - 2020-09-05 18:19:09 --> Config Class Initialized
INFO - 2020-09-05 18:19:09 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:19:09 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:19:09 --> Utf8 Class Initialized
INFO - 2020-09-05 18:19:09 --> URI Class Initialized
DEBUG - 2020-09-05 18:19:09 --> No URI present. Default controller set.
INFO - 2020-09-05 18:19:09 --> Router Class Initialized
INFO - 2020-09-05 18:19:09 --> Output Class Initialized
INFO - 2020-09-05 18:19:09 --> Security Class Initialized
DEBUG - 2020-09-05 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:19:09 --> Input Class Initialized
INFO - 2020-09-05 18:19:09 --> Language Class Initialized
INFO - 2020-09-05 18:19:09 --> Language Class Initialized
INFO - 2020-09-05 18:19:09 --> Config Class Initialized
INFO - 2020-09-05 18:19:09 --> Loader Class Initialized
INFO - 2020-09-05 18:19:09 --> Helper loaded: url_helper
INFO - 2020-09-05 18:19:09 --> Helper loaded: file_helper
INFO - 2020-09-05 18:19:09 --> Database Driver Class Initialized
INFO - 2020-09-05 18:19:09 --> Email Class Initialized
INFO - 2020-09-05 18:19:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:19:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:19:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:19:09 --> Encryption Class Initialized
INFO - 2020-09-05 18:19:09 --> Model Class Initialized
INFO - 2020-09-05 18:19:09 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:19:09 --> Model Class Initialized
INFO - 2020-09-05 18:19:09 --> Model Class Initialized
INFO - 2020-09-05 18:19:09 --> Controller Class Initialized
DEBUG - 2020-09-05 18:19:09 --> Admin MX_Controller Initialized
INFO - 2020-09-05 18:19:55 --> Config Class Initialized
INFO - 2020-09-05 18:19:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:19:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:19:55 --> Utf8 Class Initialized
INFO - 2020-09-05 18:19:55 --> URI Class Initialized
DEBUG - 2020-09-05 18:19:55 --> No URI present. Default controller set.
INFO - 2020-09-05 18:19:55 --> Router Class Initialized
INFO - 2020-09-05 18:19:55 --> Output Class Initialized
INFO - 2020-09-05 18:19:56 --> Security Class Initialized
DEBUG - 2020-09-05 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:19:56 --> Input Class Initialized
INFO - 2020-09-05 18:19:56 --> Language Class Initialized
INFO - 2020-09-05 18:19:56 --> Language Class Initialized
INFO - 2020-09-05 18:19:56 --> Config Class Initialized
INFO - 2020-09-05 18:19:56 --> Loader Class Initialized
INFO - 2020-09-05 18:19:56 --> Helper loaded: url_helper
INFO - 2020-09-05 18:19:56 --> Helper loaded: file_helper
INFO - 2020-09-05 18:19:56 --> Database Driver Class Initialized
INFO - 2020-09-05 18:19:56 --> Email Class Initialized
INFO - 2020-09-05 18:19:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:19:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:19:56 --> Encryption Class Initialized
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Controller Class Initialized
DEBUG - 2020-09-05 18:19:56 --> Admin MX_Controller Initialized
INFO - 2020-09-05 18:19:56 --> Config Class Initialized
INFO - 2020-09-05 18:19:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:19:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:19:56 --> Utf8 Class Initialized
INFO - 2020-09-05 18:19:56 --> URI Class Initialized
INFO - 2020-09-05 18:19:56 --> Router Class Initialized
INFO - 2020-09-05 18:19:56 --> Output Class Initialized
INFO - 2020-09-05 18:19:56 --> Security Class Initialized
DEBUG - 2020-09-05 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:19:56 --> Input Class Initialized
INFO - 2020-09-05 18:19:56 --> Language Class Initialized
INFO - 2020-09-05 18:19:56 --> Language Class Initialized
INFO - 2020-09-05 18:19:56 --> Config Class Initialized
INFO - 2020-09-05 18:19:56 --> Loader Class Initialized
INFO - 2020-09-05 18:19:56 --> Helper loaded: url_helper
INFO - 2020-09-05 18:19:56 --> Helper loaded: file_helper
INFO - 2020-09-05 18:19:56 --> Database Driver Class Initialized
INFO - 2020-09-05 18:19:56 --> Email Class Initialized
INFO - 2020-09-05 18:19:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:19:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:19:56 --> Encryption Class Initialized
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Model Class Initialized
INFO - 2020-09-05 18:19:56 --> Controller Class Initialized
DEBUG - 2020-09-05 18:19:56 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 18:19:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 18:19:56 --> Final output sent to browser
DEBUG - 2020-09-05 18:19:56 --> Total execution time: 0.5141
INFO - 2020-09-05 18:20:06 --> Config Class Initialized
INFO - 2020-09-05 18:20:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:20:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:20:06 --> Utf8 Class Initialized
INFO - 2020-09-05 18:20:06 --> URI Class Initialized
INFO - 2020-09-05 18:20:06 --> Router Class Initialized
INFO - 2020-09-05 18:20:06 --> Output Class Initialized
INFO - 2020-09-05 18:20:06 --> Security Class Initialized
DEBUG - 2020-09-05 18:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:20:06 --> Input Class Initialized
INFO - 2020-09-05 18:20:06 --> Language Class Initialized
INFO - 2020-09-05 18:20:06 --> Language Class Initialized
INFO - 2020-09-05 18:20:06 --> Config Class Initialized
INFO - 2020-09-05 18:20:06 --> Loader Class Initialized
INFO - 2020-09-05 18:20:06 --> Helper loaded: url_helper
INFO - 2020-09-05 18:20:06 --> Helper loaded: file_helper
INFO - 2020-09-05 18:20:06 --> Database Driver Class Initialized
INFO - 2020-09-05 18:20:06 --> Email Class Initialized
INFO - 2020-09-05 18:20:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:20:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:20:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:20:06 --> Encryption Class Initialized
INFO - 2020-09-05 18:20:06 --> Model Class Initialized
INFO - 2020-09-05 18:20:06 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:20:06 --> Model Class Initialized
INFO - 2020-09-05 18:20:06 --> Model Class Initialized
INFO - 2020-09-05 18:20:06 --> Controller Class Initialized
DEBUG - 2020-09-05 18:20:06 --> Course MX_Controller Initialized
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/course.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 18:20:06 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 18:20:06 --> Final output sent to browser
DEBUG - 2020-09-05 18:20:06 --> Total execution time: 0.7581
INFO - 2020-09-05 18:20:10 --> Config Class Initialized
INFO - 2020-09-05 18:20:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:20:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:20:10 --> Utf8 Class Initialized
INFO - 2020-09-05 18:20:10 --> URI Class Initialized
INFO - 2020-09-05 18:20:10 --> Router Class Initialized
INFO - 2020-09-05 18:20:10 --> Output Class Initialized
INFO - 2020-09-05 18:20:10 --> Security Class Initialized
DEBUG - 2020-09-05 18:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:20:10 --> Input Class Initialized
INFO - 2020-09-05 18:20:10 --> Language Class Initialized
INFO - 2020-09-05 18:20:10 --> Language Class Initialized
INFO - 2020-09-05 18:20:10 --> Config Class Initialized
INFO - 2020-09-05 18:20:10 --> Loader Class Initialized
INFO - 2020-09-05 18:20:10 --> Helper loaded: url_helper
INFO - 2020-09-05 18:20:10 --> Helper loaded: file_helper
INFO - 2020-09-05 18:20:10 --> Database Driver Class Initialized
INFO - 2020-09-05 18:20:10 --> Email Class Initialized
INFO - 2020-09-05 18:20:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 18:20:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 18:20:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 18:20:10 --> Encryption Class Initialized
INFO - 2020-09-05 18:20:10 --> Model Class Initialized
INFO - 2020-09-05 18:20:10 --> Helper loaded: inflector_helper
INFO - 2020-09-05 18:20:10 --> Model Class Initialized
INFO - 2020-09-05 18:20:10 --> Model Class Initialized
INFO - 2020-09-05 18:20:10 --> Controller Class Initialized
DEBUG - 2020-09-05 18:20:10 --> Videos MX_Controller Initialized
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/view_videos.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 18:20:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 18:20:10 --> Final output sent to browser
DEBUG - 2020-09-05 18:20:11 --> Total execution time: 0.6590
INFO - 2020-09-05 19:00:59 --> Config Class Initialized
INFO - 2020-09-05 19:00:59 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:00:59 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:00:59 --> Utf8 Class Initialized
INFO - 2020-09-05 19:00:59 --> URI Class Initialized
INFO - 2020-09-05 19:00:59 --> Router Class Initialized
INFO - 2020-09-05 19:00:59 --> Output Class Initialized
INFO - 2020-09-05 19:00:59 --> Security Class Initialized
DEBUG - 2020-09-05 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:00:59 --> Input Class Initialized
INFO - 2020-09-05 19:00:59 --> Language Class Initialized
INFO - 2020-09-05 19:00:59 --> Language Class Initialized
INFO - 2020-09-05 19:00:59 --> Config Class Initialized
INFO - 2020-09-05 19:00:59 --> Loader Class Initialized
INFO - 2020-09-05 19:00:59 --> Helper loaded: url_helper
INFO - 2020-09-05 19:00:59 --> Helper loaded: file_helper
INFO - 2020-09-05 19:00:59 --> Database Driver Class Initialized
INFO - 2020-09-05 19:00:59 --> Email Class Initialized
INFO - 2020-09-05 19:00:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:00:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:00:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:00:59 --> Encryption Class Initialized
INFO - 2020-09-05 19:00:59 --> Model Class Initialized
INFO - 2020-09-05 19:00:59 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:00:59 --> Model Class Initialized
INFO - 2020-09-05 19:00:59 --> Model Class Initialized
INFO - 2020-09-05 19:00:59 --> Controller Class Initialized
DEBUG - 2020-09-05 19:00:59 --> Videos MX_Controller Initialized
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/view_videos.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:00:59 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:00:59 --> Final output sent to browser
DEBUG - 2020-09-05 19:00:59 --> Total execution time: 0.5533
INFO - 2020-09-05 19:03:24 --> Config Class Initialized
INFO - 2020-09-05 19:03:24 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:24 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:24 --> URI Class Initialized
INFO - 2020-09-05 19:03:24 --> Router Class Initialized
INFO - 2020-09-05 19:03:24 --> Output Class Initialized
INFO - 2020-09-05 19:03:24 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:24 --> Input Class Initialized
INFO - 2020-09-05 19:03:24 --> Language Class Initialized
INFO - 2020-09-05 19:03:24 --> Language Class Initialized
INFO - 2020-09-05 19:03:24 --> Config Class Initialized
INFO - 2020-09-05 19:03:25 --> Loader Class Initialized
INFO - 2020-09-05 19:03:25 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:25 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:25 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:25 --> Email Class Initialized
INFO - 2020-09-05 19:03:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:25 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:25 --> Model Class Initialized
INFO - 2020-09-05 19:03:25 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:25 --> Model Class Initialized
INFO - 2020-09-05 19:03:25 --> Model Class Initialized
INFO - 2020-09-05 19:03:25 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:25 --> Videos MX_Controller Initialized
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/view_videos.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:03:25 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:03:25 --> Final output sent to browser
DEBUG - 2020-09-05 19:03:25 --> Total execution time: 0.8050
INFO - 2020-09-05 19:03:28 --> Config Class Initialized
INFO - 2020-09-05 19:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:29 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:29 --> URI Class Initialized
INFO - 2020-09-05 19:03:29 --> Router Class Initialized
INFO - 2020-09-05 19:03:29 --> Output Class Initialized
INFO - 2020-09-05 19:03:29 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:29 --> Input Class Initialized
INFO - 2020-09-05 19:03:29 --> Language Class Initialized
ERROR - 2020-09-05 19:03:29 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:03:48 --> Config Class Initialized
INFO - 2020-09-05 19:03:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:48 --> URI Class Initialized
DEBUG - 2020-09-05 19:03:48 --> No URI present. Default controller set.
INFO - 2020-09-05 19:03:48 --> Router Class Initialized
INFO - 2020-09-05 19:03:48 --> Output Class Initialized
INFO - 2020-09-05 19:03:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:48 --> Input Class Initialized
INFO - 2020-09-05 19:03:48 --> Language Class Initialized
INFO - 2020-09-05 19:03:48 --> Language Class Initialized
INFO - 2020-09-05 19:03:48 --> Config Class Initialized
INFO - 2020-09-05 19:03:48 --> Loader Class Initialized
INFO - 2020-09-05 19:03:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:48 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:48 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:48 --> Email Class Initialized
INFO - 2020-09-05 19:03:48 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:48 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:48 --> Model Class Initialized
INFO - 2020-09-05 19:03:48 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:48 --> Model Class Initialized
INFO - 2020-09-05 19:03:48 --> Model Class Initialized
INFO - 2020-09-05 19:03:48 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:48 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:03:48 --> Config Class Initialized
INFO - 2020-09-05 19:03:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:48 --> URI Class Initialized
INFO - 2020-09-05 19:03:48 --> Router Class Initialized
INFO - 2020-09-05 19:03:48 --> Output Class Initialized
INFO - 2020-09-05 19:03:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:48 --> Input Class Initialized
INFO - 2020-09-05 19:03:48 --> Language Class Initialized
INFO - 2020-09-05 19:03:48 --> Language Class Initialized
INFO - 2020-09-05 19:03:48 --> Config Class Initialized
INFO - 2020-09-05 19:03:48 --> Loader Class Initialized
INFO - 2020-09-05 19:03:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:49 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:49 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:49 --> Email Class Initialized
INFO - 2020-09-05 19:03:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:49 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:49 --> Model Class Initialized
INFO - 2020-09-05 19:03:49 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:49 --> Model Class Initialized
INFO - 2020-09-05 19:03:49 --> Model Class Initialized
INFO - 2020-09-05 19:03:49 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:49 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:03:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:03:49 --> Final output sent to browser
DEBUG - 2020-09-05 19:03:49 --> Total execution time: 0.4588
INFO - 2020-09-05 19:03:54 --> Config Class Initialized
INFO - 2020-09-05 19:03:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:54 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:54 --> URI Class Initialized
INFO - 2020-09-05 19:03:54 --> Router Class Initialized
INFO - 2020-09-05 19:03:54 --> Output Class Initialized
INFO - 2020-09-05 19:03:54 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:54 --> Input Class Initialized
INFO - 2020-09-05 19:03:54 --> Language Class Initialized
INFO - 2020-09-05 19:03:54 --> Language Class Initialized
INFO - 2020-09-05 19:03:54 --> Config Class Initialized
INFO - 2020-09-05 19:03:54 --> Loader Class Initialized
INFO - 2020-09-05 19:03:54 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:54 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:54 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:54 --> Email Class Initialized
INFO - 2020-09-05 19:03:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:54 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:54 --> Model Class Initialized
INFO - 2020-09-05 19:03:54 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:54 --> Model Class Initialized
INFO - 2020-09-05 19:03:54 --> Model Class Initialized
INFO - 2020-09-05 19:03:54 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:54 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:03:55 --> Config Class Initialized
INFO - 2020-09-05 19:03:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:55 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:55 --> URI Class Initialized
DEBUG - 2020-09-05 19:03:55 --> No URI present. Default controller set.
INFO - 2020-09-05 19:03:55 --> Router Class Initialized
INFO - 2020-09-05 19:03:55 --> Output Class Initialized
INFO - 2020-09-05 19:03:55 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:55 --> Input Class Initialized
INFO - 2020-09-05 19:03:55 --> Language Class Initialized
INFO - 2020-09-05 19:03:55 --> Language Class Initialized
INFO - 2020-09-05 19:03:55 --> Config Class Initialized
INFO - 2020-09-05 19:03:55 --> Loader Class Initialized
INFO - 2020-09-05 19:03:55 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:55 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:55 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:55 --> Email Class Initialized
INFO - 2020-09-05 19:03:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:55 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:55 --> Model Class Initialized
INFO - 2020-09-05 19:03:55 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:55 --> Model Class Initialized
INFO - 2020-09-05 19:03:55 --> Model Class Initialized
INFO - 2020-09-05 19:03:55 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:55 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:03:55 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:03:55 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:03:55 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:03:55 --> Final output sent to browser
DEBUG - 2020-09-05 19:03:55 --> Total execution time: 0.4462
INFO - 2020-09-05 19:03:57 --> Config Class Initialized
INFO - 2020-09-05 19:03:57 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:57 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:57 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:57 --> URI Class Initialized
INFO - 2020-09-05 19:03:57 --> Router Class Initialized
INFO - 2020-09-05 19:03:57 --> Output Class Initialized
INFO - 2020-09-05 19:03:57 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:57 --> Input Class Initialized
INFO - 2020-09-05 19:03:57 --> Language Class Initialized
INFO - 2020-09-05 19:03:57 --> Language Class Initialized
INFO - 2020-09-05 19:03:57 --> Config Class Initialized
INFO - 2020-09-05 19:03:57 --> Loader Class Initialized
INFO - 2020-09-05 19:03:57 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:57 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:57 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:57 --> Email Class Initialized
INFO - 2020-09-05 19:03:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:57 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:57 --> Model Class Initialized
INFO - 2020-09-05 19:03:57 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:57 --> Model Class Initialized
INFO - 2020-09-05 19:03:57 --> Model Class Initialized
INFO - 2020-09-05 19:03:57 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:57 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:03:57 --> Config Class Initialized
INFO - 2020-09-05 19:03:57 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:03:57 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:03:58 --> Utf8 Class Initialized
INFO - 2020-09-05 19:03:58 --> URI Class Initialized
INFO - 2020-09-05 19:03:58 --> Router Class Initialized
INFO - 2020-09-05 19:03:58 --> Output Class Initialized
INFO - 2020-09-05 19:03:58 --> Security Class Initialized
DEBUG - 2020-09-05 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:03:58 --> Input Class Initialized
INFO - 2020-09-05 19:03:58 --> Language Class Initialized
INFO - 2020-09-05 19:03:58 --> Language Class Initialized
INFO - 2020-09-05 19:03:58 --> Config Class Initialized
INFO - 2020-09-05 19:03:58 --> Loader Class Initialized
INFO - 2020-09-05 19:03:58 --> Helper loaded: url_helper
INFO - 2020-09-05 19:03:58 --> Helper loaded: file_helper
INFO - 2020-09-05 19:03:58 --> Database Driver Class Initialized
INFO - 2020-09-05 19:03:58 --> Email Class Initialized
INFO - 2020-09-05 19:03:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:03:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:03:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:03:58 --> Encryption Class Initialized
INFO - 2020-09-05 19:03:58 --> Model Class Initialized
INFO - 2020-09-05 19:03:58 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:03:58 --> Model Class Initialized
INFO - 2020-09-05 19:03:58 --> Model Class Initialized
INFO - 2020-09-05 19:03:58 --> Controller Class Initialized
DEBUG - 2020-09-05 19:03:58 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:03:58 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:03:58 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:03:58 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:03:58 --> Final output sent to browser
DEBUG - 2020-09-05 19:03:58 --> Total execution time: 0.5343
INFO - 2020-09-05 19:04:06 --> Config Class Initialized
INFO - 2020-09-05 19:04:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:06 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:06 --> URI Class Initialized
INFO - 2020-09-05 19:04:06 --> Router Class Initialized
INFO - 2020-09-05 19:04:06 --> Output Class Initialized
INFO - 2020-09-05 19:04:06 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:06 --> Input Class Initialized
INFO - 2020-09-05 19:04:06 --> Language Class Initialized
INFO - 2020-09-05 19:04:06 --> Language Class Initialized
INFO - 2020-09-05 19:04:06 --> Config Class Initialized
INFO - 2020-09-05 19:04:06 --> Loader Class Initialized
INFO - 2020-09-05 19:04:06 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:06 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:06 --> Database Driver Class Initialized
INFO - 2020-09-05 19:04:06 --> Email Class Initialized
INFO - 2020-09-05 19:04:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:04:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:04:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:04:06 --> Encryption Class Initialized
INFO - 2020-09-05 19:04:06 --> Model Class Initialized
INFO - 2020-09-05 19:04:06 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:04:06 --> Model Class Initialized
INFO - 2020-09-05 19:04:06 --> Model Class Initialized
INFO - 2020-09-05 19:04:06 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:06 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:04:06 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:06 --> Total execution time: 0.5293
INFO - 2020-09-05 19:04:15 --> Config Class Initialized
INFO - 2020-09-05 19:04:15 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:15 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:15 --> URI Class Initialized
INFO - 2020-09-05 19:04:15 --> Router Class Initialized
INFO - 2020-09-05 19:04:15 --> Output Class Initialized
INFO - 2020-09-05 19:04:15 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:15 --> Input Class Initialized
INFO - 2020-09-05 19:04:15 --> Language Class Initialized
INFO - 2020-09-05 19:04:15 --> Language Class Initialized
INFO - 2020-09-05 19:04:15 --> Config Class Initialized
INFO - 2020-09-05 19:04:15 --> Loader Class Initialized
INFO - 2020-09-05 19:04:15 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:15 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:15 --> Database Driver Class Initialized
INFO - 2020-09-05 19:04:15 --> Email Class Initialized
INFO - 2020-09-05 19:04:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:04:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:04:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:04:15 --> Encryption Class Initialized
INFO - 2020-09-05 19:04:15 --> Model Class Initialized
INFO - 2020-09-05 19:04:15 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:04:15 --> Model Class Initialized
INFO - 2020-09-05 19:04:15 --> Model Class Initialized
INFO - 2020-09-05 19:04:15 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:15 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:04:15 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:15 --> Total execution time: 0.5043
INFO - 2020-09-05 19:04:23 --> Config Class Initialized
INFO - 2020-09-05 19:04:23 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:24 --> URI Class Initialized
INFO - 2020-09-05 19:04:24 --> Router Class Initialized
INFO - 2020-09-05 19:04:24 --> Output Class Initialized
INFO - 2020-09-05 19:04:24 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:24 --> Input Class Initialized
INFO - 2020-09-05 19:04:24 --> Language Class Initialized
INFO - 2020-09-05 19:04:24 --> Language Class Initialized
INFO - 2020-09-05 19:04:24 --> Config Class Initialized
INFO - 2020-09-05 19:04:24 --> Loader Class Initialized
INFO - 2020-09-05 19:04:24 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:24 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:24 --> Database Driver Class Initialized
INFO - 2020-09-05 19:04:24 --> Email Class Initialized
INFO - 2020-09-05 19:04:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:04:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:04:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:04:24 --> Encryption Class Initialized
INFO - 2020-09-05 19:04:24 --> Model Class Initialized
INFO - 2020-09-05 19:04:24 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:04:24 --> Model Class Initialized
INFO - 2020-09-05 19:04:24 --> Model Class Initialized
INFO - 2020-09-05 19:04:24 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:24 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:04:24 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:24 --> Total execution time: 0.3781
INFO - 2020-09-05 19:04:27 --> Config Class Initialized
INFO - 2020-09-05 19:04:27 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:27 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:27 --> URI Class Initialized
INFO - 2020-09-05 19:04:27 --> Router Class Initialized
INFO - 2020-09-05 19:04:27 --> Output Class Initialized
INFO - 2020-09-05 19:04:27 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:27 --> Input Class Initialized
INFO - 2020-09-05 19:04:27 --> Language Class Initialized
INFO - 2020-09-05 19:04:27 --> Language Class Initialized
INFO - 2020-09-05 19:04:27 --> Config Class Initialized
INFO - 2020-09-05 19:04:27 --> Loader Class Initialized
INFO - 2020-09-05 19:04:27 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:27 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:27 --> Database Driver Class Initialized
INFO - 2020-09-05 19:04:27 --> Email Class Initialized
INFO - 2020-09-05 19:04:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:04:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:04:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:04:27 --> Encryption Class Initialized
INFO - 2020-09-05 19:04:27 --> Model Class Initialized
INFO - 2020-09-05 19:04:27 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:04:27 --> Model Class Initialized
INFO - 2020-09-05 19:04:27 --> Model Class Initialized
INFO - 2020-09-05 19:04:27 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:27 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:04:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:04:28 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:04:28 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:28 --> Total execution time: 0.6004
INFO - 2020-09-05 19:06:10 --> Config Class Initialized
INFO - 2020-09-05 19:06:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:06:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:06:10 --> Utf8 Class Initialized
INFO - 2020-09-05 19:06:10 --> URI Class Initialized
INFO - 2020-09-05 19:06:10 --> Router Class Initialized
INFO - 2020-09-05 19:06:10 --> Output Class Initialized
INFO - 2020-09-05 19:06:10 --> Security Class Initialized
DEBUG - 2020-09-05 19:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:06:10 --> Input Class Initialized
INFO - 2020-09-05 19:06:10 --> Language Class Initialized
INFO - 2020-09-05 19:06:10 --> Language Class Initialized
INFO - 2020-09-05 19:06:10 --> Config Class Initialized
INFO - 2020-09-05 19:06:10 --> Loader Class Initialized
INFO - 2020-09-05 19:06:10 --> Helper loaded: url_helper
INFO - 2020-09-05 19:06:10 --> Helper loaded: file_helper
INFO - 2020-09-05 19:06:10 --> Database Driver Class Initialized
INFO - 2020-09-05 19:06:10 --> Email Class Initialized
INFO - 2020-09-05 19:06:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:06:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:06:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:06:10 --> Encryption Class Initialized
INFO - 2020-09-05 19:06:10 --> Model Class Initialized
INFO - 2020-09-05 19:06:10 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:06:10 --> Model Class Initialized
INFO - 2020-09-05 19:06:10 --> Model Class Initialized
INFO - 2020-09-05 19:06:10 --> Controller Class Initialized
DEBUG - 2020-09-05 19:06:10 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:06:10 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:06:10 --> Final output sent to browser
DEBUG - 2020-09-05 19:06:10 --> Total execution time: 0.6015
INFO - 2020-09-05 19:07:13 --> Config Class Initialized
INFO - 2020-09-05 19:07:13 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:07:13 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:07:13 --> Utf8 Class Initialized
INFO - 2020-09-05 19:07:13 --> URI Class Initialized
INFO - 2020-09-05 19:07:13 --> Router Class Initialized
INFO - 2020-09-05 19:07:13 --> Output Class Initialized
INFO - 2020-09-05 19:07:13 --> Security Class Initialized
DEBUG - 2020-09-05 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:07:13 --> Input Class Initialized
INFO - 2020-09-05 19:07:13 --> Language Class Initialized
INFO - 2020-09-05 19:07:13 --> Language Class Initialized
INFO - 2020-09-05 19:07:13 --> Config Class Initialized
INFO - 2020-09-05 19:07:13 --> Loader Class Initialized
INFO - 2020-09-05 19:07:13 --> Helper loaded: url_helper
INFO - 2020-09-05 19:07:13 --> Helper loaded: file_helper
INFO - 2020-09-05 19:07:13 --> Database Driver Class Initialized
INFO - 2020-09-05 19:07:13 --> Email Class Initialized
INFO - 2020-09-05 19:07:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:07:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:07:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:07:13 --> Encryption Class Initialized
INFO - 2020-09-05 19:07:13 --> Model Class Initialized
INFO - 2020-09-05 19:07:13 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:07:13 --> Model Class Initialized
INFO - 2020-09-05 19:07:13 --> Model Class Initialized
INFO - 2020-09-05 19:07:13 --> Controller Class Initialized
DEBUG - 2020-09-05 19:07:13 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:07:13 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:07:13 --> Final output sent to browser
DEBUG - 2020-09-05 19:07:13 --> Total execution time: 0.6936
INFO - 2020-09-05 19:07:20 --> Config Class Initialized
INFO - 2020-09-05 19:07:20 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:07:20 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:07:20 --> Utf8 Class Initialized
INFO - 2020-09-05 19:07:20 --> URI Class Initialized
INFO - 2020-09-05 19:07:20 --> Router Class Initialized
INFO - 2020-09-05 19:07:20 --> Output Class Initialized
INFO - 2020-09-05 19:07:20 --> Security Class Initialized
DEBUG - 2020-09-05 19:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:07:20 --> Input Class Initialized
INFO - 2020-09-05 19:07:20 --> Language Class Initialized
INFO - 2020-09-05 19:07:20 --> Language Class Initialized
INFO - 2020-09-05 19:07:20 --> Config Class Initialized
INFO - 2020-09-05 19:07:20 --> Loader Class Initialized
INFO - 2020-09-05 19:07:20 --> Helper loaded: url_helper
INFO - 2020-09-05 19:07:20 --> Helper loaded: file_helper
INFO - 2020-09-05 19:07:20 --> Database Driver Class Initialized
INFO - 2020-09-05 19:07:20 --> Email Class Initialized
INFO - 2020-09-05 19:07:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:07:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:07:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:07:21 --> Encryption Class Initialized
INFO - 2020-09-05 19:07:21 --> Model Class Initialized
INFO - 2020-09-05 19:07:21 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:07:21 --> Model Class Initialized
INFO - 2020-09-05 19:07:21 --> Model Class Initialized
INFO - 2020-09-05 19:07:21 --> Controller Class Initialized
DEBUG - 2020-09-05 19:07:21 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:07:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:07:21 --> Final output sent to browser
DEBUG - 2020-09-05 19:07:21 --> Total execution time: 0.8010
INFO - 2020-09-05 19:07:45 --> Config Class Initialized
INFO - 2020-09-05 19:07:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:07:46 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:07:46 --> Utf8 Class Initialized
INFO - 2020-09-05 19:07:46 --> URI Class Initialized
INFO - 2020-09-05 19:07:46 --> Router Class Initialized
INFO - 2020-09-05 19:07:46 --> Output Class Initialized
INFO - 2020-09-05 19:07:46 --> Security Class Initialized
DEBUG - 2020-09-05 19:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:07:46 --> Input Class Initialized
INFO - 2020-09-05 19:07:46 --> Language Class Initialized
INFO - 2020-09-05 19:07:46 --> Language Class Initialized
INFO - 2020-09-05 19:07:46 --> Config Class Initialized
INFO - 2020-09-05 19:07:46 --> Loader Class Initialized
INFO - 2020-09-05 19:07:46 --> Helper loaded: url_helper
INFO - 2020-09-05 19:07:46 --> Helper loaded: file_helper
INFO - 2020-09-05 19:07:46 --> Database Driver Class Initialized
INFO - 2020-09-05 19:07:46 --> Email Class Initialized
INFO - 2020-09-05 19:07:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:07:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:07:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:07:46 --> Encryption Class Initialized
INFO - 2020-09-05 19:07:46 --> Model Class Initialized
INFO - 2020-09-05 19:07:46 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:07:46 --> Model Class Initialized
INFO - 2020-09-05 19:07:46 --> Model Class Initialized
INFO - 2020-09-05 19:07:46 --> Controller Class Initialized
DEBUG - 2020-09-05 19:07:46 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:07:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:07:46 --> Final output sent to browser
DEBUG - 2020-09-05 19:07:46 --> Total execution time: 0.5853
INFO - 2020-09-05 19:07:53 --> Config Class Initialized
INFO - 2020-09-05 19:07:53 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:07:53 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:07:53 --> Utf8 Class Initialized
INFO - 2020-09-05 19:07:53 --> URI Class Initialized
INFO - 2020-09-05 19:07:53 --> Router Class Initialized
INFO - 2020-09-05 19:07:53 --> Output Class Initialized
INFO - 2020-09-05 19:07:53 --> Security Class Initialized
DEBUG - 2020-09-05 19:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:07:53 --> Input Class Initialized
INFO - 2020-09-05 19:07:54 --> Language Class Initialized
INFO - 2020-09-05 19:07:54 --> Language Class Initialized
INFO - 2020-09-05 19:07:54 --> Config Class Initialized
INFO - 2020-09-05 19:07:54 --> Loader Class Initialized
INFO - 2020-09-05 19:07:54 --> Helper loaded: url_helper
INFO - 2020-09-05 19:07:54 --> Helper loaded: file_helper
INFO - 2020-09-05 19:07:54 --> Database Driver Class Initialized
INFO - 2020-09-05 19:07:54 --> Email Class Initialized
INFO - 2020-09-05 19:07:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:07:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:07:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:07:54 --> Encryption Class Initialized
INFO - 2020-09-05 19:07:54 --> Model Class Initialized
INFO - 2020-09-05 19:07:54 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:07:54 --> Model Class Initialized
INFO - 2020-09-05 19:07:54 --> Model Class Initialized
INFO - 2020-09-05 19:07:54 --> Controller Class Initialized
DEBUG - 2020-09-05 19:07:54 --> Course MX_Controller Initialized
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/course.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:07:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:07:54 --> Final output sent to browser
DEBUG - 2020-09-05 19:07:54 --> Total execution time: 0.6334
INFO - 2020-09-05 19:10:02 --> Config Class Initialized
INFO - 2020-09-05 19:10:02 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:10:02 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:10:02 --> Utf8 Class Initialized
INFO - 2020-09-05 19:10:02 --> URI Class Initialized
INFO - 2020-09-05 19:10:02 --> Router Class Initialized
INFO - 2020-09-05 19:10:02 --> Output Class Initialized
INFO - 2020-09-05 19:10:02 --> Security Class Initialized
DEBUG - 2020-09-05 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:10:02 --> Input Class Initialized
INFO - 2020-09-05 19:10:02 --> Language Class Initialized
INFO - 2020-09-05 19:10:02 --> Language Class Initialized
INFO - 2020-09-05 19:10:02 --> Config Class Initialized
INFO - 2020-09-05 19:10:02 --> Loader Class Initialized
INFO - 2020-09-05 19:10:02 --> Helper loaded: url_helper
INFO - 2020-09-05 19:10:02 --> Helper loaded: file_helper
INFO - 2020-09-05 19:10:02 --> Database Driver Class Initialized
INFO - 2020-09-05 19:10:02 --> Email Class Initialized
INFO - 2020-09-05 19:10:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:10:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:10:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:10:02 --> Encryption Class Initialized
INFO - 2020-09-05 19:10:02 --> Model Class Initialized
INFO - 2020-09-05 19:10:02 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:10:02 --> Model Class Initialized
INFO - 2020-09-05 19:10:02 --> Model Class Initialized
INFO - 2020-09-05 19:10:02 --> Controller Class Initialized
ERROR - 2020-09-05 19:10:02 --> 404 Page Not Found: ../modules/Admin/controllers/Admin/Course
INFO - 2020-09-05 19:10:04 --> Config Class Initialized
INFO - 2020-09-05 19:10:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:10:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:10:04 --> Utf8 Class Initialized
INFO - 2020-09-05 19:10:04 --> URI Class Initialized
INFO - 2020-09-05 19:10:04 --> Router Class Initialized
INFO - 2020-09-05 19:10:04 --> Output Class Initialized
INFO - 2020-09-05 19:10:04 --> Security Class Initialized
DEBUG - 2020-09-05 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:10:05 --> Input Class Initialized
INFO - 2020-09-05 19:10:05 --> Language Class Initialized
INFO - 2020-09-05 19:10:05 --> Language Class Initialized
INFO - 2020-09-05 19:10:05 --> Config Class Initialized
INFO - 2020-09-05 19:10:05 --> Loader Class Initialized
INFO - 2020-09-05 19:10:05 --> Helper loaded: url_helper
INFO - 2020-09-05 19:10:05 --> Helper loaded: file_helper
INFO - 2020-09-05 19:10:05 --> Database Driver Class Initialized
INFO - 2020-09-05 19:10:05 --> Email Class Initialized
INFO - 2020-09-05 19:10:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:10:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:10:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:10:05 --> Encryption Class Initialized
INFO - 2020-09-05 19:10:05 --> Model Class Initialized
INFO - 2020-09-05 19:10:05 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:10:05 --> Model Class Initialized
INFO - 2020-09-05 19:10:05 --> Model Class Initialized
INFO - 2020-09-05 19:10:05 --> Controller Class Initialized
DEBUG - 2020-09-05 19:10:05 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:10:05 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:10:05 --> Final output sent to browser
DEBUG - 2020-09-05 19:10:05 --> Total execution time: 0.6778
INFO - 2020-09-05 19:10:16 --> Config Class Initialized
INFO - 2020-09-05 19:10:16 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:10:16 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:10:16 --> Utf8 Class Initialized
INFO - 2020-09-05 19:10:16 --> URI Class Initialized
INFO - 2020-09-05 19:10:16 --> Router Class Initialized
INFO - 2020-09-05 19:10:16 --> Output Class Initialized
INFO - 2020-09-05 19:10:16 --> Security Class Initialized
DEBUG - 2020-09-05 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:10:16 --> Input Class Initialized
INFO - 2020-09-05 19:10:16 --> Language Class Initialized
INFO - 2020-09-05 19:10:16 --> Language Class Initialized
INFO - 2020-09-05 19:10:16 --> Config Class Initialized
INFO - 2020-09-05 19:10:16 --> Loader Class Initialized
INFO - 2020-09-05 19:10:16 --> Helper loaded: url_helper
INFO - 2020-09-05 19:10:16 --> Helper loaded: file_helper
INFO - 2020-09-05 19:10:17 --> Database Driver Class Initialized
INFO - 2020-09-05 19:10:17 --> Email Class Initialized
INFO - 2020-09-05 19:10:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:10:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:10:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:10:17 --> Encryption Class Initialized
INFO - 2020-09-05 19:10:17 --> Model Class Initialized
INFO - 2020-09-05 19:10:17 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:10:17 --> Model Class Initialized
INFO - 2020-09-05 19:10:17 --> Model Class Initialized
INFO - 2020-09-05 19:10:17 --> Controller Class Initialized
DEBUG - 2020-09-05 19:10:17 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:10:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:10:17 --> Final output sent to browser
DEBUG - 2020-09-05 19:10:17 --> Total execution time: 0.6592
INFO - 2020-09-05 19:10:19 --> Config Class Initialized
INFO - 2020-09-05 19:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:10:19 --> Utf8 Class Initialized
INFO - 2020-09-05 19:10:19 --> URI Class Initialized
INFO - 2020-09-05 19:10:19 --> Router Class Initialized
INFO - 2020-09-05 19:10:19 --> Output Class Initialized
INFO - 2020-09-05 19:10:19 --> Security Class Initialized
DEBUG - 2020-09-05 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:10:19 --> Input Class Initialized
INFO - 2020-09-05 19:10:19 --> Language Class Initialized
INFO - 2020-09-05 19:10:19 --> Language Class Initialized
INFO - 2020-09-05 19:10:19 --> Config Class Initialized
INFO - 2020-09-05 19:10:19 --> Loader Class Initialized
INFO - 2020-09-05 19:10:19 --> Helper loaded: url_helper
INFO - 2020-09-05 19:10:19 --> Helper loaded: file_helper
INFO - 2020-09-05 19:10:19 --> Database Driver Class Initialized
INFO - 2020-09-05 19:10:19 --> Email Class Initialized
INFO - 2020-09-05 19:10:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:10:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:10:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:10:19 --> Encryption Class Initialized
INFO - 2020-09-05 19:10:19 --> Model Class Initialized
INFO - 2020-09-05 19:10:19 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:10:19 --> Model Class Initialized
INFO - 2020-09-05 19:10:19 --> Model Class Initialized
INFO - 2020-09-05 19:10:19 --> Controller Class Initialized
DEBUG - 2020-09-05 19:10:19 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
ERROR - 2020-09-05 19:10:19 --> Severity: Notice --> Undefined variable: allCourse A:\Xampp\htdocs\salim_works\WebCard\application\modules\Admin\views\course.php 9
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/course.php
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:10:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:10:19 --> Final output sent to browser
DEBUG - 2020-09-05 19:10:19 --> Total execution time: 0.5886
INFO - 2020-09-05 19:11:37 --> Config Class Initialized
INFO - 2020-09-05 19:11:37 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:11:37 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:11:37 --> Utf8 Class Initialized
INFO - 2020-09-05 19:11:37 --> URI Class Initialized
INFO - 2020-09-05 19:11:37 --> Router Class Initialized
INFO - 2020-09-05 19:11:37 --> Output Class Initialized
INFO - 2020-09-05 19:11:37 --> Security Class Initialized
DEBUG - 2020-09-05 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:11:37 --> Input Class Initialized
INFO - 2020-09-05 19:11:37 --> Language Class Initialized
INFO - 2020-09-05 19:11:37 --> Language Class Initialized
INFO - 2020-09-05 19:11:37 --> Config Class Initialized
INFO - 2020-09-05 19:11:37 --> Loader Class Initialized
INFO - 2020-09-05 19:11:37 --> Helper loaded: url_helper
INFO - 2020-09-05 19:11:37 --> Helper loaded: file_helper
INFO - 2020-09-05 19:11:37 --> Database Driver Class Initialized
INFO - 2020-09-05 19:11:37 --> Email Class Initialized
INFO - 2020-09-05 19:11:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:11:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:11:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:11:37 --> Encryption Class Initialized
INFO - 2020-09-05 19:11:37 --> Model Class Initialized
INFO - 2020-09-05 19:11:37 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:11:37 --> Model Class Initialized
INFO - 2020-09-05 19:11:37 --> Model Class Initialized
INFO - 2020-09-05 19:11:37 --> Controller Class Initialized
DEBUG - 2020-09-05 19:11:37 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:11:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:11:37 --> Final output sent to browser
DEBUG - 2020-09-05 19:11:37 --> Total execution time: 0.5285
INFO - 2020-09-05 19:12:11 --> Config Class Initialized
INFO - 2020-09-05 19:12:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:12:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:12:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:12:11 --> URI Class Initialized
INFO - 2020-09-05 19:12:11 --> Router Class Initialized
INFO - 2020-09-05 19:12:11 --> Output Class Initialized
INFO - 2020-09-05 19:12:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:12:11 --> Input Class Initialized
INFO - 2020-09-05 19:12:12 --> Language Class Initialized
INFO - 2020-09-05 19:12:12 --> Language Class Initialized
INFO - 2020-09-05 19:12:12 --> Config Class Initialized
INFO - 2020-09-05 19:12:12 --> Loader Class Initialized
INFO - 2020-09-05 19:12:12 --> Helper loaded: url_helper
INFO - 2020-09-05 19:12:12 --> Helper loaded: file_helper
INFO - 2020-09-05 19:12:12 --> Database Driver Class Initialized
INFO - 2020-09-05 19:12:12 --> Email Class Initialized
INFO - 2020-09-05 19:12:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:12:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:12:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:12:12 --> Encryption Class Initialized
INFO - 2020-09-05 19:12:12 --> Model Class Initialized
INFO - 2020-09-05 19:12:12 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:12:12 --> Model Class Initialized
INFO - 2020-09-05 19:12:12 --> Model Class Initialized
INFO - 2020-09-05 19:12:12 --> Controller Class Initialized
DEBUG - 2020-09-05 19:12:12 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:12:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:12:12 --> Final output sent to browser
DEBUG - 2020-09-05 19:12:12 --> Total execution time: 0.6235
INFO - 2020-09-05 19:15:28 --> Config Class Initialized
INFO - 2020-09-05 19:15:28 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:15:28 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:15:28 --> Utf8 Class Initialized
INFO - 2020-09-05 19:15:28 --> URI Class Initialized
INFO - 2020-09-05 19:15:28 --> Router Class Initialized
INFO - 2020-09-05 19:15:28 --> Output Class Initialized
INFO - 2020-09-05 19:15:28 --> Security Class Initialized
DEBUG - 2020-09-05 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:15:28 --> Input Class Initialized
INFO - 2020-09-05 19:15:28 --> Language Class Initialized
INFO - 2020-09-05 19:15:28 --> Language Class Initialized
INFO - 2020-09-05 19:15:28 --> Config Class Initialized
INFO - 2020-09-05 19:15:28 --> Loader Class Initialized
INFO - 2020-09-05 19:15:28 --> Helper loaded: url_helper
INFO - 2020-09-05 19:15:28 --> Helper loaded: file_helper
INFO - 2020-09-05 19:15:28 --> Database Driver Class Initialized
INFO - 2020-09-05 19:15:28 --> Email Class Initialized
INFO - 2020-09-05 19:15:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:15:28 --> Encryption Class Initialized
INFO - 2020-09-05 19:15:28 --> Model Class Initialized
INFO - 2020-09-05 19:15:28 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:15:28 --> Model Class Initialized
INFO - 2020-09-05 19:15:28 --> Model Class Initialized
INFO - 2020-09-05 19:15:28 --> Controller Class Initialized
DEBUG - 2020-09-05 19:15:28 --> Card MX_Controller Initialized
INFO - 2020-09-05 19:15:29 --> Config Class Initialized
INFO - 2020-09-05 19:15:29 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:15:29 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:15:29 --> Utf8 Class Initialized
INFO - 2020-09-05 19:15:29 --> URI Class Initialized
INFO - 2020-09-05 19:15:29 --> Router Class Initialized
INFO - 2020-09-05 19:15:29 --> Output Class Initialized
INFO - 2020-09-05 19:15:29 --> Security Class Initialized
DEBUG - 2020-09-05 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:15:29 --> Input Class Initialized
INFO - 2020-09-05 19:15:29 --> Language Class Initialized
INFO - 2020-09-05 19:15:29 --> Language Class Initialized
INFO - 2020-09-05 19:15:29 --> Config Class Initialized
INFO - 2020-09-05 19:15:29 --> Loader Class Initialized
INFO - 2020-09-05 19:15:29 --> Helper loaded: url_helper
INFO - 2020-09-05 19:15:29 --> Helper loaded: file_helper
INFO - 2020-09-05 19:15:29 --> Database Driver Class Initialized
INFO - 2020-09-05 19:15:29 --> Email Class Initialized
INFO - 2020-09-05 19:15:29 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:15:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:15:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:15:29 --> Encryption Class Initialized
INFO - 2020-09-05 19:15:29 --> Model Class Initialized
INFO - 2020-09-05 19:15:29 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:15:29 --> Model Class Initialized
INFO - 2020-09-05 19:15:29 --> Model Class Initialized
INFO - 2020-09-05 19:15:29 --> Controller Class Initialized
DEBUG - 2020-09-05 19:15:29 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:15:29 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:15:29 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:15:29 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:15:29 --> Final output sent to browser
DEBUG - 2020-09-05 19:15:29 --> Total execution time: 0.5179
INFO - 2020-09-05 19:15:40 --> Config Class Initialized
INFO - 2020-09-05 19:15:40 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:15:40 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:15:40 --> Utf8 Class Initialized
INFO - 2020-09-05 19:15:40 --> URI Class Initialized
INFO - 2020-09-05 19:15:40 --> Router Class Initialized
INFO - 2020-09-05 19:15:40 --> Output Class Initialized
INFO - 2020-09-05 19:15:40 --> Security Class Initialized
DEBUG - 2020-09-05 19:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:15:40 --> Input Class Initialized
INFO - 2020-09-05 19:15:40 --> Language Class Initialized
INFO - 2020-09-05 19:15:40 --> Language Class Initialized
INFO - 2020-09-05 19:15:40 --> Config Class Initialized
INFO - 2020-09-05 19:15:40 --> Loader Class Initialized
INFO - 2020-09-05 19:15:40 --> Helper loaded: url_helper
INFO - 2020-09-05 19:15:40 --> Helper loaded: file_helper
INFO - 2020-09-05 19:15:40 --> Database Driver Class Initialized
INFO - 2020-09-05 19:15:40 --> Email Class Initialized
INFO - 2020-09-05 19:15:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:15:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:15:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:15:41 --> Encryption Class Initialized
INFO - 2020-09-05 19:15:41 --> Model Class Initialized
INFO - 2020-09-05 19:15:41 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:15:41 --> Model Class Initialized
INFO - 2020-09-05 19:15:41 --> Model Class Initialized
INFO - 2020-09-05 19:15:41 --> Controller Class Initialized
DEBUG - 2020-09-05 19:15:41 --> Admin MX_Controller Initialized
ERROR - 2020-09-05 19:15:41 --> Query error: Table 'salim_webcard.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'admin'
INFO - 2020-09-05 19:15:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-05 19:15:41 --> Query error: Unknown column 'username' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1599326141
WHERE `username` = 'admin'
AND `id` = '5c11a6e4b631841a5f1215ddf12a14a9ca6d227d'
INFO - 2020-09-05 19:15:45 --> Config Class Initialized
INFO - 2020-09-05 19:15:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:15:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:15:45 --> Utf8 Class Initialized
INFO - 2020-09-05 19:15:45 --> URI Class Initialized
INFO - 2020-09-05 19:15:45 --> Router Class Initialized
INFO - 2020-09-05 19:15:45 --> Output Class Initialized
INFO - 2020-09-05 19:15:45 --> Security Class Initialized
DEBUG - 2020-09-05 19:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:15:45 --> Input Class Initialized
INFO - 2020-09-05 19:15:45 --> Language Class Initialized
INFO - 2020-09-05 19:15:45 --> Language Class Initialized
INFO - 2020-09-05 19:15:45 --> Config Class Initialized
INFO - 2020-09-05 19:15:45 --> Loader Class Initialized
INFO - 2020-09-05 19:15:45 --> Helper loaded: url_helper
INFO - 2020-09-05 19:15:45 --> Helper loaded: file_helper
INFO - 2020-09-05 19:15:45 --> Database Driver Class Initialized
INFO - 2020-09-05 19:15:45 --> Email Class Initialized
INFO - 2020-09-05 19:15:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:15:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:15:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:15:46 --> Encryption Class Initialized
INFO - 2020-09-05 19:15:46 --> Model Class Initialized
INFO - 2020-09-05 19:15:46 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:15:46 --> Model Class Initialized
INFO - 2020-09-05 19:15:46 --> Model Class Initialized
INFO - 2020-09-05 19:15:46 --> Controller Class Initialized
DEBUG - 2020-09-05 19:15:46 --> Admin MX_Controller Initialized
ERROR - 2020-09-05 19:15:46 --> Query error: Table 'salim_webcard.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'admin'
INFO - 2020-09-05 19:15:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-05 19:15:46 --> Query error: Unknown column 'username' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1599326146
WHERE `username` = 'admin'
AND `id` = '5c11a6e4b631841a5f1215ddf12a14a9ca6d227d'
INFO - 2020-09-05 19:17:11 --> Config Class Initialized
INFO - 2020-09-05 19:17:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:17:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:17:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:17:11 --> URI Class Initialized
INFO - 2020-09-05 19:17:11 --> Router Class Initialized
INFO - 2020-09-05 19:17:11 --> Output Class Initialized
INFO - 2020-09-05 19:17:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:17:12 --> Input Class Initialized
INFO - 2020-09-05 19:17:12 --> Language Class Initialized
INFO - 2020-09-05 19:17:12 --> Language Class Initialized
INFO - 2020-09-05 19:17:12 --> Config Class Initialized
INFO - 2020-09-05 19:17:12 --> Loader Class Initialized
INFO - 2020-09-05 19:17:12 --> Helper loaded: url_helper
INFO - 2020-09-05 19:17:12 --> Helper loaded: file_helper
INFO - 2020-09-05 19:17:12 --> Database Driver Class Initialized
INFO - 2020-09-05 19:17:12 --> Email Class Initialized
INFO - 2020-09-05 19:17:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:17:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:17:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:17:12 --> Encryption Class Initialized
INFO - 2020-09-05 19:17:12 --> Model Class Initialized
INFO - 2020-09-05 19:17:12 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:17:12 --> Model Class Initialized
INFO - 2020-09-05 19:17:12 --> Model Class Initialized
INFO - 2020-09-05 19:17:12 --> Controller Class Initialized
DEBUG - 2020-09-05 19:17:12 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:17:12 --> Final output sent to browser
DEBUG - 2020-09-05 19:17:12 --> Total execution time: 0.7221
INFO - 2020-09-05 19:17:18 --> Config Class Initialized
INFO - 2020-09-05 19:17:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:17:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:17:18 --> Utf8 Class Initialized
INFO - 2020-09-05 19:17:18 --> URI Class Initialized
INFO - 2020-09-05 19:17:18 --> Router Class Initialized
INFO - 2020-09-05 19:17:18 --> Output Class Initialized
INFO - 2020-09-05 19:17:18 --> Security Class Initialized
DEBUG - 2020-09-05 19:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:17:18 --> Input Class Initialized
INFO - 2020-09-05 19:17:18 --> Language Class Initialized
INFO - 2020-09-05 19:17:18 --> Language Class Initialized
INFO - 2020-09-05 19:17:18 --> Config Class Initialized
INFO - 2020-09-05 19:17:18 --> Loader Class Initialized
INFO - 2020-09-05 19:17:18 --> Helper loaded: url_helper
INFO - 2020-09-05 19:17:18 --> Helper loaded: file_helper
INFO - 2020-09-05 19:17:18 --> Database Driver Class Initialized
INFO - 2020-09-05 19:17:18 --> Email Class Initialized
INFO - 2020-09-05 19:17:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:17:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:17:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:17:18 --> Encryption Class Initialized
INFO - 2020-09-05 19:17:18 --> Model Class Initialized
INFO - 2020-09-05 19:17:18 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:17:18 --> Model Class Initialized
INFO - 2020-09-05 19:17:18 --> Model Class Initialized
INFO - 2020-09-05 19:17:18 --> Controller Class Initialized
DEBUG - 2020-09-05 19:17:18 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:17:18 --> Final output sent to browser
DEBUG - 2020-09-05 19:17:18 --> Total execution time: 0.7256
INFO - 2020-09-05 19:17:22 --> Config Class Initialized
INFO - 2020-09-05 19:17:22 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:17:22 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:17:22 --> Utf8 Class Initialized
INFO - 2020-09-05 19:17:22 --> URI Class Initialized
INFO - 2020-09-05 19:17:22 --> Router Class Initialized
INFO - 2020-09-05 19:17:22 --> Output Class Initialized
INFO - 2020-09-05 19:17:22 --> Security Class Initialized
DEBUG - 2020-09-05 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:17:22 --> Input Class Initialized
INFO - 2020-09-05 19:17:22 --> Language Class Initialized
INFO - 2020-09-05 19:17:22 --> Language Class Initialized
INFO - 2020-09-05 19:17:22 --> Config Class Initialized
INFO - 2020-09-05 19:17:22 --> Loader Class Initialized
INFO - 2020-09-05 19:17:22 --> Helper loaded: url_helper
INFO - 2020-09-05 19:17:22 --> Helper loaded: file_helper
INFO - 2020-09-05 19:17:22 --> Database Driver Class Initialized
INFO - 2020-09-05 19:17:22 --> Email Class Initialized
INFO - 2020-09-05 19:17:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:17:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:17:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:17:22 --> Encryption Class Initialized
INFO - 2020-09-05 19:17:22 --> Model Class Initialized
INFO - 2020-09-05 19:17:22 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:17:22 --> Model Class Initialized
INFO - 2020-09-05 19:17:22 --> Model Class Initialized
INFO - 2020-09-05 19:17:22 --> Controller Class Initialized
DEBUG - 2020-09-05 19:17:22 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:17:22 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:17:22 --> Final output sent to browser
DEBUG - 2020-09-05 19:17:22 --> Total execution time: 0.6007
INFO - 2020-09-05 19:17:26 --> Config Class Initialized
INFO - 2020-09-05 19:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:17:26 --> Utf8 Class Initialized
INFO - 2020-09-05 19:17:26 --> URI Class Initialized
INFO - 2020-09-05 19:17:26 --> Router Class Initialized
INFO - 2020-09-05 19:17:26 --> Output Class Initialized
INFO - 2020-09-05 19:17:26 --> Security Class Initialized
DEBUG - 2020-09-05 19:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:17:26 --> Input Class Initialized
INFO - 2020-09-05 19:17:26 --> Language Class Initialized
INFO - 2020-09-05 19:17:26 --> Language Class Initialized
INFO - 2020-09-05 19:17:26 --> Config Class Initialized
INFO - 2020-09-05 19:17:26 --> Loader Class Initialized
INFO - 2020-09-05 19:17:26 --> Helper loaded: url_helper
INFO - 2020-09-05 19:17:26 --> Helper loaded: file_helper
INFO - 2020-09-05 19:17:26 --> Database Driver Class Initialized
INFO - 2020-09-05 19:17:26 --> Email Class Initialized
INFO - 2020-09-05 19:17:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:17:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:17:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:17:26 --> Encryption Class Initialized
INFO - 2020-09-05 19:17:26 --> Model Class Initialized
INFO - 2020-09-05 19:17:26 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:17:26 --> Model Class Initialized
INFO - 2020-09-05 19:17:27 --> Model Class Initialized
INFO - 2020-09-05 19:17:27 --> Controller Class Initialized
DEBUG - 2020-09-05 19:17:27 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:17:27 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:17:27 --> Final output sent to browser
DEBUG - 2020-09-05 19:17:27 --> Total execution time: 0.8238
INFO - 2020-09-05 19:18:18 --> Config Class Initialized
INFO - 2020-09-05 19:18:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:18:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:18:18 --> Utf8 Class Initialized
INFO - 2020-09-05 19:18:18 --> URI Class Initialized
INFO - 2020-09-05 19:18:18 --> Router Class Initialized
INFO - 2020-09-05 19:18:18 --> Output Class Initialized
INFO - 2020-09-05 19:18:18 --> Security Class Initialized
DEBUG - 2020-09-05 19:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:18:18 --> Input Class Initialized
INFO - 2020-09-05 19:18:18 --> Language Class Initialized
INFO - 2020-09-05 19:18:18 --> Language Class Initialized
INFO - 2020-09-05 19:18:18 --> Config Class Initialized
INFO - 2020-09-05 19:18:18 --> Loader Class Initialized
INFO - 2020-09-05 19:18:18 --> Helper loaded: url_helper
INFO - 2020-09-05 19:18:18 --> Helper loaded: file_helper
INFO - 2020-09-05 19:18:18 --> Database Driver Class Initialized
INFO - 2020-09-05 19:18:18 --> Email Class Initialized
INFO - 2020-09-05 19:18:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:18:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:18:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:18:19 --> Encryption Class Initialized
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Controller Class Initialized
DEBUG - 2020-09-05 19:18:19 --> Card MX_Controller Initialized
INFO - 2020-09-05 19:18:19 --> Config Class Initialized
INFO - 2020-09-05 19:18:19 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:18:19 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:18:19 --> Utf8 Class Initialized
INFO - 2020-09-05 19:18:19 --> URI Class Initialized
INFO - 2020-09-05 19:18:19 --> Router Class Initialized
INFO - 2020-09-05 19:18:19 --> Output Class Initialized
INFO - 2020-09-05 19:18:19 --> Security Class Initialized
DEBUG - 2020-09-05 19:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:18:19 --> Input Class Initialized
INFO - 2020-09-05 19:18:19 --> Language Class Initialized
INFO - 2020-09-05 19:18:19 --> Language Class Initialized
INFO - 2020-09-05 19:18:19 --> Config Class Initialized
INFO - 2020-09-05 19:18:19 --> Loader Class Initialized
INFO - 2020-09-05 19:18:19 --> Helper loaded: url_helper
INFO - 2020-09-05 19:18:19 --> Helper loaded: file_helper
INFO - 2020-09-05 19:18:19 --> Database Driver Class Initialized
INFO - 2020-09-05 19:18:19 --> Email Class Initialized
INFO - 2020-09-05 19:18:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:18:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:18:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:18:19 --> Encryption Class Initialized
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Model Class Initialized
INFO - 2020-09-05 19:18:19 --> Controller Class Initialized
DEBUG - 2020-09-05 19:18:19 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:18:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:18:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:18:19 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:18:19 --> Final output sent to browser
DEBUG - 2020-09-05 19:18:19 --> Total execution time: 0.5338
INFO - 2020-09-05 19:18:26 --> Config Class Initialized
INFO - 2020-09-05 19:18:26 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:18:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:18:27 --> Utf8 Class Initialized
INFO - 2020-09-05 19:18:27 --> URI Class Initialized
INFO - 2020-09-05 19:18:27 --> Router Class Initialized
INFO - 2020-09-05 19:18:27 --> Output Class Initialized
INFO - 2020-09-05 19:18:27 --> Security Class Initialized
DEBUG - 2020-09-05 19:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:18:27 --> Input Class Initialized
INFO - 2020-09-05 19:18:27 --> Language Class Initialized
INFO - 2020-09-05 19:18:27 --> Language Class Initialized
INFO - 2020-09-05 19:18:27 --> Config Class Initialized
INFO - 2020-09-05 19:18:27 --> Loader Class Initialized
INFO - 2020-09-05 19:18:27 --> Helper loaded: url_helper
INFO - 2020-09-05 19:18:27 --> Helper loaded: file_helper
INFO - 2020-09-05 19:18:27 --> Database Driver Class Initialized
INFO - 2020-09-05 19:18:27 --> Email Class Initialized
INFO - 2020-09-05 19:18:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:18:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:18:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:18:27 --> Encryption Class Initialized
INFO - 2020-09-05 19:18:27 --> Model Class Initialized
INFO - 2020-09-05 19:18:27 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:18:27 --> Model Class Initialized
INFO - 2020-09-05 19:18:27 --> Model Class Initialized
INFO - 2020-09-05 19:18:27 --> Controller Class Initialized
DEBUG - 2020-09-05 19:18:27 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:18:27 --> Final output sent to browser
DEBUG - 2020-09-05 19:18:27 --> Total execution time: 0.7016
INFO - 2020-09-05 19:18:31 --> Config Class Initialized
INFO - 2020-09-05 19:18:31 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:18:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:18:31 --> Utf8 Class Initialized
INFO - 2020-09-05 19:18:31 --> URI Class Initialized
INFO - 2020-09-05 19:18:31 --> Router Class Initialized
INFO - 2020-09-05 19:18:31 --> Output Class Initialized
INFO - 2020-09-05 19:18:31 --> Security Class Initialized
DEBUG - 2020-09-05 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:18:31 --> Input Class Initialized
INFO - 2020-09-05 19:18:32 --> Language Class Initialized
INFO - 2020-09-05 19:18:32 --> Language Class Initialized
INFO - 2020-09-05 19:18:32 --> Config Class Initialized
INFO - 2020-09-05 19:18:32 --> Loader Class Initialized
INFO - 2020-09-05 19:18:32 --> Helper loaded: url_helper
INFO - 2020-09-05 19:18:32 --> Helper loaded: file_helper
INFO - 2020-09-05 19:18:32 --> Database Driver Class Initialized
INFO - 2020-09-05 19:18:32 --> Email Class Initialized
INFO - 2020-09-05 19:18:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:18:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:18:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:18:32 --> Encryption Class Initialized
INFO - 2020-09-05 19:18:32 --> Model Class Initialized
INFO - 2020-09-05 19:18:32 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:18:32 --> Model Class Initialized
INFO - 2020-09-05 19:18:32 --> Model Class Initialized
INFO - 2020-09-05 19:18:32 --> Controller Class Initialized
DEBUG - 2020-09-05 19:18:32 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:18:32 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:18:32 --> Final output sent to browser
DEBUG - 2020-09-05 19:18:32 --> Total execution time: 0.7842
INFO - 2020-09-05 19:18:45 --> Config Class Initialized
INFO - 2020-09-05 19:18:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:18:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:18:45 --> Utf8 Class Initialized
INFO - 2020-09-05 19:18:45 --> URI Class Initialized
INFO - 2020-09-05 19:18:45 --> Router Class Initialized
INFO - 2020-09-05 19:18:45 --> Output Class Initialized
INFO - 2020-09-05 19:18:45 --> Security Class Initialized
DEBUG - 2020-09-05 19:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:18:45 --> Input Class Initialized
INFO - 2020-09-05 19:18:45 --> Language Class Initialized
INFO - 2020-09-05 19:18:45 --> Language Class Initialized
INFO - 2020-09-05 19:18:45 --> Config Class Initialized
INFO - 2020-09-05 19:18:45 --> Loader Class Initialized
INFO - 2020-09-05 19:18:45 --> Helper loaded: url_helper
INFO - 2020-09-05 19:18:45 --> Helper loaded: file_helper
INFO - 2020-09-05 19:18:45 --> Database Driver Class Initialized
INFO - 2020-09-05 19:18:45 --> Email Class Initialized
INFO - 2020-09-05 19:18:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:18:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:18:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:18:45 --> Encryption Class Initialized
INFO - 2020-09-05 19:18:45 --> Model Class Initialized
INFO - 2020-09-05 19:18:45 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:18:45 --> Model Class Initialized
INFO - 2020-09-05 19:18:45 --> Model Class Initialized
INFO - 2020-09-05 19:18:45 --> Controller Class Initialized
DEBUG - 2020-09-05 19:18:45 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:18:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:18:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:18:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:18:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:18:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:18:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:18:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:18:46 --> Final output sent to browser
DEBUG - 2020-09-05 19:18:46 --> Total execution time: 0.9374
INFO - 2020-09-05 19:19:37 --> Config Class Initialized
INFO - 2020-09-05 19:19:37 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:19:37 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:19:37 --> Utf8 Class Initialized
INFO - 2020-09-05 19:19:37 --> URI Class Initialized
INFO - 2020-09-05 19:19:37 --> Router Class Initialized
INFO - 2020-09-05 19:19:37 --> Output Class Initialized
INFO - 2020-09-05 19:19:37 --> Security Class Initialized
DEBUG - 2020-09-05 19:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:19:37 --> Input Class Initialized
INFO - 2020-09-05 19:19:37 --> Language Class Initialized
INFO - 2020-09-05 19:19:37 --> Language Class Initialized
INFO - 2020-09-05 19:19:38 --> Config Class Initialized
INFO - 2020-09-05 19:19:38 --> Loader Class Initialized
INFO - 2020-09-05 19:19:38 --> Helper loaded: url_helper
INFO - 2020-09-05 19:19:38 --> Helper loaded: file_helper
INFO - 2020-09-05 19:19:38 --> Database Driver Class Initialized
INFO - 2020-09-05 19:19:38 --> Email Class Initialized
INFO - 2020-09-05 19:19:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:19:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:19:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:19:38 --> Encryption Class Initialized
INFO - 2020-09-05 19:19:38 --> Model Class Initialized
INFO - 2020-09-05 19:19:38 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:19:38 --> Model Class Initialized
INFO - 2020-09-05 19:19:38 --> Model Class Initialized
INFO - 2020-09-05 19:19:38 --> Controller Class Initialized
DEBUG - 2020-09-05 19:19:38 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:19:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:19:38 --> Final output sent to browser
DEBUG - 2020-09-05 19:19:38 --> Total execution time: 0.6688
INFO - 2020-09-05 19:19:40 --> Config Class Initialized
INFO - 2020-09-05 19:19:40 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:19:40 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:19:40 --> Utf8 Class Initialized
INFO - 2020-09-05 19:19:40 --> URI Class Initialized
INFO - 2020-09-05 19:19:40 --> Router Class Initialized
INFO - 2020-09-05 19:19:40 --> Output Class Initialized
INFO - 2020-09-05 19:19:40 --> Security Class Initialized
DEBUG - 2020-09-05 19:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:19:40 --> Input Class Initialized
INFO - 2020-09-05 19:19:40 --> Language Class Initialized
INFO - 2020-09-05 19:19:40 --> Language Class Initialized
INFO - 2020-09-05 19:19:40 --> Config Class Initialized
INFO - 2020-09-05 19:19:40 --> Loader Class Initialized
INFO - 2020-09-05 19:19:41 --> Helper loaded: url_helper
INFO - 2020-09-05 19:19:41 --> Helper loaded: file_helper
INFO - 2020-09-05 19:19:41 --> Database Driver Class Initialized
INFO - 2020-09-05 19:19:41 --> Email Class Initialized
INFO - 2020-09-05 19:19:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:19:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:19:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:19:41 --> Encryption Class Initialized
INFO - 2020-09-05 19:19:41 --> Model Class Initialized
INFO - 2020-09-05 19:19:41 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:19:41 --> Model Class Initialized
INFO - 2020-09-05 19:19:41 --> Model Class Initialized
INFO - 2020-09-05 19:19:41 --> Controller Class Initialized
DEBUG - 2020-09-05 19:19:41 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:19:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:19:41 --> Final output sent to browser
DEBUG - 2020-09-05 19:19:41 --> Total execution time: 0.7811
INFO - 2020-09-05 19:23:41 --> Config Class Initialized
INFO - 2020-09-05 19:23:41 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:23:41 --> Utf8 Class Initialized
INFO - 2020-09-05 19:23:41 --> URI Class Initialized
INFO - 2020-09-05 19:23:41 --> Router Class Initialized
INFO - 2020-09-05 19:23:41 --> Output Class Initialized
INFO - 2020-09-05 19:23:41 --> Security Class Initialized
DEBUG - 2020-09-05 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:23:41 --> Input Class Initialized
INFO - 2020-09-05 19:23:41 --> Language Class Initialized
INFO - 2020-09-05 19:23:41 --> Language Class Initialized
INFO - 2020-09-05 19:23:41 --> Config Class Initialized
INFO - 2020-09-05 19:23:41 --> Loader Class Initialized
INFO - 2020-09-05 19:23:41 --> Helper loaded: url_helper
INFO - 2020-09-05 19:23:41 --> Helper loaded: file_helper
INFO - 2020-09-05 19:23:41 --> Database Driver Class Initialized
INFO - 2020-09-05 19:23:41 --> Email Class Initialized
INFO - 2020-09-05 19:23:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:23:41 --> Encryption Class Initialized
INFO - 2020-09-05 19:23:41 --> Model Class Initialized
INFO - 2020-09-05 19:23:41 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:23:41 --> Model Class Initialized
INFO - 2020-09-05 19:23:41 --> Model Class Initialized
INFO - 2020-09-05 19:23:41 --> Controller Class Initialized
DEBUG - 2020-09-05 19:23:41 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:23:41 --> Config Class Initialized
INFO - 2020-09-05 19:23:41 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:23:41 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:23:41 --> Utf8 Class Initialized
INFO - 2020-09-05 19:23:41 --> URI Class Initialized
DEBUG - 2020-09-05 19:23:41 --> No URI present. Default controller set.
INFO - 2020-09-05 19:23:41 --> Router Class Initialized
INFO - 2020-09-05 19:23:42 --> Output Class Initialized
INFO - 2020-09-05 19:23:42 --> Security Class Initialized
DEBUG - 2020-09-05 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:23:42 --> Input Class Initialized
INFO - 2020-09-05 19:23:42 --> Language Class Initialized
INFO - 2020-09-05 19:23:42 --> Language Class Initialized
INFO - 2020-09-05 19:23:42 --> Config Class Initialized
INFO - 2020-09-05 19:23:42 --> Loader Class Initialized
INFO - 2020-09-05 19:23:42 --> Helper loaded: url_helper
INFO - 2020-09-05 19:23:42 --> Helper loaded: file_helper
INFO - 2020-09-05 19:23:42 --> Database Driver Class Initialized
INFO - 2020-09-05 19:23:42 --> Email Class Initialized
INFO - 2020-09-05 19:23:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:23:42 --> Encryption Class Initialized
INFO - 2020-09-05 19:23:42 --> Model Class Initialized
INFO - 2020-09-05 19:23:42 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:23:42 --> Model Class Initialized
INFO - 2020-09-05 19:23:42 --> Model Class Initialized
INFO - 2020-09-05 19:23:42 --> Controller Class Initialized
DEBUG - 2020-09-05 19:23:42 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:23:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:23:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:23:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:23:42 --> Final output sent to browser
DEBUG - 2020-09-05 19:23:42 --> Total execution time: 0.5377
INFO - 2020-09-05 19:24:04 --> Config Class Initialized
INFO - 2020-09-05 19:24:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:05 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:05 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:05 --> URI Class Initialized
INFO - 2020-09-05 19:24:05 --> Router Class Initialized
INFO - 2020-09-05 19:24:05 --> Output Class Initialized
INFO - 2020-09-05 19:24:05 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:05 --> Input Class Initialized
INFO - 2020-09-05 19:24:05 --> Language Class Initialized
INFO - 2020-09-05 19:24:05 --> Language Class Initialized
INFO - 2020-09-05 19:24:05 --> Config Class Initialized
INFO - 2020-09-05 19:24:05 --> Loader Class Initialized
INFO - 2020-09-05 19:24:05 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:05 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:05 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:05 --> Email Class Initialized
INFO - 2020-09-05 19:24:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:05 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:05 --> Model Class Initialized
INFO - 2020-09-05 19:24:05 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:05 --> Model Class Initialized
INFO - 2020-09-05 19:24:05 --> Model Class Initialized
INFO - 2020-09-05 19:24:05 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:05 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:24:05 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:05 --> Total execution time: 0.4777
INFO - 2020-09-05 19:24:13 --> Config Class Initialized
INFO - 2020-09-05 19:24:13 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:13 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:13 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:13 --> URI Class Initialized
INFO - 2020-09-05 19:24:13 --> Router Class Initialized
INFO - 2020-09-05 19:24:13 --> Output Class Initialized
INFO - 2020-09-05 19:24:13 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:13 --> Input Class Initialized
INFO - 2020-09-05 19:24:13 --> Language Class Initialized
INFO - 2020-09-05 19:24:13 --> Language Class Initialized
INFO - 2020-09-05 19:24:13 --> Config Class Initialized
INFO - 2020-09-05 19:24:13 --> Loader Class Initialized
INFO - 2020-09-05 19:24:13 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:13 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:13 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:13 --> Email Class Initialized
INFO - 2020-09-05 19:24:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:13 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:13 --> Model Class Initialized
INFO - 2020-09-05 19:24:13 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:14 --> Model Class Initialized
INFO - 2020-09-05 19:24:14 --> Model Class Initialized
INFO - 2020-09-05 19:24:14 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:14 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:24:14 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:14 --> Total execution time: 0.5762
INFO - 2020-09-05 19:24:17 --> Config Class Initialized
INFO - 2020-09-05 19:24:17 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:17 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:17 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:17 --> URI Class Initialized
INFO - 2020-09-05 19:24:17 --> Router Class Initialized
INFO - 2020-09-05 19:24:17 --> Output Class Initialized
INFO - 2020-09-05 19:24:17 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:17 --> Input Class Initialized
INFO - 2020-09-05 19:24:17 --> Language Class Initialized
INFO - 2020-09-05 19:24:17 --> Language Class Initialized
INFO - 2020-09-05 19:24:17 --> Config Class Initialized
INFO - 2020-09-05 19:24:17 --> Loader Class Initialized
INFO - 2020-09-05 19:24:17 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:17 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:17 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:17 --> Email Class Initialized
INFO - 2020-09-05 19:24:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:17 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:17 --> Model Class Initialized
INFO - 2020-09-05 19:24:17 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:17 --> Model Class Initialized
INFO - 2020-09-05 19:24:17 --> Model Class Initialized
INFO - 2020-09-05 19:24:17 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:17 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:24:17 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:24:17 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:17 --> Total execution time: 0.6715
INFO - 2020-09-05 19:24:48 --> Config Class Initialized
INFO - 2020-09-05 19:24:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:48 --> URI Class Initialized
INFO - 2020-09-05 19:24:48 --> Router Class Initialized
INFO - 2020-09-05 19:24:48 --> Output Class Initialized
INFO - 2020-09-05 19:24:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:48 --> Input Class Initialized
INFO - 2020-09-05 19:24:48 --> Language Class Initialized
INFO - 2020-09-05 19:24:48 --> Language Class Initialized
INFO - 2020-09-05 19:24:48 --> Config Class Initialized
INFO - 2020-09-05 19:24:48 --> Loader Class Initialized
INFO - 2020-09-05 19:24:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:48 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:48 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:48 --> Email Class Initialized
INFO - 2020-09-05 19:24:48 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:48 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:48 --> Model Class Initialized
INFO - 2020-09-05 19:24:48 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:48 --> Model Class Initialized
INFO - 2020-09-05 19:24:48 --> Model Class Initialized
INFO - 2020-09-05 19:24:48 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:48 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:24:48 --> Config Class Initialized
INFO - 2020-09-05 19:24:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:48 --> URI Class Initialized
DEBUG - 2020-09-05 19:24:48 --> No URI present. Default controller set.
INFO - 2020-09-05 19:24:48 --> Router Class Initialized
INFO - 2020-09-05 19:24:48 --> Output Class Initialized
INFO - 2020-09-05 19:24:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:48 --> Input Class Initialized
INFO - 2020-09-05 19:24:48 --> Language Class Initialized
INFO - 2020-09-05 19:24:48 --> Language Class Initialized
INFO - 2020-09-05 19:24:49 --> Config Class Initialized
INFO - 2020-09-05 19:24:49 --> Loader Class Initialized
INFO - 2020-09-05 19:24:49 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:49 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:49 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:49 --> Email Class Initialized
INFO - 2020-09-05 19:24:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:49 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:49 --> Model Class Initialized
INFO - 2020-09-05 19:24:49 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:49 --> Model Class Initialized
INFO - 2020-09-05 19:24:49 --> Model Class Initialized
INFO - 2020-09-05 19:24:49 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:49 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:24:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:24:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:24:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:24:49 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:49 --> Total execution time: 0.5356
INFO - 2020-09-05 19:24:50 --> Config Class Initialized
INFO - 2020-09-05 19:24:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:50 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:50 --> URI Class Initialized
DEBUG - 2020-09-05 19:24:50 --> No URI present. Default controller set.
INFO - 2020-09-05 19:24:50 --> Router Class Initialized
INFO - 2020-09-05 19:24:50 --> Output Class Initialized
INFO - 2020-09-05 19:24:50 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:50 --> Input Class Initialized
INFO - 2020-09-05 19:24:50 --> Language Class Initialized
INFO - 2020-09-05 19:24:50 --> Language Class Initialized
INFO - 2020-09-05 19:24:50 --> Config Class Initialized
INFO - 2020-09-05 19:24:50 --> Loader Class Initialized
INFO - 2020-09-05 19:24:50 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:50 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:50 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:50 --> Email Class Initialized
INFO - 2020-09-05 19:24:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:50 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:50 --> Model Class Initialized
INFO - 2020-09-05 19:24:50 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:50 --> Model Class Initialized
INFO - 2020-09-05 19:24:50 --> Model Class Initialized
INFO - 2020-09-05 19:24:50 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:50 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:24:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:24:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:24:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:24:50 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:50 --> Total execution time: 0.5295
INFO - 2020-09-05 19:24:52 --> Config Class Initialized
INFO - 2020-09-05 19:24:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:52 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:52 --> URI Class Initialized
DEBUG - 2020-09-05 19:24:52 --> No URI present. Default controller set.
INFO - 2020-09-05 19:24:52 --> Router Class Initialized
INFO - 2020-09-05 19:24:52 --> Output Class Initialized
INFO - 2020-09-05 19:24:52 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:52 --> Input Class Initialized
INFO - 2020-09-05 19:24:52 --> Language Class Initialized
INFO - 2020-09-05 19:24:52 --> Language Class Initialized
INFO - 2020-09-05 19:24:52 --> Config Class Initialized
INFO - 2020-09-05 19:24:52 --> Loader Class Initialized
INFO - 2020-09-05 19:24:52 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:52 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:52 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:52 --> Email Class Initialized
INFO - 2020-09-05 19:24:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:53 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:53 --> Model Class Initialized
INFO - 2020-09-05 19:24:53 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:53 --> Model Class Initialized
INFO - 2020-09-05 19:24:53 --> Model Class Initialized
INFO - 2020-09-05 19:24:53 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:53 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:24:53 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:24:53 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:24:53 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:24:53 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:53 --> Total execution time: 0.5863
INFO - 2020-09-05 19:24:59 --> Config Class Initialized
INFO - 2020-09-05 19:24:59 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:24:59 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:24:59 --> Utf8 Class Initialized
INFO - 2020-09-05 19:24:59 --> URI Class Initialized
INFO - 2020-09-05 19:24:59 --> Router Class Initialized
INFO - 2020-09-05 19:24:59 --> Output Class Initialized
INFO - 2020-09-05 19:24:59 --> Security Class Initialized
DEBUG - 2020-09-05 19:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:24:59 --> Input Class Initialized
INFO - 2020-09-05 19:24:59 --> Language Class Initialized
INFO - 2020-09-05 19:24:59 --> Language Class Initialized
INFO - 2020-09-05 19:24:59 --> Config Class Initialized
INFO - 2020-09-05 19:24:59 --> Loader Class Initialized
INFO - 2020-09-05 19:24:59 --> Helper loaded: url_helper
INFO - 2020-09-05 19:24:59 --> Helper loaded: file_helper
INFO - 2020-09-05 19:24:59 --> Database Driver Class Initialized
INFO - 2020-09-05 19:24:59 --> Email Class Initialized
INFO - 2020-09-05 19:24:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:24:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:24:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:24:59 --> Encryption Class Initialized
INFO - 2020-09-05 19:24:59 --> Model Class Initialized
INFO - 2020-09-05 19:24:59 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:24:59 --> Model Class Initialized
INFO - 2020-09-05 19:24:59 --> Model Class Initialized
INFO - 2020-09-05 19:24:59 --> Controller Class Initialized
DEBUG - 2020-09-05 19:24:59 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:24:59 --> Final output sent to browser
DEBUG - 2020-09-05 19:24:59 --> Total execution time: 0.4966
INFO - 2020-09-05 19:25:03 --> Config Class Initialized
INFO - 2020-09-05 19:25:03 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:03 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:03 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:03 --> URI Class Initialized
INFO - 2020-09-05 19:25:03 --> Router Class Initialized
INFO - 2020-09-05 19:25:03 --> Output Class Initialized
INFO - 2020-09-05 19:25:03 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:03 --> Input Class Initialized
INFO - 2020-09-05 19:25:03 --> Language Class Initialized
INFO - 2020-09-05 19:25:03 --> Language Class Initialized
INFO - 2020-09-05 19:25:03 --> Config Class Initialized
INFO - 2020-09-05 19:25:03 --> Loader Class Initialized
INFO - 2020-09-05 19:25:03 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:03 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:03 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:03 --> Email Class Initialized
INFO - 2020-09-05 19:25:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:03 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:03 --> Model Class Initialized
INFO - 2020-09-05 19:25:03 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:03 --> Model Class Initialized
INFO - 2020-09-05 19:25:03 --> Model Class Initialized
INFO - 2020-09-05 19:25:03 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:03 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:25:03 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:25:03 --> Final output sent to browser
DEBUG - 2020-09-05 19:25:03 --> Total execution time: 0.6273
INFO - 2020-09-05 19:25:34 --> Config Class Initialized
INFO - 2020-09-05 19:25:34 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:34 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:34 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:34 --> URI Class Initialized
INFO - 2020-09-05 19:25:34 --> Router Class Initialized
INFO - 2020-09-05 19:25:34 --> Output Class Initialized
INFO - 2020-09-05 19:25:34 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:35 --> Input Class Initialized
INFO - 2020-09-05 19:25:35 --> Language Class Initialized
INFO - 2020-09-05 19:25:35 --> Language Class Initialized
INFO - 2020-09-05 19:25:35 --> Config Class Initialized
INFO - 2020-09-05 19:25:35 --> Loader Class Initialized
INFO - 2020-09-05 19:25:35 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:35 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:35 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:35 --> Email Class Initialized
INFO - 2020-09-05 19:25:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:35 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:35 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:25:35 --> Config Class Initialized
INFO - 2020-09-05 19:25:35 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:35 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:35 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:35 --> URI Class Initialized
DEBUG - 2020-09-05 19:25:35 --> No URI present. Default controller set.
INFO - 2020-09-05 19:25:35 --> Router Class Initialized
INFO - 2020-09-05 19:25:35 --> Output Class Initialized
INFO - 2020-09-05 19:25:35 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:35 --> Input Class Initialized
INFO - 2020-09-05 19:25:35 --> Language Class Initialized
INFO - 2020-09-05 19:25:35 --> Language Class Initialized
INFO - 2020-09-05 19:25:35 --> Config Class Initialized
INFO - 2020-09-05 19:25:35 --> Loader Class Initialized
INFO - 2020-09-05 19:25:35 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:35 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:35 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:35 --> Email Class Initialized
INFO - 2020-09-05 19:25:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:35 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Model Class Initialized
INFO - 2020-09-05 19:25:35 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:35 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:25:35 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:25:35 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:25:35 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:25:35 --> Final output sent to browser
DEBUG - 2020-09-05 19:25:35 --> Total execution time: 0.5422
INFO - 2020-09-05 19:25:37 --> Config Class Initialized
INFO - 2020-09-05 19:25:37 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:37 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:37 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:37 --> URI Class Initialized
DEBUG - 2020-09-05 19:25:37 --> No URI present. Default controller set.
INFO - 2020-09-05 19:25:37 --> Router Class Initialized
INFO - 2020-09-05 19:25:37 --> Output Class Initialized
INFO - 2020-09-05 19:25:38 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:38 --> Input Class Initialized
INFO - 2020-09-05 19:25:38 --> Language Class Initialized
INFO - 2020-09-05 19:25:38 --> Language Class Initialized
INFO - 2020-09-05 19:25:38 --> Config Class Initialized
INFO - 2020-09-05 19:25:38 --> Loader Class Initialized
INFO - 2020-09-05 19:25:38 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:38 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:38 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:38 --> Email Class Initialized
INFO - 2020-09-05 19:25:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:38 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:38 --> Model Class Initialized
INFO - 2020-09-05 19:25:38 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:38 --> Model Class Initialized
INFO - 2020-09-05 19:25:38 --> Model Class Initialized
INFO - 2020-09-05 19:25:38 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:38 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:25:38 --> Final output sent to browser
DEBUG - 2020-09-05 19:25:38 --> Total execution time: 0.7052
INFO - 2020-09-05 19:25:44 --> Config Class Initialized
INFO - 2020-09-05 19:25:44 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:44 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:44 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:44 --> URI Class Initialized
INFO - 2020-09-05 19:25:44 --> Router Class Initialized
INFO - 2020-09-05 19:25:44 --> Output Class Initialized
INFO - 2020-09-05 19:25:44 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:44 --> Input Class Initialized
INFO - 2020-09-05 19:25:44 --> Language Class Initialized
INFO - 2020-09-05 19:25:44 --> Language Class Initialized
INFO - 2020-09-05 19:25:44 --> Config Class Initialized
INFO - 2020-09-05 19:25:44 --> Loader Class Initialized
INFO - 2020-09-05 19:25:44 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:44 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:44 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:44 --> Email Class Initialized
INFO - 2020-09-05 19:25:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:44 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:44 --> Model Class Initialized
INFO - 2020-09-05 19:25:44 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:44 --> Model Class Initialized
INFO - 2020-09-05 19:25:44 --> Model Class Initialized
INFO - 2020-09-05 19:25:44 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:44 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:25:44 --> Final output sent to browser
DEBUG - 2020-09-05 19:25:44 --> Total execution time: 0.5061
INFO - 2020-09-05 19:25:48 --> Config Class Initialized
INFO - 2020-09-05 19:25:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:25:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:25:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:25:48 --> URI Class Initialized
INFO - 2020-09-05 19:25:48 --> Router Class Initialized
INFO - 2020-09-05 19:25:48 --> Output Class Initialized
INFO - 2020-09-05 19:25:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:25:48 --> Input Class Initialized
INFO - 2020-09-05 19:25:48 --> Language Class Initialized
INFO - 2020-09-05 19:25:48 --> Language Class Initialized
INFO - 2020-09-05 19:25:48 --> Config Class Initialized
INFO - 2020-09-05 19:25:48 --> Loader Class Initialized
INFO - 2020-09-05 19:25:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:25:48 --> Helper loaded: file_helper
INFO - 2020-09-05 19:25:48 --> Database Driver Class Initialized
INFO - 2020-09-05 19:25:48 --> Email Class Initialized
INFO - 2020-09-05 19:25:48 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:25:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:25:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:25:48 --> Encryption Class Initialized
INFO - 2020-09-05 19:25:48 --> Model Class Initialized
INFO - 2020-09-05 19:25:48 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:25:48 --> Model Class Initialized
INFO - 2020-09-05 19:25:48 --> Model Class Initialized
INFO - 2020-09-05 19:25:48 --> Controller Class Initialized
DEBUG - 2020-09-05 19:25:48 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:25:48 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:25:48 --> Final output sent to browser
DEBUG - 2020-09-05 19:25:48 --> Total execution time: 0.6275
INFO - 2020-09-05 19:27:12 --> Config Class Initialized
INFO - 2020-09-05 19:27:12 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:27:12 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:27:12 --> Utf8 Class Initialized
INFO - 2020-09-05 19:27:12 --> URI Class Initialized
INFO - 2020-09-05 19:27:12 --> Router Class Initialized
INFO - 2020-09-05 19:27:12 --> Output Class Initialized
INFO - 2020-09-05 19:27:12 --> Security Class Initialized
DEBUG - 2020-09-05 19:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:27:12 --> Input Class Initialized
INFO - 2020-09-05 19:27:12 --> Language Class Initialized
INFO - 2020-09-05 19:27:12 --> Language Class Initialized
INFO - 2020-09-05 19:27:12 --> Config Class Initialized
INFO - 2020-09-05 19:27:12 --> Loader Class Initialized
INFO - 2020-09-05 19:27:12 --> Helper loaded: url_helper
INFO - 2020-09-05 19:27:12 --> Helper loaded: file_helper
INFO - 2020-09-05 19:27:13 --> Database Driver Class Initialized
INFO - 2020-09-05 19:27:13 --> Email Class Initialized
INFO - 2020-09-05 19:27:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:27:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:27:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:27:13 --> Encryption Class Initialized
INFO - 2020-09-05 19:27:13 --> Model Class Initialized
INFO - 2020-09-05 19:27:13 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:27:13 --> Model Class Initialized
INFO - 2020-09-05 19:27:13 --> Model Class Initialized
INFO - 2020-09-05 19:27:13 --> Controller Class Initialized
DEBUG - 2020-09-05 19:27:13 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:27:13 --> Config Class Initialized
INFO - 2020-09-05 19:27:13 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:27:13 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:27:13 --> Utf8 Class Initialized
INFO - 2020-09-05 19:27:13 --> URI Class Initialized
DEBUG - 2020-09-05 19:27:13 --> No URI present. Default controller set.
INFO - 2020-09-05 19:27:13 --> Router Class Initialized
INFO - 2020-09-05 19:27:13 --> Output Class Initialized
INFO - 2020-09-05 19:27:13 --> Security Class Initialized
DEBUG - 2020-09-05 19:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:27:13 --> Input Class Initialized
INFO - 2020-09-05 19:27:13 --> Language Class Initialized
INFO - 2020-09-05 19:27:13 --> Language Class Initialized
INFO - 2020-09-05 19:27:13 --> Config Class Initialized
INFO - 2020-09-05 19:27:13 --> Loader Class Initialized
INFO - 2020-09-05 19:27:13 --> Helper loaded: url_helper
INFO - 2020-09-05 19:27:13 --> Helper loaded: file_helper
INFO - 2020-09-05 19:27:13 --> Database Driver Class Initialized
INFO - 2020-09-05 19:27:13 --> Email Class Initialized
INFO - 2020-09-05 19:27:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:27:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:27:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:27:13 --> Encryption Class Initialized
INFO - 2020-09-05 19:27:14 --> Model Class Initialized
INFO - 2020-09-05 19:27:14 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:27:14 --> Model Class Initialized
INFO - 2020-09-05 19:27:14 --> Model Class Initialized
INFO - 2020-09-05 19:27:14 --> Controller Class Initialized
DEBUG - 2020-09-05 19:27:14 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:27:14 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:27:14 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:27:14 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:27:14 --> Final output sent to browser
DEBUG - 2020-09-05 19:27:14 --> Total execution time: 1.0166
INFO - 2020-09-05 19:27:24 --> Config Class Initialized
INFO - 2020-09-05 19:27:24 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:27:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:27:24 --> Utf8 Class Initialized
INFO - 2020-09-05 19:27:24 --> URI Class Initialized
DEBUG - 2020-09-05 19:27:24 --> No URI present. Default controller set.
INFO - 2020-09-05 19:27:24 --> Router Class Initialized
INFO - 2020-09-05 19:27:24 --> Output Class Initialized
INFO - 2020-09-05 19:27:24 --> Security Class Initialized
DEBUG - 2020-09-05 19:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:27:24 --> Input Class Initialized
INFO - 2020-09-05 19:27:24 --> Language Class Initialized
INFO - 2020-09-05 19:27:24 --> Language Class Initialized
INFO - 2020-09-05 19:27:24 --> Config Class Initialized
INFO - 2020-09-05 19:27:24 --> Loader Class Initialized
INFO - 2020-09-05 19:27:24 --> Helper loaded: url_helper
INFO - 2020-09-05 19:27:24 --> Helper loaded: file_helper
INFO - 2020-09-05 19:27:24 --> Database Driver Class Initialized
INFO - 2020-09-05 19:27:24 --> Email Class Initialized
INFO - 2020-09-05 19:27:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:27:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:27:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:27:24 --> Encryption Class Initialized
INFO - 2020-09-05 19:27:24 --> Model Class Initialized
INFO - 2020-09-05 19:27:24 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:27:24 --> Model Class Initialized
INFO - 2020-09-05 19:27:24 --> Model Class Initialized
INFO - 2020-09-05 19:27:24 --> Controller Class Initialized
DEBUG - 2020-09-05 19:27:24 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:27:24 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:27:24 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:27:24 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:27:24 --> Final output sent to browser
DEBUG - 2020-09-05 19:27:25 --> Total execution time: 0.6031
INFO - 2020-09-05 19:27:50 --> Config Class Initialized
INFO - 2020-09-05 19:27:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:27:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:27:50 --> Utf8 Class Initialized
INFO - 2020-09-05 19:27:50 --> URI Class Initialized
INFO - 2020-09-05 19:27:50 --> Router Class Initialized
INFO - 2020-09-05 19:27:50 --> Output Class Initialized
INFO - 2020-09-05 19:27:50 --> Security Class Initialized
DEBUG - 2020-09-05 19:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:27:50 --> Input Class Initialized
INFO - 2020-09-05 19:27:50 --> Language Class Initialized
INFO - 2020-09-05 19:27:50 --> Language Class Initialized
INFO - 2020-09-05 19:27:50 --> Config Class Initialized
INFO - 2020-09-05 19:27:50 --> Loader Class Initialized
INFO - 2020-09-05 19:27:50 --> Helper loaded: url_helper
INFO - 2020-09-05 19:27:50 --> Helper loaded: file_helper
INFO - 2020-09-05 19:27:50 --> Database Driver Class Initialized
INFO - 2020-09-05 19:27:50 --> Email Class Initialized
INFO - 2020-09-05 19:27:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:27:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:27:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:27:50 --> Encryption Class Initialized
INFO - 2020-09-05 19:27:50 --> Model Class Initialized
INFO - 2020-09-05 19:27:51 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:27:51 --> Model Class Initialized
INFO - 2020-09-05 19:27:51 --> Model Class Initialized
INFO - 2020-09-05 19:27:51 --> Controller Class Initialized
DEBUG - 2020-09-05 19:27:51 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:27:51 --> Final output sent to browser
DEBUG - 2020-09-05 19:27:51 --> Total execution time: 0.6441
INFO - 2020-09-05 19:27:56 --> Config Class Initialized
INFO - 2020-09-05 19:27:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:27:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:27:56 --> Utf8 Class Initialized
INFO - 2020-09-05 19:27:56 --> URI Class Initialized
INFO - 2020-09-05 19:27:56 --> Router Class Initialized
INFO - 2020-09-05 19:27:56 --> Output Class Initialized
INFO - 2020-09-05 19:27:56 --> Security Class Initialized
DEBUG - 2020-09-05 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:27:56 --> Input Class Initialized
INFO - 2020-09-05 19:27:56 --> Language Class Initialized
INFO - 2020-09-05 19:27:56 --> Language Class Initialized
INFO - 2020-09-05 19:27:56 --> Config Class Initialized
INFO - 2020-09-05 19:27:56 --> Loader Class Initialized
INFO - 2020-09-05 19:27:56 --> Helper loaded: url_helper
INFO - 2020-09-05 19:27:56 --> Helper loaded: file_helper
INFO - 2020-09-05 19:27:56 --> Database Driver Class Initialized
INFO - 2020-09-05 19:27:56 --> Email Class Initialized
INFO - 2020-09-05 19:27:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:27:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:27:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:27:56 --> Encryption Class Initialized
INFO - 2020-09-05 19:27:56 --> Model Class Initialized
INFO - 2020-09-05 19:27:56 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:27:56 --> Model Class Initialized
INFO - 2020-09-05 19:27:56 --> Model Class Initialized
INFO - 2020-09-05 19:27:56 --> Controller Class Initialized
DEBUG - 2020-09-05 19:27:56 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:27:56 --> Final output sent to browser
DEBUG - 2020-09-05 19:27:56 --> Total execution time: 0.5170
INFO - 2020-09-05 19:28:04 --> Config Class Initialized
INFO - 2020-09-05 19:28:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:04 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:04 --> URI Class Initialized
INFO - 2020-09-05 19:28:04 --> Router Class Initialized
INFO - 2020-09-05 19:28:04 --> Output Class Initialized
INFO - 2020-09-05 19:28:04 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:04 --> Input Class Initialized
INFO - 2020-09-05 19:28:04 --> Language Class Initialized
INFO - 2020-09-05 19:28:04 --> Language Class Initialized
INFO - 2020-09-05 19:28:04 --> Config Class Initialized
INFO - 2020-09-05 19:28:04 --> Loader Class Initialized
INFO - 2020-09-05 19:28:04 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:04 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:04 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:04 --> Email Class Initialized
INFO - 2020-09-05 19:28:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:04 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:04 --> Model Class Initialized
INFO - 2020-09-05 19:28:04 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:04 --> Model Class Initialized
INFO - 2020-09-05 19:28:04 --> Model Class Initialized
INFO - 2020-09-05 19:28:04 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:04 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:28:04 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:04 --> Total execution time: 0.5158
INFO - 2020-09-05 19:28:08 --> Config Class Initialized
INFO - 2020-09-05 19:28:08 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:08 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:08 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:08 --> URI Class Initialized
INFO - 2020-09-05 19:28:08 --> Router Class Initialized
INFO - 2020-09-05 19:28:08 --> Output Class Initialized
INFO - 2020-09-05 19:28:08 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:08 --> Input Class Initialized
INFO - 2020-09-05 19:28:08 --> Language Class Initialized
INFO - 2020-09-05 19:28:08 --> Language Class Initialized
INFO - 2020-09-05 19:28:08 --> Config Class Initialized
INFO - 2020-09-05 19:28:08 --> Loader Class Initialized
INFO - 2020-09-05 19:28:08 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:08 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:08 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:08 --> Email Class Initialized
INFO - 2020-09-05 19:28:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:08 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:08 --> Model Class Initialized
INFO - 2020-09-05 19:28:08 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:08 --> Model Class Initialized
INFO - 2020-09-05 19:28:08 --> Model Class Initialized
INFO - 2020-09-05 19:28:08 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:08 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:28:08 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:28:08 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:08 --> Total execution time: 0.7310
INFO - 2020-09-05 19:28:36 --> Config Class Initialized
INFO - 2020-09-05 19:28:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:36 --> URI Class Initialized
INFO - 2020-09-05 19:28:36 --> Router Class Initialized
INFO - 2020-09-05 19:28:36 --> Output Class Initialized
INFO - 2020-09-05 19:28:36 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:36 --> Input Class Initialized
INFO - 2020-09-05 19:28:36 --> Language Class Initialized
INFO - 2020-09-05 19:28:36 --> Language Class Initialized
INFO - 2020-09-05 19:28:36 --> Config Class Initialized
INFO - 2020-09-05 19:28:36 --> Loader Class Initialized
INFO - 2020-09-05 19:28:36 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:36 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:36 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:36 --> Email Class Initialized
INFO - 2020-09-05 19:28:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:36 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:36 --> Model Class Initialized
INFO - 2020-09-05 19:28:36 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:36 --> Model Class Initialized
INFO - 2020-09-05 19:28:36 --> Model Class Initialized
INFO - 2020-09-05 19:28:36 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:36 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:28:37 --> Config Class Initialized
INFO - 2020-09-05 19:28:37 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:37 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:37 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:38 --> URI Class Initialized
DEBUG - 2020-09-05 19:28:38 --> No URI present. Default controller set.
INFO - 2020-09-05 19:28:38 --> Router Class Initialized
INFO - 2020-09-05 19:28:38 --> Output Class Initialized
INFO - 2020-09-05 19:28:38 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:38 --> Input Class Initialized
INFO - 2020-09-05 19:28:38 --> Language Class Initialized
INFO - 2020-09-05 19:28:38 --> Language Class Initialized
INFO - 2020-09-05 19:28:38 --> Config Class Initialized
INFO - 2020-09-05 19:28:38 --> Loader Class Initialized
INFO - 2020-09-05 19:28:38 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:38 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:38 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:38 --> Email Class Initialized
INFO - 2020-09-05 19:28:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:38 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:38 --> Model Class Initialized
INFO - 2020-09-05 19:28:38 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:38 --> Model Class Initialized
INFO - 2020-09-05 19:28:38 --> Model Class Initialized
INFO - 2020-09-05 19:28:38 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:38 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:28:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:28:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:28:38 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:28:38 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:38 --> Total execution time: 0.5569
INFO - 2020-09-05 19:28:46 --> Config Class Initialized
INFO - 2020-09-05 19:28:46 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:46 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:46 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:46 --> URI Class Initialized
INFO - 2020-09-05 19:28:46 --> Router Class Initialized
INFO - 2020-09-05 19:28:46 --> Output Class Initialized
INFO - 2020-09-05 19:28:46 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:46 --> Input Class Initialized
INFO - 2020-09-05 19:28:46 --> Language Class Initialized
INFO - 2020-09-05 19:28:46 --> Language Class Initialized
INFO - 2020-09-05 19:28:46 --> Config Class Initialized
INFO - 2020-09-05 19:28:46 --> Loader Class Initialized
INFO - 2020-09-05 19:28:46 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:46 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:46 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:46 --> Email Class Initialized
INFO - 2020-09-05 19:28:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:47 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:47 --> Model Class Initialized
INFO - 2020-09-05 19:28:47 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:47 --> Model Class Initialized
INFO - 2020-09-05 19:28:47 --> Model Class Initialized
INFO - 2020-09-05 19:28:47 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:47 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:28:47 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:47 --> Total execution time: 0.6483
INFO - 2020-09-05 19:28:52 --> Config Class Initialized
INFO - 2020-09-05 19:28:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:52 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:52 --> URI Class Initialized
INFO - 2020-09-05 19:28:52 --> Router Class Initialized
INFO - 2020-09-05 19:28:52 --> Output Class Initialized
INFO - 2020-09-05 19:28:52 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:52 --> Input Class Initialized
INFO - 2020-09-05 19:28:52 --> Language Class Initialized
INFO - 2020-09-05 19:28:52 --> Language Class Initialized
INFO - 2020-09-05 19:28:52 --> Config Class Initialized
INFO - 2020-09-05 19:28:52 --> Loader Class Initialized
INFO - 2020-09-05 19:28:52 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:52 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:52 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:52 --> Email Class Initialized
INFO - 2020-09-05 19:28:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:52 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:52 --> Model Class Initialized
INFO - 2020-09-05 19:28:52 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:52 --> Model Class Initialized
INFO - 2020-09-05 19:28:53 --> Model Class Initialized
INFO - 2020-09-05 19:28:53 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:53 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:28:53 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:53 --> Total execution time: 0.4604
INFO - 2020-09-05 19:28:56 --> Config Class Initialized
INFO - 2020-09-05 19:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:28:56 --> Utf8 Class Initialized
INFO - 2020-09-05 19:28:56 --> URI Class Initialized
INFO - 2020-09-05 19:28:56 --> Router Class Initialized
INFO - 2020-09-05 19:28:56 --> Output Class Initialized
INFO - 2020-09-05 19:28:56 --> Security Class Initialized
DEBUG - 2020-09-05 19:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:28:56 --> Input Class Initialized
INFO - 2020-09-05 19:28:56 --> Language Class Initialized
INFO - 2020-09-05 19:28:56 --> Language Class Initialized
INFO - 2020-09-05 19:28:56 --> Config Class Initialized
INFO - 2020-09-05 19:28:56 --> Loader Class Initialized
INFO - 2020-09-05 19:28:56 --> Helper loaded: url_helper
INFO - 2020-09-05 19:28:56 --> Helper loaded: file_helper
INFO - 2020-09-05 19:28:56 --> Database Driver Class Initialized
INFO - 2020-09-05 19:28:56 --> Email Class Initialized
INFO - 2020-09-05 19:28:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:28:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:28:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:28:56 --> Encryption Class Initialized
INFO - 2020-09-05 19:28:56 --> Model Class Initialized
INFO - 2020-09-05 19:28:56 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:28:56 --> Model Class Initialized
INFO - 2020-09-05 19:28:56 --> Model Class Initialized
INFO - 2020-09-05 19:28:56 --> Controller Class Initialized
DEBUG - 2020-09-05 19:28:56 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:28:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:28:56 --> Final output sent to browser
DEBUG - 2020-09-05 19:28:56 --> Total execution time: 0.6386
INFO - 2020-09-05 19:29:36 --> Config Class Initialized
INFO - 2020-09-05 19:29:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:29:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:29:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:29:36 --> URI Class Initialized
INFO - 2020-09-05 19:29:36 --> Router Class Initialized
INFO - 2020-09-05 19:29:36 --> Output Class Initialized
INFO - 2020-09-05 19:29:36 --> Security Class Initialized
DEBUG - 2020-09-05 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:29:36 --> Input Class Initialized
INFO - 2020-09-05 19:29:36 --> Language Class Initialized
INFO - 2020-09-05 19:29:36 --> Language Class Initialized
INFO - 2020-09-05 19:29:36 --> Config Class Initialized
INFO - 2020-09-05 19:29:36 --> Loader Class Initialized
INFO - 2020-09-05 19:29:36 --> Helper loaded: url_helper
INFO - 2020-09-05 19:29:36 --> Helper loaded: file_helper
INFO - 2020-09-05 19:29:36 --> Database Driver Class Initialized
INFO - 2020-09-05 19:29:36 --> Email Class Initialized
INFO - 2020-09-05 19:29:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:29:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:29:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:29:36 --> Encryption Class Initialized
INFO - 2020-09-05 19:29:36 --> Model Class Initialized
INFO - 2020-09-05 19:29:36 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:29:36 --> Model Class Initialized
INFO - 2020-09-05 19:29:36 --> Model Class Initialized
INFO - 2020-09-05 19:29:36 --> Controller Class Initialized
DEBUG - 2020-09-05 19:29:36 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:29:36 --> Config Class Initialized
INFO - 2020-09-05 19:29:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:29:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:29:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:29:36 --> URI Class Initialized
DEBUG - 2020-09-05 19:29:36 --> No URI present. Default controller set.
INFO - 2020-09-05 19:29:36 --> Router Class Initialized
INFO - 2020-09-05 19:29:36 --> Output Class Initialized
INFO - 2020-09-05 19:29:36 --> Security Class Initialized
DEBUG - 2020-09-05 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:29:36 --> Input Class Initialized
INFO - 2020-09-05 19:29:36 --> Language Class Initialized
INFO - 2020-09-05 19:29:36 --> Language Class Initialized
INFO - 2020-09-05 19:29:36 --> Config Class Initialized
INFO - 2020-09-05 19:29:36 --> Loader Class Initialized
INFO - 2020-09-05 19:29:36 --> Helper loaded: url_helper
INFO - 2020-09-05 19:29:36 --> Helper loaded: file_helper
INFO - 2020-09-05 19:29:36 --> Database Driver Class Initialized
INFO - 2020-09-05 19:29:37 --> Email Class Initialized
INFO - 2020-09-05 19:29:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:29:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:29:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:29:37 --> Encryption Class Initialized
INFO - 2020-09-05 19:29:37 --> Model Class Initialized
INFO - 2020-09-05 19:29:37 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:29:37 --> Model Class Initialized
INFO - 2020-09-05 19:29:37 --> Model Class Initialized
INFO - 2020-09-05 19:29:37 --> Controller Class Initialized
DEBUG - 2020-09-05 19:29:37 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:29:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:29:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:29:37 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:29:37 --> Final output sent to browser
DEBUG - 2020-09-05 19:29:37 --> Total execution time: 0.5789
INFO - 2020-09-05 19:29:46 --> Config Class Initialized
INFO - 2020-09-05 19:29:46 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:29:46 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:29:46 --> Utf8 Class Initialized
INFO - 2020-09-05 19:29:46 --> URI Class Initialized
INFO - 2020-09-05 19:29:46 --> Router Class Initialized
INFO - 2020-09-05 19:29:46 --> Output Class Initialized
INFO - 2020-09-05 19:29:46 --> Security Class Initialized
DEBUG - 2020-09-05 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:29:46 --> Input Class Initialized
INFO - 2020-09-05 19:29:46 --> Language Class Initialized
INFO - 2020-09-05 19:29:46 --> Language Class Initialized
INFO - 2020-09-05 19:29:46 --> Config Class Initialized
INFO - 2020-09-05 19:29:46 --> Loader Class Initialized
INFO - 2020-09-05 19:29:46 --> Helper loaded: url_helper
INFO - 2020-09-05 19:29:46 --> Helper loaded: file_helper
INFO - 2020-09-05 19:29:46 --> Database Driver Class Initialized
INFO - 2020-09-05 19:29:46 --> Email Class Initialized
INFO - 2020-09-05 19:29:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:29:46 --> Encryption Class Initialized
INFO - 2020-09-05 19:29:46 --> Model Class Initialized
INFO - 2020-09-05 19:29:46 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:29:46 --> Model Class Initialized
INFO - 2020-09-05 19:29:46 --> Model Class Initialized
INFO - 2020-09-05 19:29:46 --> Controller Class Initialized
DEBUG - 2020-09-05 19:29:46 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:29:47 --> Final output sent to browser
DEBUG - 2020-09-05 19:29:47 --> Total execution time: 0.5547
INFO - 2020-09-05 19:29:50 --> Config Class Initialized
INFO - 2020-09-05 19:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:29:50 --> Utf8 Class Initialized
INFO - 2020-09-05 19:29:50 --> URI Class Initialized
INFO - 2020-09-05 19:29:50 --> Router Class Initialized
INFO - 2020-09-05 19:29:50 --> Output Class Initialized
INFO - 2020-09-05 19:29:50 --> Security Class Initialized
DEBUG - 2020-09-05 19:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:29:50 --> Input Class Initialized
INFO - 2020-09-05 19:29:50 --> Language Class Initialized
INFO - 2020-09-05 19:29:50 --> Language Class Initialized
INFO - 2020-09-05 19:29:50 --> Config Class Initialized
INFO - 2020-09-05 19:29:50 --> Loader Class Initialized
INFO - 2020-09-05 19:29:50 --> Helper loaded: url_helper
INFO - 2020-09-05 19:29:50 --> Helper loaded: file_helper
INFO - 2020-09-05 19:29:50 --> Database Driver Class Initialized
INFO - 2020-09-05 19:29:50 --> Email Class Initialized
INFO - 2020-09-05 19:29:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:29:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:29:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:29:50 --> Encryption Class Initialized
INFO - 2020-09-05 19:29:50 --> Model Class Initialized
INFO - 2020-09-05 19:29:50 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:29:50 --> Model Class Initialized
INFO - 2020-09-05 19:29:50 --> Model Class Initialized
INFO - 2020-09-05 19:29:50 --> Controller Class Initialized
DEBUG - 2020-09-05 19:29:50 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:29:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:29:50 --> Final output sent to browser
DEBUG - 2020-09-05 19:29:50 --> Total execution time: 0.5963
INFO - 2020-09-05 19:30:19 --> Config Class Initialized
INFO - 2020-09-05 19:30:20 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:30:20 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:20 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:20 --> URI Class Initialized
INFO - 2020-09-05 19:30:20 --> Router Class Initialized
INFO - 2020-09-05 19:30:20 --> Output Class Initialized
INFO - 2020-09-05 19:30:20 --> Security Class Initialized
DEBUG - 2020-09-05 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:20 --> Input Class Initialized
INFO - 2020-09-05 19:30:20 --> Language Class Initialized
INFO - 2020-09-05 19:30:20 --> Language Class Initialized
INFO - 2020-09-05 19:30:20 --> Config Class Initialized
INFO - 2020-09-05 19:30:20 --> Loader Class Initialized
INFO - 2020-09-05 19:30:20 --> Helper loaded: url_helper
INFO - 2020-09-05 19:30:20 --> Helper loaded: file_helper
INFO - 2020-09-05 19:30:20 --> Database Driver Class Initialized
INFO - 2020-09-05 19:30:20 --> Email Class Initialized
INFO - 2020-09-05 19:30:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:30:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:30:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:30:20 --> Encryption Class Initialized
INFO - 2020-09-05 19:30:20 --> Model Class Initialized
INFO - 2020-09-05 19:30:20 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:30:20 --> Model Class Initialized
INFO - 2020-09-05 19:30:20 --> Model Class Initialized
INFO - 2020-09-05 19:30:20 --> Controller Class Initialized
DEBUG - 2020-09-05 19:30:20 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:30:20 --> Config Class Initialized
INFO - 2020-09-05 19:30:20 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:30:20 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:20 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:20 --> URI Class Initialized
DEBUG - 2020-09-05 19:30:20 --> No URI present. Default controller set.
INFO - 2020-09-05 19:30:20 --> Router Class Initialized
INFO - 2020-09-05 19:30:20 --> Output Class Initialized
INFO - 2020-09-05 19:30:20 --> Security Class Initialized
DEBUG - 2020-09-05 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:20 --> Input Class Initialized
INFO - 2020-09-05 19:30:20 --> Language Class Initialized
INFO - 2020-09-05 19:30:20 --> Language Class Initialized
INFO - 2020-09-05 19:30:20 --> Config Class Initialized
INFO - 2020-09-05 19:30:20 --> Loader Class Initialized
INFO - 2020-09-05 19:30:20 --> Helper loaded: url_helper
INFO - 2020-09-05 19:30:20 --> Helper loaded: file_helper
INFO - 2020-09-05 19:30:21 --> Database Driver Class Initialized
INFO - 2020-09-05 19:30:21 --> Email Class Initialized
INFO - 2020-09-05 19:30:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:30:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:30:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:30:21 --> Encryption Class Initialized
INFO - 2020-09-05 19:30:21 --> Model Class Initialized
INFO - 2020-09-05 19:30:21 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:30:21 --> Model Class Initialized
INFO - 2020-09-05 19:30:21 --> Model Class Initialized
INFO - 2020-09-05 19:30:21 --> Controller Class Initialized
DEBUG - 2020-09-05 19:30:21 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:30:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:30:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:30:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:30:21 --> Final output sent to browser
DEBUG - 2020-09-05 19:30:21 --> Total execution time: 0.5808
INFO - 2020-09-05 19:30:30 --> Config Class Initialized
INFO - 2020-09-05 19:30:30 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:30:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:31 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:31 --> URI Class Initialized
INFO - 2020-09-05 19:30:31 --> Router Class Initialized
INFO - 2020-09-05 19:30:31 --> Output Class Initialized
INFO - 2020-09-05 19:30:31 --> Security Class Initialized
DEBUG - 2020-09-05 19:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:31 --> Input Class Initialized
INFO - 2020-09-05 19:30:31 --> Language Class Initialized
INFO - 2020-09-05 19:30:31 --> Language Class Initialized
INFO - 2020-09-05 19:30:31 --> Config Class Initialized
INFO - 2020-09-05 19:30:31 --> Loader Class Initialized
INFO - 2020-09-05 19:30:31 --> Helper loaded: url_helper
INFO - 2020-09-05 19:30:31 --> Helper loaded: file_helper
INFO - 2020-09-05 19:30:31 --> Database Driver Class Initialized
INFO - 2020-09-05 19:30:31 --> Email Class Initialized
INFO - 2020-09-05 19:30:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:30:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:30:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:30:31 --> Encryption Class Initialized
INFO - 2020-09-05 19:30:31 --> Model Class Initialized
INFO - 2020-09-05 19:30:31 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:30:31 --> Model Class Initialized
INFO - 2020-09-05 19:30:31 --> Model Class Initialized
INFO - 2020-09-05 19:30:31 --> Controller Class Initialized
DEBUG - 2020-09-05 19:30:31 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:30:31 --> Final output sent to browser
DEBUG - 2020-09-05 19:30:31 --> Total execution time: 0.6107
INFO - 2020-09-05 19:30:36 --> Config Class Initialized
INFO - 2020-09-05 19:30:36 --> Config Class Initialized
INFO - 2020-09-05 19:30:36 --> Hooks Class Initialized
INFO - 2020-09-05 19:30:36 --> Config Class Initialized
INFO - 2020-09-05 19:30:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:30:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:36 --> URI Class Initialized
DEBUG - 2020-09-05 19:30:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:36 --> URI Class Initialized
INFO - 2020-09-05 19:30:36 --> Router Class Initialized
INFO - 2020-09-05 19:30:36 --> Router Class Initialized
INFO - 2020-09-05 19:30:36 --> Output Class Initialized
INFO - 2020-09-05 19:30:36 --> Output Class Initialized
INFO - 2020-09-05 19:30:36 --> Security Class Initialized
INFO - 2020-09-05 19:30:36 --> Security Class Initialized
DEBUG - 2020-09-05 19:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:36 --> Input Class Initialized
INFO - 2020-09-05 19:30:36 --> Language Class Initialized
DEBUG - 2020-09-05 19:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:36 --> Input Class Initialized
INFO - 2020-09-05 19:30:36 --> Language Class Initialized
ERROR - 2020-09-05 19:30:36 --> 404 Page Not Found: /index
ERROR - 2020-09-05 19:30:36 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:30:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:30:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:30:36 --> Utf8 Class Initialized
INFO - 2020-09-05 19:30:36 --> URI Class Initialized
INFO - 2020-09-05 19:30:36 --> Router Class Initialized
INFO - 2020-09-05 19:30:37 --> Output Class Initialized
INFO - 2020-09-05 19:30:37 --> Security Class Initialized
DEBUG - 2020-09-05 19:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:30:37 --> Input Class Initialized
INFO - 2020-09-05 19:30:37 --> Language Class Initialized
ERROR - 2020-09-05 19:30:37 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:32:10 --> Config Class Initialized
INFO - 2020-09-05 19:32:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:10 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:10 --> URI Class Initialized
DEBUG - 2020-09-05 19:32:10 --> No URI present. Default controller set.
INFO - 2020-09-05 19:32:10 --> Router Class Initialized
INFO - 2020-09-05 19:32:10 --> Output Class Initialized
INFO - 2020-09-05 19:32:10 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:10 --> Input Class Initialized
INFO - 2020-09-05 19:32:10 --> Language Class Initialized
INFO - 2020-09-05 19:32:10 --> Language Class Initialized
INFO - 2020-09-05 19:32:10 --> Config Class Initialized
INFO - 2020-09-05 19:32:10 --> Loader Class Initialized
INFO - 2020-09-05 19:32:10 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:10 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:10 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:10 --> Email Class Initialized
INFO - 2020-09-05 19:32:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:10 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:10 --> Model Class Initialized
INFO - 2020-09-05 19:32:10 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:10 --> Model Class Initialized
INFO - 2020-09-05 19:32:10 --> Model Class Initialized
INFO - 2020-09-05 19:32:10 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:10 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:32:10 --> Config Class Initialized
INFO - 2020-09-05 19:32:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:11 --> URI Class Initialized
INFO - 2020-09-05 19:32:11 --> Router Class Initialized
INFO - 2020-09-05 19:32:11 --> Output Class Initialized
INFO - 2020-09-05 19:32:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:11 --> Input Class Initialized
INFO - 2020-09-05 19:32:11 --> Language Class Initialized
INFO - 2020-09-05 19:32:11 --> Language Class Initialized
INFO - 2020-09-05 19:32:11 --> Config Class Initialized
INFO - 2020-09-05 19:32:11 --> Loader Class Initialized
INFO - 2020-09-05 19:32:11 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:11 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:11 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:11 --> Email Class Initialized
INFO - 2020-09-05 19:32:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:11 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:11 --> Model Class Initialized
INFO - 2020-09-05 19:32:11 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:11 --> Model Class Initialized
INFO - 2020-09-05 19:32:11 --> Model Class Initialized
INFO - 2020-09-05 19:32:11 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:11 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:32:11 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:32:11 --> Final output sent to browser
DEBUG - 2020-09-05 19:32:11 --> Total execution time: 0.6366
INFO - 2020-09-05 19:32:11 --> Config Class Initialized
INFO - 2020-09-05 19:32:11 --> Config Class Initialized
INFO - 2020-09-05 19:32:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:11 --> URI Class Initialized
INFO - 2020-09-05 19:32:11 --> Router Class Initialized
INFO - 2020-09-05 19:32:11 --> Output Class Initialized
INFO - 2020-09-05 19:32:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:11 --> Input Class Initialized
INFO - 2020-09-05 19:32:11 --> Language Class Initialized
ERROR - 2020-09-05 19:32:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:32:11 --> Config Class Initialized
INFO - 2020-09-05 19:32:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:11 --> URI Class Initialized
INFO - 2020-09-05 19:32:11 --> Router Class Initialized
INFO - 2020-09-05 19:32:11 --> Output Class Initialized
INFO - 2020-09-05 19:32:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:11 --> Input Class Initialized
INFO - 2020-09-05 19:32:11 --> Language Class Initialized
ERROR - 2020-09-05 19:32:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:32:11 --> URI Class Initialized
INFO - 2020-09-05 19:32:12 --> Router Class Initialized
INFO - 2020-09-05 19:32:12 --> Output Class Initialized
INFO - 2020-09-05 19:32:12 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:12 --> Input Class Initialized
INFO - 2020-09-05 19:32:12 --> Language Class Initialized
ERROR - 2020-09-05 19:32:12 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:32:18 --> Config Class Initialized
INFO - 2020-09-05 19:32:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:18 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:18 --> URI Class Initialized
INFO - 2020-09-05 19:32:18 --> Router Class Initialized
INFO - 2020-09-05 19:32:18 --> Output Class Initialized
INFO - 2020-09-05 19:32:18 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:18 --> Input Class Initialized
INFO - 2020-09-05 19:32:18 --> Language Class Initialized
INFO - 2020-09-05 19:32:18 --> Language Class Initialized
INFO - 2020-09-05 19:32:18 --> Config Class Initialized
INFO - 2020-09-05 19:32:19 --> Loader Class Initialized
INFO - 2020-09-05 19:32:19 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:19 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:19 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:19 --> Email Class Initialized
INFO - 2020-09-05 19:32:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:19 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:19 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:32:19 --> Config Class Initialized
INFO - 2020-09-05 19:32:19 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:19 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:19 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:19 --> URI Class Initialized
DEBUG - 2020-09-05 19:32:19 --> No URI present. Default controller set.
INFO - 2020-09-05 19:32:19 --> Router Class Initialized
INFO - 2020-09-05 19:32:19 --> Output Class Initialized
INFO - 2020-09-05 19:32:19 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:19 --> Input Class Initialized
INFO - 2020-09-05 19:32:19 --> Language Class Initialized
INFO - 2020-09-05 19:32:19 --> Language Class Initialized
INFO - 2020-09-05 19:32:19 --> Config Class Initialized
INFO - 2020-09-05 19:32:19 --> Loader Class Initialized
INFO - 2020-09-05 19:32:19 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:19 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:19 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:19 --> Email Class Initialized
INFO - 2020-09-05 19:32:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:19 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Model Class Initialized
INFO - 2020-09-05 19:32:19 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:20 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:32:20 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:32:20 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:32:20 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:32:20 --> Final output sent to browser
DEBUG - 2020-09-05 19:32:20 --> Total execution time: 0.5688
INFO - 2020-09-05 19:32:31 --> Config Class Initialized
INFO - 2020-09-05 19:32:31 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:31 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:32 --> URI Class Initialized
INFO - 2020-09-05 19:32:32 --> Router Class Initialized
INFO - 2020-09-05 19:32:32 --> Output Class Initialized
INFO - 2020-09-05 19:32:32 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:32 --> Input Class Initialized
INFO - 2020-09-05 19:32:32 --> Language Class Initialized
INFO - 2020-09-05 19:32:32 --> Language Class Initialized
INFO - 2020-09-05 19:32:32 --> Config Class Initialized
INFO - 2020-09-05 19:32:32 --> Loader Class Initialized
INFO - 2020-09-05 19:32:32 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:32 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:32 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:32 --> Email Class Initialized
INFO - 2020-09-05 19:32:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:32 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:32 --> Model Class Initialized
INFO - 2020-09-05 19:32:32 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:32 --> Model Class Initialized
INFO - 2020-09-05 19:32:32 --> Model Class Initialized
INFO - 2020-09-05 19:32:32 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:32 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:32:32 --> Final output sent to browser
DEBUG - 2020-09-05 19:32:32 --> Total execution time: 0.5479
INFO - 2020-09-05 19:32:47 --> Config Class Initialized
INFO - 2020-09-05 19:32:47 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:47 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:47 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:47 --> URI Class Initialized
DEBUG - 2020-09-05 19:32:47 --> No URI present. Default controller set.
INFO - 2020-09-05 19:32:47 --> Router Class Initialized
INFO - 2020-09-05 19:32:47 --> Output Class Initialized
INFO - 2020-09-05 19:32:47 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:47 --> Input Class Initialized
INFO - 2020-09-05 19:32:47 --> Language Class Initialized
INFO - 2020-09-05 19:32:47 --> Language Class Initialized
INFO - 2020-09-05 19:32:47 --> Config Class Initialized
INFO - 2020-09-05 19:32:47 --> Loader Class Initialized
INFO - 2020-09-05 19:32:47 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:47 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:47 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:47 --> Email Class Initialized
INFO - 2020-09-05 19:32:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:47 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:47 --> Model Class Initialized
INFO - 2020-09-05 19:32:47 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:47 --> Model Class Initialized
INFO - 2020-09-05 19:32:47 --> Model Class Initialized
INFO - 2020-09-05 19:32:47 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:47 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:32:50 --> Config Class Initialized
INFO - 2020-09-05 19:32:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:50 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:50 --> URI Class Initialized
INFO - 2020-09-05 19:32:50 --> Router Class Initialized
INFO - 2020-09-05 19:32:50 --> Output Class Initialized
INFO - 2020-09-05 19:32:50 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:50 --> Input Class Initialized
INFO - 2020-09-05 19:32:50 --> Language Class Initialized
INFO - 2020-09-05 19:32:50 --> Language Class Initialized
INFO - 2020-09-05 19:32:50 --> Config Class Initialized
INFO - 2020-09-05 19:32:50 --> Loader Class Initialized
INFO - 2020-09-05 19:32:50 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:50 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:50 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:50 --> Email Class Initialized
INFO - 2020-09-05 19:32:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:50 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:50 --> Model Class Initialized
INFO - 2020-09-05 19:32:50 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:50 --> Model Class Initialized
INFO - 2020-09-05 19:32:50 --> Model Class Initialized
INFO - 2020-09-05 19:32:50 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:50 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:32:50 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:32:50 --> Final output sent to browser
DEBUG - 2020-09-05 19:32:50 --> Total execution time: 0.6139
INFO - 2020-09-05 19:32:55 --> Config Class Initialized
INFO - 2020-09-05 19:32:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:55 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:55 --> URI Class Initialized
INFO - 2020-09-05 19:32:55 --> Router Class Initialized
INFO - 2020-09-05 19:32:55 --> Output Class Initialized
INFO - 2020-09-05 19:32:56 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:56 --> Input Class Initialized
INFO - 2020-09-05 19:32:56 --> Language Class Initialized
INFO - 2020-09-05 19:32:56 --> Language Class Initialized
INFO - 2020-09-05 19:32:56 --> Config Class Initialized
INFO - 2020-09-05 19:32:56 --> Loader Class Initialized
INFO - 2020-09-05 19:32:56 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:56 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:56 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:56 --> Email Class Initialized
INFO - 2020-09-05 19:32:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:56 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:56 --> Model Class Initialized
INFO - 2020-09-05 19:32:56 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:56 --> Model Class Initialized
INFO - 2020-09-05 19:32:56 --> Model Class Initialized
INFO - 2020-09-05 19:32:56 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:56 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:32:56 --> Config Class Initialized
INFO - 2020-09-05 19:32:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:32:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:32:56 --> Utf8 Class Initialized
INFO - 2020-09-05 19:32:56 --> URI Class Initialized
DEBUG - 2020-09-05 19:32:56 --> No URI present. Default controller set.
INFO - 2020-09-05 19:32:56 --> Router Class Initialized
INFO - 2020-09-05 19:32:56 --> Output Class Initialized
INFO - 2020-09-05 19:32:56 --> Security Class Initialized
DEBUG - 2020-09-05 19:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:32:56 --> Input Class Initialized
INFO - 2020-09-05 19:32:56 --> Language Class Initialized
INFO - 2020-09-05 19:32:56 --> Language Class Initialized
INFO - 2020-09-05 19:32:57 --> Config Class Initialized
INFO - 2020-09-05 19:32:57 --> Loader Class Initialized
INFO - 2020-09-05 19:32:57 --> Helper loaded: url_helper
INFO - 2020-09-05 19:32:57 --> Helper loaded: file_helper
INFO - 2020-09-05 19:32:57 --> Database Driver Class Initialized
INFO - 2020-09-05 19:32:57 --> Email Class Initialized
INFO - 2020-09-05 19:32:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:32:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:32:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:32:57 --> Encryption Class Initialized
INFO - 2020-09-05 19:32:57 --> Model Class Initialized
INFO - 2020-09-05 19:32:57 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:32:57 --> Model Class Initialized
INFO - 2020-09-05 19:32:57 --> Model Class Initialized
INFO - 2020-09-05 19:32:57 --> Controller Class Initialized
DEBUG - 2020-09-05 19:32:57 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:32:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:32:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:32:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:32:57 --> Final output sent to browser
DEBUG - 2020-09-05 19:32:57 --> Total execution time: 0.6137
INFO - 2020-09-05 19:33:07 --> Config Class Initialized
INFO - 2020-09-05 19:33:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:33:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:33:07 --> Utf8 Class Initialized
INFO - 2020-09-05 19:33:07 --> URI Class Initialized
INFO - 2020-09-05 19:33:07 --> Router Class Initialized
INFO - 2020-09-05 19:33:07 --> Output Class Initialized
INFO - 2020-09-05 19:33:07 --> Security Class Initialized
DEBUG - 2020-09-05 19:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:33:08 --> Input Class Initialized
INFO - 2020-09-05 19:33:08 --> Language Class Initialized
INFO - 2020-09-05 19:33:08 --> Language Class Initialized
INFO - 2020-09-05 19:33:08 --> Config Class Initialized
INFO - 2020-09-05 19:33:08 --> Loader Class Initialized
INFO - 2020-09-05 19:33:08 --> Helper loaded: url_helper
INFO - 2020-09-05 19:33:08 --> Helper loaded: file_helper
INFO - 2020-09-05 19:33:08 --> Database Driver Class Initialized
INFO - 2020-09-05 19:33:08 --> Email Class Initialized
INFO - 2020-09-05 19:33:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:33:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:33:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:33:08 --> Encryption Class Initialized
INFO - 2020-09-05 19:33:08 --> Model Class Initialized
INFO - 2020-09-05 19:33:08 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:33:08 --> Model Class Initialized
INFO - 2020-09-05 19:33:08 --> Model Class Initialized
INFO - 2020-09-05 19:33:08 --> Controller Class Initialized
DEBUG - 2020-09-05 19:33:08 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:33:08 --> Final output sent to browser
DEBUG - 2020-09-05 19:33:08 --> Total execution time: 0.6771
INFO - 2020-09-05 19:33:11 --> Config Class Initialized
INFO - 2020-09-05 19:33:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:33:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:33:11 --> Utf8 Class Initialized
INFO - 2020-09-05 19:33:11 --> URI Class Initialized
INFO - 2020-09-05 19:33:11 --> Router Class Initialized
INFO - 2020-09-05 19:33:11 --> Output Class Initialized
INFO - 2020-09-05 19:33:11 --> Security Class Initialized
DEBUG - 2020-09-05 19:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:33:11 --> Input Class Initialized
INFO - 2020-09-05 19:33:11 --> Language Class Initialized
INFO - 2020-09-05 19:33:11 --> Language Class Initialized
INFO - 2020-09-05 19:33:11 --> Config Class Initialized
INFO - 2020-09-05 19:33:11 --> Loader Class Initialized
INFO - 2020-09-05 19:33:11 --> Helper loaded: url_helper
INFO - 2020-09-05 19:33:11 --> Helper loaded: file_helper
INFO - 2020-09-05 19:33:11 --> Database Driver Class Initialized
INFO - 2020-09-05 19:33:11 --> Email Class Initialized
INFO - 2020-09-05 19:33:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:33:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:33:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:33:11 --> Encryption Class Initialized
INFO - 2020-09-05 19:33:11 --> Model Class Initialized
INFO - 2020-09-05 19:33:11 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:33:11 --> Model Class Initialized
INFO - 2020-09-05 19:33:11 --> Model Class Initialized
INFO - 2020-09-05 19:33:11 --> Controller Class Initialized
DEBUG - 2020-09-05 19:33:11 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:33:12 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:33:12 --> Final output sent to browser
DEBUG - 2020-09-05 19:33:12 --> Total execution time: 0.6492
INFO - 2020-09-05 19:33:20 --> Config Class Initialized
INFO - 2020-09-05 19:33:20 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:33:20 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:33:21 --> Utf8 Class Initialized
INFO - 2020-09-05 19:33:21 --> URI Class Initialized
INFO - 2020-09-05 19:33:21 --> Router Class Initialized
INFO - 2020-09-05 19:33:21 --> Output Class Initialized
INFO - 2020-09-05 19:33:21 --> Security Class Initialized
DEBUG - 2020-09-05 19:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:33:21 --> Input Class Initialized
INFO - 2020-09-05 19:33:21 --> Language Class Initialized
INFO - 2020-09-05 19:33:21 --> Language Class Initialized
INFO - 2020-09-05 19:33:21 --> Config Class Initialized
INFO - 2020-09-05 19:33:21 --> Loader Class Initialized
INFO - 2020-09-05 19:33:21 --> Helper loaded: url_helper
INFO - 2020-09-05 19:33:21 --> Helper loaded: file_helper
INFO - 2020-09-05 19:33:21 --> Database Driver Class Initialized
INFO - 2020-09-05 19:33:21 --> Email Class Initialized
INFO - 2020-09-05 19:33:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:33:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:33:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:33:21 --> Encryption Class Initialized
INFO - 2020-09-05 19:33:21 --> Model Class Initialized
INFO - 2020-09-05 19:33:21 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:33:21 --> Model Class Initialized
INFO - 2020-09-05 19:33:21 --> Model Class Initialized
INFO - 2020-09-05 19:33:21 --> Controller Class Initialized
DEBUG - 2020-09-05 19:33:21 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:33:21 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:33:21 --> Final output sent to browser
DEBUG - 2020-09-05 19:33:21 --> Total execution time: 0.6439
INFO - 2020-09-05 19:33:48 --> Config Class Initialized
INFO - 2020-09-05 19:33:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:33:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:33:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:33:48 --> URI Class Initialized
INFO - 2020-09-05 19:33:48 --> Router Class Initialized
INFO - 2020-09-05 19:33:48 --> Output Class Initialized
INFO - 2020-09-05 19:33:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:33:48 --> Input Class Initialized
INFO - 2020-09-05 19:33:48 --> Language Class Initialized
INFO - 2020-09-05 19:33:48 --> Language Class Initialized
INFO - 2020-09-05 19:33:48 --> Config Class Initialized
INFO - 2020-09-05 19:33:48 --> Loader Class Initialized
INFO - 2020-09-05 19:33:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:33:48 --> Helper loaded: file_helper
INFO - 2020-09-05 19:33:49 --> Database Driver Class Initialized
INFO - 2020-09-05 19:33:49 --> Email Class Initialized
INFO - 2020-09-05 19:33:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:33:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:33:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:33:49 --> Encryption Class Initialized
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Controller Class Initialized
DEBUG - 2020-09-05 19:33:49 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:33:49 --> Config Class Initialized
INFO - 2020-09-05 19:33:49 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:33:49 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:33:49 --> Utf8 Class Initialized
INFO - 2020-09-05 19:33:49 --> URI Class Initialized
DEBUG - 2020-09-05 19:33:49 --> No URI present. Default controller set.
INFO - 2020-09-05 19:33:49 --> Router Class Initialized
INFO - 2020-09-05 19:33:49 --> Output Class Initialized
INFO - 2020-09-05 19:33:49 --> Security Class Initialized
DEBUG - 2020-09-05 19:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:33:49 --> Input Class Initialized
INFO - 2020-09-05 19:33:49 --> Language Class Initialized
INFO - 2020-09-05 19:33:49 --> Language Class Initialized
INFO - 2020-09-05 19:33:49 --> Config Class Initialized
INFO - 2020-09-05 19:33:49 --> Loader Class Initialized
INFO - 2020-09-05 19:33:49 --> Helper loaded: url_helper
INFO - 2020-09-05 19:33:49 --> Helper loaded: file_helper
INFO - 2020-09-05 19:33:49 --> Database Driver Class Initialized
INFO - 2020-09-05 19:33:49 --> Email Class Initialized
INFO - 2020-09-05 19:33:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:33:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:33:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:33:49 --> Encryption Class Initialized
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Model Class Initialized
INFO - 2020-09-05 19:33:49 --> Controller Class Initialized
DEBUG - 2020-09-05 19:33:49 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:33:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:33:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:33:49 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:33:49 --> Final output sent to browser
DEBUG - 2020-09-05 19:33:50 --> Total execution time: 0.6308
INFO - 2020-09-05 19:34:26 --> Config Class Initialized
INFO - 2020-09-05 19:34:26 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:34:26 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:34:26 --> Utf8 Class Initialized
INFO - 2020-09-05 19:34:26 --> URI Class Initialized
INFO - 2020-09-05 19:34:26 --> Router Class Initialized
INFO - 2020-09-05 19:34:26 --> Output Class Initialized
INFO - 2020-09-05 19:34:26 --> Security Class Initialized
DEBUG - 2020-09-05 19:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:34:26 --> Input Class Initialized
INFO - 2020-09-05 19:34:26 --> Language Class Initialized
INFO - 2020-09-05 19:34:26 --> Language Class Initialized
INFO - 2020-09-05 19:34:26 --> Config Class Initialized
INFO - 2020-09-05 19:34:26 --> Loader Class Initialized
INFO - 2020-09-05 19:34:26 --> Helper loaded: url_helper
INFO - 2020-09-05 19:34:26 --> Helper loaded: file_helper
INFO - 2020-09-05 19:34:26 --> Database Driver Class Initialized
INFO - 2020-09-05 19:34:26 --> Email Class Initialized
INFO - 2020-09-05 19:34:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:34:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:34:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:34:26 --> Encryption Class Initialized
INFO - 2020-09-05 19:34:26 --> Model Class Initialized
INFO - 2020-09-05 19:34:26 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:34:26 --> Model Class Initialized
INFO - 2020-09-05 19:34:26 --> Model Class Initialized
INFO - 2020-09-05 19:34:26 --> Controller Class Initialized
DEBUG - 2020-09-05 19:34:26 --> Admin MX_Controller Initialized
INFO - 2020-09-05 19:34:26 --> Final output sent to browser
DEBUG - 2020-09-05 19:34:26 --> Total execution time: 0.5194
INFO - 2020-09-05 19:34:30 --> Config Class Initialized
INFO - 2020-09-05 19:34:30 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:34:30 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:34:30 --> Utf8 Class Initialized
INFO - 2020-09-05 19:34:30 --> URI Class Initialized
INFO - 2020-09-05 19:34:30 --> Router Class Initialized
INFO - 2020-09-05 19:34:30 --> Output Class Initialized
INFO - 2020-09-05 19:34:30 --> Security Class Initialized
DEBUG - 2020-09-05 19:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:34:30 --> Input Class Initialized
INFO - 2020-09-05 19:34:30 --> Language Class Initialized
INFO - 2020-09-05 19:34:30 --> Language Class Initialized
INFO - 2020-09-05 19:34:30 --> Config Class Initialized
INFO - 2020-09-05 19:34:30 --> Loader Class Initialized
INFO - 2020-09-05 19:34:30 --> Helper loaded: url_helper
INFO - 2020-09-05 19:34:30 --> Helper loaded: file_helper
INFO - 2020-09-05 19:34:30 --> Database Driver Class Initialized
INFO - 2020-09-05 19:34:30 --> Email Class Initialized
INFO - 2020-09-05 19:34:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:34:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:34:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:34:30 --> Encryption Class Initialized
INFO - 2020-09-05 19:34:30 --> Model Class Initialized
INFO - 2020-09-05 19:34:30 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:34:30 --> Model Class Initialized
INFO - 2020-09-05 19:34:30 --> Model Class Initialized
INFO - 2020-09-05 19:34:30 --> Controller Class Initialized
DEBUG - 2020-09-05 19:34:30 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:34:30 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:34:30 --> Final output sent to browser
DEBUG - 2020-09-05 19:34:30 --> Total execution time: 0.6498
INFO - 2020-09-05 19:34:41 --> Config Class Initialized
INFO - 2020-09-05 19:34:41 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:34:41 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:34:41 --> Utf8 Class Initialized
INFO - 2020-09-05 19:34:41 --> URI Class Initialized
INFO - 2020-09-05 19:34:41 --> Router Class Initialized
INFO - 2020-09-05 19:34:41 --> Output Class Initialized
INFO - 2020-09-05 19:34:41 --> Security Class Initialized
DEBUG - 2020-09-05 19:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:34:41 --> Input Class Initialized
INFO - 2020-09-05 19:34:41 --> Language Class Initialized
INFO - 2020-09-05 19:34:41 --> Language Class Initialized
INFO - 2020-09-05 19:34:41 --> Config Class Initialized
INFO - 2020-09-05 19:34:41 --> Loader Class Initialized
INFO - 2020-09-05 19:34:41 --> Helper loaded: url_helper
INFO - 2020-09-05 19:34:41 --> Helper loaded: file_helper
INFO - 2020-09-05 19:34:41 --> Database Driver Class Initialized
INFO - 2020-09-05 19:34:41 --> Email Class Initialized
INFO - 2020-09-05 19:34:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:34:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:34:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:34:41 --> Encryption Class Initialized
INFO - 2020-09-05 19:34:41 --> Model Class Initialized
INFO - 2020-09-05 19:34:41 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:34:41 --> Model Class Initialized
INFO - 2020-09-05 19:34:41 --> Model Class Initialized
INFO - 2020-09-05 19:34:41 --> Controller Class Initialized
DEBUG - 2020-09-05 19:34:41 --> Card MX_Controller Initialized
DEBUG - 2020-09-05 19:34:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:34:42 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-05 19:34:42 --> Final output sent to browser
DEBUG - 2020-09-05 19:34:42 --> Total execution time: 0.7281
INFO - 2020-09-05 19:34:59 --> Config Class Initialized
INFO - 2020-09-05 19:34:59 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:34:59 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:34:59 --> Utf8 Class Initialized
INFO - 2020-09-05 19:34:59 --> URI Class Initialized
INFO - 2020-09-05 19:34:59 --> Router Class Initialized
INFO - 2020-09-05 19:34:59 --> Output Class Initialized
INFO - 2020-09-05 19:34:59 --> Security Class Initialized
DEBUG - 2020-09-05 19:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:34:59 --> Input Class Initialized
INFO - 2020-09-05 19:34:59 --> Language Class Initialized
INFO - 2020-09-05 19:34:59 --> Language Class Initialized
INFO - 2020-09-05 19:34:59 --> Config Class Initialized
INFO - 2020-09-05 19:34:59 --> Loader Class Initialized
INFO - 2020-09-05 19:34:59 --> Helper loaded: url_helper
INFO - 2020-09-05 19:34:59 --> Helper loaded: file_helper
INFO - 2020-09-05 19:34:59 --> Database Driver Class Initialized
INFO - 2020-09-05 19:34:59 --> Email Class Initialized
INFO - 2020-09-05 19:34:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:34:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:34:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:34:59 --> Encryption Class Initialized
INFO - 2020-09-05 19:34:59 --> Model Class Initialized
INFO - 2020-09-05 19:34:59 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:34:59 --> Model Class Initialized
INFO - 2020-09-05 19:34:59 --> Model Class Initialized
INFO - 2020-09-05 19:34:59 --> Controller Class Initialized
DEBUG - 2020-09-05 19:34:59 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-09-05 19:34:59 --> Config Class Initialized
INFO - 2020-09-05 19:34:59 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:34:59 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:34:59 --> Utf8 Class Initialized
INFO - 2020-09-05 19:35:00 --> URI Class Initialized
DEBUG - 2020-09-05 19:35:00 --> No URI present. Default controller set.
INFO - 2020-09-05 19:35:00 --> Router Class Initialized
INFO - 2020-09-05 19:35:00 --> Output Class Initialized
INFO - 2020-09-05 19:35:00 --> Security Class Initialized
DEBUG - 2020-09-05 19:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:35:00 --> Input Class Initialized
INFO - 2020-09-05 19:35:00 --> Language Class Initialized
INFO - 2020-09-05 19:35:00 --> Language Class Initialized
INFO - 2020-09-05 19:35:00 --> Config Class Initialized
INFO - 2020-09-05 19:35:00 --> Loader Class Initialized
INFO - 2020-09-05 19:35:00 --> Helper loaded: url_helper
INFO - 2020-09-05 19:35:00 --> Helper loaded: file_helper
INFO - 2020-09-05 19:35:00 --> Database Driver Class Initialized
INFO - 2020-09-05 19:35:00 --> Email Class Initialized
INFO - 2020-09-05 19:35:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:35:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:35:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:35:00 --> Encryption Class Initialized
INFO - 2020-09-05 19:35:00 --> Model Class Initialized
INFO - 2020-09-05 19:35:00 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:35:00 --> Model Class Initialized
INFO - 2020-09-05 19:35:00 --> Model Class Initialized
INFO - 2020-09-05 19:35:00 --> Controller Class Initialized
DEBUG - 2020-09-05 19:35:00 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:35:00 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:35:00 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:35:00 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:35:00 --> Final output sent to browser
DEBUG - 2020-09-05 19:35:00 --> Total execution time: 0.6013
INFO - 2020-09-05 19:35:45 --> Config Class Initialized
INFO - 2020-09-05 19:35:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:35:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:35:45 --> Utf8 Class Initialized
INFO - 2020-09-05 19:35:45 --> URI Class Initialized
DEBUG - 2020-09-05 19:35:45 --> No URI present. Default controller set.
INFO - 2020-09-05 19:35:45 --> Router Class Initialized
INFO - 2020-09-05 19:35:45 --> Output Class Initialized
INFO - 2020-09-05 19:35:45 --> Security Class Initialized
DEBUG - 2020-09-05 19:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:35:45 --> Input Class Initialized
INFO - 2020-09-05 19:35:45 --> Language Class Initialized
INFO - 2020-09-05 19:35:45 --> Language Class Initialized
INFO - 2020-09-05 19:35:45 --> Config Class Initialized
INFO - 2020-09-05 19:35:45 --> Loader Class Initialized
INFO - 2020-09-05 19:35:45 --> Helper loaded: url_helper
INFO - 2020-09-05 19:35:45 --> Helper loaded: file_helper
INFO - 2020-09-05 19:35:45 --> Database Driver Class Initialized
INFO - 2020-09-05 19:35:45 --> Email Class Initialized
INFO - 2020-09-05 19:35:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:35:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:35:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:35:45 --> Encryption Class Initialized
INFO - 2020-09-05 19:35:45 --> Model Class Initialized
INFO - 2020-09-05 19:35:45 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:35:45 --> Model Class Initialized
INFO - 2020-09-05 19:35:45 --> Model Class Initialized
INFO - 2020-09-05 19:35:45 --> Controller Class Initialized
DEBUG - 2020-09-05 19:35:45 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:35:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:35:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:35:45 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:35:45 --> Final output sent to browser
DEBUG - 2020-09-05 19:35:45 --> Total execution time: 0.6663
INFO - 2020-09-05 19:35:56 --> Config Class Initialized
INFO - 2020-09-05 19:35:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:35:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:35:56 --> Utf8 Class Initialized
INFO - 2020-09-05 19:35:56 --> URI Class Initialized
DEBUG - 2020-09-05 19:35:56 --> No URI present. Default controller set.
INFO - 2020-09-05 19:35:56 --> Router Class Initialized
INFO - 2020-09-05 19:35:57 --> Output Class Initialized
INFO - 2020-09-05 19:35:57 --> Security Class Initialized
DEBUG - 2020-09-05 19:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:35:57 --> Input Class Initialized
INFO - 2020-09-05 19:35:57 --> Language Class Initialized
INFO - 2020-09-05 19:35:57 --> Language Class Initialized
INFO - 2020-09-05 19:35:57 --> Config Class Initialized
INFO - 2020-09-05 19:35:57 --> Loader Class Initialized
INFO - 2020-09-05 19:35:57 --> Helper loaded: url_helper
INFO - 2020-09-05 19:35:57 --> Helper loaded: file_helper
INFO - 2020-09-05 19:35:57 --> Database Driver Class Initialized
INFO - 2020-09-05 19:35:57 --> Email Class Initialized
INFO - 2020-09-05 19:35:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-05 19:35:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-05 19:35:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-05 19:35:57 --> Encryption Class Initialized
INFO - 2020-09-05 19:35:57 --> Model Class Initialized
INFO - 2020-09-05 19:35:57 --> Helper loaded: inflector_helper
INFO - 2020-09-05 19:35:57 --> Model Class Initialized
INFO - 2020-09-05 19:35:57 --> Model Class Initialized
INFO - 2020-09-05 19:35:57 --> Controller Class Initialized
DEBUG - 2020-09-05 19:35:57 --> Admin MX_Controller Initialized
DEBUG - 2020-09-05 19:35:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-05 19:35:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-05 19:35:57 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-05 19:35:57 --> Final output sent to browser
DEBUG - 2020-09-05 19:35:57 --> Total execution time: 0.6507
