<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-29 09:22:17 --> Config Class Initialized
INFO - 2021-06-29 09:22:17 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:22:18 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:18 --> Utf8 Class Initialized
INFO - 2021-06-29 09:22:18 --> URI Class Initialized
DEBUG - 2021-06-29 09:22:18 --> No URI present. Default controller set.
INFO - 2021-06-29 09:22:18 --> Router Class Initialized
INFO - 2021-06-29 09:22:18 --> Output Class Initialized
INFO - 2021-06-29 09:22:18 --> Security Class Initialized
DEBUG - 2021-06-29 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:18 --> Input Class Initialized
INFO - 2021-06-29 09:22:18 --> Language Class Initialized
INFO - 2021-06-29 09:22:18 --> Language Class Initialized
INFO - 2021-06-29 09:22:18 --> Config Class Initialized
INFO - 2021-06-29 09:22:18 --> Loader Class Initialized
INFO - 2021-06-29 09:22:18 --> Helper loaded: url_helper
INFO - 2021-06-29 09:22:18 --> Helper loaded: file_helper
INFO - 2021-06-29 09:22:18 --> Helper loaded: common_helper
INFO - 2021-06-29 09:22:18 --> Database Driver Class Initialized
INFO - 2021-06-29 09:22:18 --> Email Class Initialized
INFO - 2021-06-29 09:22:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 09:22:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 09:22:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 09:22:18 --> Encryption Class Initialized
INFO - 2021-06-29 09:22:18 --> Model Class Initialized
INFO - 2021-06-29 09:22:18 --> Helper loaded: inflector_helper
INFO - 2021-06-29 09:22:18 --> Model Class Initialized
INFO - 2021-06-29 09:22:18 --> Model Class Initialized
INFO - 2021-06-29 09:22:18 --> Controller Class Initialized
DEBUG - 2021-06-29 09:22:18 --> Admin MX_Controller Initialized
DEBUG - 2021-06-29 09:22:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-06-29 09:22:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-06-29 09:22:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-06-29 09:22:19 --> Final output sent to browser
DEBUG - 2021-06-29 09:22:19 --> Total execution time: 1.2630
INFO - 2021-06-29 09:22:25 --> Config Class Initialized
INFO - 2021-06-29 09:22:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:22:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:25 --> Utf8 Class Initialized
INFO - 2021-06-29 09:22:25 --> URI Class Initialized
INFO - 2021-06-29 09:22:25 --> Router Class Initialized
INFO - 2021-06-29 09:22:25 --> Output Class Initialized
INFO - 2021-06-29 09:22:25 --> Security Class Initialized
DEBUG - 2021-06-29 09:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:25 --> Input Class Initialized
INFO - 2021-06-29 09:22:25 --> Language Class Initialized
INFO - 2021-06-29 09:22:25 --> Language Class Initialized
INFO - 2021-06-29 09:22:25 --> Config Class Initialized
INFO - 2021-06-29 09:22:25 --> Loader Class Initialized
INFO - 2021-06-29 09:22:25 --> Helper loaded: url_helper
INFO - 2021-06-29 09:22:25 --> Helper loaded: file_helper
INFO - 2021-06-29 09:22:25 --> Helper loaded: common_helper
INFO - 2021-06-29 09:22:25 --> Database Driver Class Initialized
INFO - 2021-06-29 09:22:25 --> Email Class Initialized
INFO - 2021-06-29 09:22:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 09:22:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 09:22:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 09:22:25 --> Encryption Class Initialized
INFO - 2021-06-29 09:22:25 --> Model Class Initialized
INFO - 2021-06-29 09:22:25 --> Helper loaded: inflector_helper
INFO - 2021-06-29 09:22:25 --> Model Class Initialized
INFO - 2021-06-29 09:22:25 --> Model Class Initialized
INFO - 2021-06-29 09:22:25 --> Controller Class Initialized
DEBUG - 2021-06-29 09:22:25 --> Admin MX_Controller Initialized
INFO - 2021-06-29 09:22:25 --> Final output sent to browser
DEBUG - 2021-06-29 09:22:25 --> Total execution time: 0.1737
INFO - 2021-06-29 09:22:28 --> Config Class Initialized
INFO - 2021-06-29 09:22:28 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:22:28 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:28 --> Utf8 Class Initialized
INFO - 2021-06-29 09:22:28 --> URI Class Initialized
INFO - 2021-06-29 09:22:28 --> Router Class Initialized
INFO - 2021-06-29 09:22:28 --> Output Class Initialized
INFO - 2021-06-29 09:22:28 --> Security Class Initialized
DEBUG - 2021-06-29 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:28 --> Input Class Initialized
INFO - 2021-06-29 09:22:28 --> Language Class Initialized
INFO - 2021-06-29 09:22:28 --> Language Class Initialized
INFO - 2021-06-29 09:22:28 --> Config Class Initialized
INFO - 2021-06-29 09:22:28 --> Loader Class Initialized
INFO - 2021-06-29 09:22:28 --> Helper loaded: url_helper
INFO - 2021-06-29 09:22:28 --> Helper loaded: file_helper
INFO - 2021-06-29 09:22:28 --> Helper loaded: common_helper
INFO - 2021-06-29 09:22:28 --> Database Driver Class Initialized
INFO - 2021-06-29 09:22:28 --> Email Class Initialized
INFO - 2021-06-29 09:22:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 09:22:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 09:22:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 09:22:28 --> Encryption Class Initialized
INFO - 2021-06-29 09:22:28 --> Model Class Initialized
INFO - 2021-06-29 09:22:28 --> Helper loaded: inflector_helper
INFO - 2021-06-29 09:22:28 --> Model Class Initialized
INFO - 2021-06-29 09:22:28 --> Model Class Initialized
INFO - 2021-06-29 09:22:28 --> Controller Class Initialized
DEBUG - 2021-06-29 09:22:28 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-06-29 09:22:28 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-06-29 09:22:28 --> Final output sent to browser
DEBUG - 2021-06-29 09:22:28 --> Total execution time: 0.2387
INFO - 2021-06-29 09:22:32 --> Config Class Initialized
INFO - 2021-06-29 09:22:32 --> Hooks Class Initialized
INFO - 2021-06-29 09:22:32 --> Config Class Initialized
INFO - 2021-06-29 09:22:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:32 --> Utf8 Class Initialized
DEBUG - 2021-06-29 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:32 --> Utf8 Class Initialized
INFO - 2021-06-29 09:22:32 --> URI Class Initialized
INFO - 2021-06-29 09:22:32 --> Config Class Initialized
INFO - 2021-06-29 09:22:32 --> Hooks Class Initialized
INFO - 2021-06-29 09:22:32 --> URI Class Initialized
DEBUG - 2021-06-29 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:22:32 --> Router Class Initialized
INFO - 2021-06-29 09:22:32 --> Utf8 Class Initialized
INFO - 2021-06-29 09:22:32 --> Router Class Initialized
INFO - 2021-06-29 09:22:32 --> URI Class Initialized
INFO - 2021-06-29 09:22:32 --> Output Class Initialized
INFO - 2021-06-29 09:22:32 --> Output Class Initialized
INFO - 2021-06-29 09:22:32 --> Security Class Initialized
INFO - 2021-06-29 09:22:32 --> Security Class Initialized
DEBUG - 2021-06-29 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:32 --> Router Class Initialized
INFO - 2021-06-29 09:22:32 --> Input Class Initialized
INFO - 2021-06-29 09:22:32 --> Language Class Initialized
DEBUG - 2021-06-29 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:32 --> Input Class Initialized
INFO - 2021-06-29 09:22:32 --> Output Class Initialized
INFO - 2021-06-29 09:22:32 --> Language Class Initialized
INFO - 2021-06-29 09:22:32 --> Security Class Initialized
DEBUG - 2021-06-29 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:22:32 --> Input Class Initialized
INFO - 2021-06-29 09:22:32 --> Language Class Initialized
ERROR - 2021-06-29 09:22:32 --> 404 Page Not Found: /index
ERROR - 2021-06-29 09:22:32 --> 404 Page Not Found: /index
ERROR - 2021-06-29 09:22:32 --> 404 Page Not Found: /index
INFO - 2021-06-29 09:23:32 --> Config Class Initialized
INFO - 2021-06-29 09:23:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:23:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:23:32 --> Utf8 Class Initialized
INFO - 2021-06-29 09:23:32 --> URI Class Initialized
INFO - 2021-06-29 09:23:32 --> Config Class Initialized
INFO - 2021-06-29 09:23:32 --> Hooks Class Initialized
INFO - 2021-06-29 09:23:32 --> Router Class Initialized
INFO - 2021-06-29 09:23:32 --> Output Class Initialized
DEBUG - 2021-06-29 09:23:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:23:32 --> Utf8 Class Initialized
INFO - 2021-06-29 09:23:32 --> Security Class Initialized
DEBUG - 2021-06-29 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:23:32 --> Input Class Initialized
INFO - 2021-06-29 09:23:32 --> Language Class Initialized
INFO - 2021-06-29 09:23:32 --> Config Class Initialized
ERROR - 2021-06-29 09:23:32 --> 404 Page Not Found: /index
INFO - 2021-06-29 09:23:32 --> Hooks Class Initialized
INFO - 2021-06-29 09:23:32 --> URI Class Initialized
INFO - 2021-06-29 09:23:32 --> Router Class Initialized
DEBUG - 2021-06-29 09:23:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:23:32 --> Utf8 Class Initialized
INFO - 2021-06-29 09:23:32 --> URI Class Initialized
INFO - 2021-06-29 09:23:32 --> Output Class Initialized
INFO - 2021-06-29 09:23:32 --> Router Class Initialized
INFO - 2021-06-29 09:23:32 --> Security Class Initialized
INFO - 2021-06-29 09:23:32 --> Output Class Initialized
INFO - 2021-06-29 09:23:32 --> Security Class Initialized
DEBUG - 2021-06-29 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:23:32 --> Input Class Initialized
DEBUG - 2021-06-29 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:23:32 --> Input Class Initialized
INFO - 2021-06-29 09:23:32 --> Language Class Initialized
ERROR - 2021-06-29 09:23:32 --> 404 Page Not Found: /index
INFO - 2021-06-29 09:23:32 --> Language Class Initialized
ERROR - 2021-06-29 09:23:32 --> 404 Page Not Found: /index
INFO - 2021-06-29 11:26:42 --> Config Class Initialized
INFO - 2021-06-29 11:26:42 --> Hooks Class Initialized
DEBUG - 2021-06-29 11:26:42 --> UTF-8 Support Enabled
INFO - 2021-06-29 11:26:42 --> Utf8 Class Initialized
INFO - 2021-06-29 11:26:42 --> URI Class Initialized
INFO - 2021-06-29 11:26:42 --> Router Class Initialized
INFO - 2021-06-29 11:26:42 --> Output Class Initialized
INFO - 2021-06-29 11:26:42 --> Security Class Initialized
DEBUG - 2021-06-29 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 11:26:42 --> Input Class Initialized
INFO - 2021-06-29 11:26:42 --> Language Class Initialized
INFO - 2021-06-29 11:26:42 --> Language Class Initialized
INFO - 2021-06-29 11:26:42 --> Config Class Initialized
INFO - 2021-06-29 11:26:42 --> Loader Class Initialized
INFO - 2021-06-29 11:26:42 --> Helper loaded: url_helper
INFO - 2021-06-29 11:26:42 --> Helper loaded: file_helper
INFO - 2021-06-29 11:26:42 --> Helper loaded: common_helper
INFO - 2021-06-29 11:26:42 --> Database Driver Class Initialized
INFO - 2021-06-29 11:26:42 --> Email Class Initialized
INFO - 2021-06-29 11:26:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 11:26:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 11:26:42 --> Encryption Class Initialized
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Helper loaded: inflector_helper
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Controller Class Initialized
DEBUG - 2021-06-29 11:26:42 --> Card MX_Controller Initialized
INFO - 2021-06-29 11:26:42 --> Config Class Initialized
INFO - 2021-06-29 11:26:42 --> Hooks Class Initialized
DEBUG - 2021-06-29 11:26:42 --> UTF-8 Support Enabled
INFO - 2021-06-29 11:26:42 --> Utf8 Class Initialized
INFO - 2021-06-29 11:26:42 --> URI Class Initialized
INFO - 2021-06-29 11:26:42 --> Router Class Initialized
INFO - 2021-06-29 11:26:42 --> Output Class Initialized
INFO - 2021-06-29 11:26:42 --> Security Class Initialized
DEBUG - 2021-06-29 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 11:26:42 --> Input Class Initialized
INFO - 2021-06-29 11:26:42 --> Language Class Initialized
INFO - 2021-06-29 11:26:42 --> Language Class Initialized
INFO - 2021-06-29 11:26:42 --> Config Class Initialized
INFO - 2021-06-29 11:26:42 --> Loader Class Initialized
INFO - 2021-06-29 11:26:42 --> Helper loaded: url_helper
INFO - 2021-06-29 11:26:42 --> Helper loaded: file_helper
INFO - 2021-06-29 11:26:42 --> Helper loaded: common_helper
INFO - 2021-06-29 11:26:42 --> Database Driver Class Initialized
INFO - 2021-06-29 11:26:42 --> Email Class Initialized
INFO - 2021-06-29 11:26:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 11:26:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 11:26:42 --> Encryption Class Initialized
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Helper loaded: inflector_helper
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Model Class Initialized
INFO - 2021-06-29 11:26:42 --> Controller Class Initialized
DEBUG - 2021-06-29 11:26:42 --> Admin MX_Controller Initialized
DEBUG - 2021-06-29 11:26:42 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-06-29 11:26:42 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-06-29 11:26:42 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-06-29 11:26:42 --> Final output sent to browser
DEBUG - 2021-06-29 11:26:42 --> Total execution time: 0.0937
INFO - 2021-06-29 14:12:36 --> Config Class Initialized
INFO - 2021-06-29 14:12:36 --> Hooks Class Initialized
DEBUG - 2021-06-29 14:12:36 --> UTF-8 Support Enabled
INFO - 2021-06-29 14:12:36 --> Utf8 Class Initialized
INFO - 2021-06-29 14:12:36 --> URI Class Initialized
INFO - 2021-06-29 14:12:36 --> Router Class Initialized
INFO - 2021-06-29 14:12:36 --> Output Class Initialized
INFO - 2021-06-29 14:12:36 --> Security Class Initialized
DEBUG - 2021-06-29 14:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 14:12:36 --> Input Class Initialized
INFO - 2021-06-29 14:12:36 --> Language Class Initialized
INFO - 2021-06-29 14:12:36 --> Language Class Initialized
INFO - 2021-06-29 14:12:36 --> Config Class Initialized
INFO - 2021-06-29 14:12:36 --> Loader Class Initialized
INFO - 2021-06-29 14:12:36 --> Helper loaded: url_helper
INFO - 2021-06-29 14:12:36 --> Helper loaded: file_helper
INFO - 2021-06-29 14:12:36 --> Helper loaded: common_helper
INFO - 2021-06-29 14:12:36 --> Database Driver Class Initialized
INFO - 2021-06-29 14:12:36 --> Email Class Initialized
INFO - 2021-06-29 14:12:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-06-29 14:12:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-29 14:12:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-29 14:12:37 --> Encryption Class Initialized
INFO - 2021-06-29 14:12:37 --> Model Class Initialized
INFO - 2021-06-29 14:12:37 --> Helper loaded: inflector_helper
INFO - 2021-06-29 14:12:37 --> Model Class Initialized
INFO - 2021-06-29 14:12:37 --> Model Class Initialized
INFO - 2021-06-29 14:12:37 --> Controller Class Initialized
DEBUG - 2021-06-29 14:12:37 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\welcome_message.php
INFO - 2021-06-29 14:12:37 --> Final output sent to browser
DEBUG - 2021-06-29 14:12:37 --> Total execution time: 0.1492
INFO - 2021-06-29 16:29:52 --> Config Class Initialized
INFO - 2021-06-29 16:29:52 --> Config Class Initialized
INFO - 2021-06-29 16:29:52 --> Config Class Initialized
INFO - 2021-06-29 16:29:52 --> Hooks Class Initialized
INFO - 2021-06-29 16:29:52 --> Hooks Class Initialized
INFO - 2021-06-29 16:29:52 --> Hooks Class Initialized
DEBUG - 2021-06-29 16:29:52 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:29:52 --> Utf8 Class Initialized
DEBUG - 2021-06-29 16:29:52 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:29:52 --> URI Class Initialized
INFO - 2021-06-29 16:29:52 --> Utf8 Class Initialized
DEBUG - 2021-06-29 16:29:52 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:29:52 --> Utf8 Class Initialized
INFO - 2021-06-29 16:29:52 --> URI Class Initialized
INFO - 2021-06-29 16:29:52 --> URI Class Initialized
INFO - 2021-06-29 16:29:52 --> Router Class Initialized
INFO - 2021-06-29 16:29:52 --> Router Class Initialized
INFO - 2021-06-29 16:29:52 --> Router Class Initialized
INFO - 2021-06-29 16:29:52 --> Output Class Initialized
INFO - 2021-06-29 16:29:52 --> Output Class Initialized
INFO - 2021-06-29 16:29:52 --> Output Class Initialized
INFO - 2021-06-29 16:29:52 --> Security Class Initialized
INFO - 2021-06-29 16:29:52 --> Security Class Initialized
DEBUG - 2021-06-29 16:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-06-29 16:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 16:29:52 --> Input Class Initialized
INFO - 2021-06-29 16:29:52 --> Input Class Initialized
INFO - 2021-06-29 16:29:52 --> Language Class Initialized
INFO - 2021-06-29 16:29:52 --> Language Class Initialized
INFO - 2021-06-29 16:29:52 --> Security Class Initialized
ERROR - 2021-06-29 16:29:52 --> 404 Page Not Found: /index
DEBUG - 2021-06-29 16:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 16:29:52 --> Input Class Initialized
INFO - 2021-06-29 16:29:52 --> Language Class Initialized
ERROR - 2021-06-29 16:29:52 --> 404 Page Not Found: /index
ERROR - 2021-06-29 16:29:52 --> 404 Page Not Found: /index
INFO - 2021-06-29 16:32:08 --> Config Class Initialized
INFO - 2021-06-29 16:32:08 --> Hooks Class Initialized
DEBUG - 2021-06-29 16:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:32:08 --> Utf8 Class Initialized
INFO - 2021-06-29 16:32:08 --> URI Class Initialized
INFO - 2021-06-29 16:32:08 --> Router Class Initialized
INFO - 2021-06-29 16:32:08 --> Output Class Initialized
INFO - 2021-06-29 16:32:08 --> Security Class Initialized
INFO - 2021-06-29 16:32:08 --> Config Class Initialized
INFO - 2021-06-29 16:32:08 --> Hooks Class Initialized
DEBUG - 2021-06-29 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 16:32:08 --> Input Class Initialized
DEBUG - 2021-06-29 16:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:32:08 --> Language Class Initialized
INFO - 2021-06-29 16:32:08 --> Utf8 Class Initialized
INFO - 2021-06-29 16:32:08 --> Config Class Initialized
INFO - 2021-06-29 16:32:08 --> Hooks Class Initialized
INFO - 2021-06-29 16:32:08 --> URI Class Initialized
ERROR - 2021-06-29 16:32:08 --> 404 Page Not Found: /index
DEBUG - 2021-06-29 16:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-29 16:32:08 --> Utf8 Class Initialized
INFO - 2021-06-29 16:32:08 --> Router Class Initialized
INFO - 2021-06-29 16:32:08 --> URI Class Initialized
INFO - 2021-06-29 16:32:08 --> Output Class Initialized
INFO - 2021-06-29 16:32:08 --> Security Class Initialized
INFO - 2021-06-29 16:32:08 --> Router Class Initialized
DEBUG - 2021-06-29 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 16:32:08 --> Input Class Initialized
INFO - 2021-06-29 16:32:08 --> Language Class Initialized
INFO - 2021-06-29 16:32:08 --> Output Class Initialized
ERROR - 2021-06-29 16:32:08 --> 404 Page Not Found: /index
INFO - 2021-06-29 16:32:08 --> Security Class Initialized
DEBUG - 2021-06-29 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 16:32:08 --> Input Class Initialized
INFO - 2021-06-29 16:32:08 --> Language Class Initialized
ERROR - 2021-06-29 16:32:08 --> 404 Page Not Found: /index
