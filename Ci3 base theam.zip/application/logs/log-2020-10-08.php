<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-08 05:25:37 --> Config Class Initialized
INFO - 2020-10-08 05:25:37 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:25:37 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:25:37 --> Utf8 Class Initialized
INFO - 2020-10-08 05:25:37 --> URI Class Initialized
DEBUG - 2020-10-08 05:25:37 --> No URI present. Default controller set.
INFO - 2020-10-08 05:25:37 --> Router Class Initialized
INFO - 2020-10-08 05:25:37 --> Output Class Initialized
INFO - 2020-10-08 05:25:37 --> Security Class Initialized
DEBUG - 2020-10-08 05:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:25:37 --> Input Class Initialized
INFO - 2020-10-08 05:25:37 --> Language Class Initialized
INFO - 2020-10-08 05:25:37 --> Language Class Initialized
INFO - 2020-10-08 05:25:37 --> Config Class Initialized
INFO - 2020-10-08 05:25:37 --> Loader Class Initialized
INFO - 2020-10-08 05:25:37 --> Helper loaded: url_helper
INFO - 2020-10-08 05:25:37 --> Helper loaded: file_helper
INFO - 2020-10-08 05:25:37 --> Database Driver Class Initialized
INFO - 2020-10-08 05:25:37 --> Email Class Initialized
INFO - 2020-10-08 05:25:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:25:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:25:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:25:38 --> Encryption Class Initialized
INFO - 2020-10-08 05:25:38 --> Model Class Initialized
INFO - 2020-10-08 05:25:38 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:25:38 --> Model Class Initialized
INFO - 2020-10-08 05:25:38 --> Model Class Initialized
INFO - 2020-10-08 05:25:38 --> Controller Class Initialized
DEBUG - 2020-10-08 05:25:38 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:25:38 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:25:38 --> Final output sent to browser
DEBUG - 2020-10-08 05:25:38 --> Total execution time: 1.0000
INFO - 2020-10-08 05:30:01 --> Config Class Initialized
INFO - 2020-10-08 05:30:01 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:30:01 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:30:01 --> Utf8 Class Initialized
INFO - 2020-10-08 05:30:01 --> URI Class Initialized
DEBUG - 2020-10-08 05:30:01 --> No URI present. Default controller set.
INFO - 2020-10-08 05:30:01 --> Router Class Initialized
INFO - 2020-10-08 05:30:01 --> Output Class Initialized
INFO - 2020-10-08 05:30:01 --> Security Class Initialized
DEBUG - 2020-10-08 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:30:01 --> Input Class Initialized
INFO - 2020-10-08 05:30:01 --> Language Class Initialized
INFO - 2020-10-08 05:30:01 --> Language Class Initialized
INFO - 2020-10-08 05:30:01 --> Config Class Initialized
INFO - 2020-10-08 05:30:01 --> Loader Class Initialized
INFO - 2020-10-08 05:30:01 --> Helper loaded: url_helper
INFO - 2020-10-08 05:30:01 --> Helper loaded: file_helper
INFO - 2020-10-08 05:30:01 --> Database Driver Class Initialized
INFO - 2020-10-08 05:30:01 --> Email Class Initialized
INFO - 2020-10-08 05:30:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:30:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:30:01 --> Encryption Class Initialized
INFO - 2020-10-08 05:30:01 --> Model Class Initialized
INFO - 2020-10-08 05:30:01 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:30:01 --> Model Class Initialized
INFO - 2020-10-08 05:30:01 --> Model Class Initialized
INFO - 2020-10-08 05:30:01 --> Controller Class Initialized
DEBUG - 2020-10-08 05:30:01 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:30:01 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:30:01 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:30:01 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:30:01 --> Final output sent to browser
DEBUG - 2020-10-08 05:30:01 --> Total execution time: 0.4792
INFO - 2020-10-08 05:30:40 --> Config Class Initialized
INFO - 2020-10-08 05:30:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:30:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:30:40 --> Utf8 Class Initialized
INFO - 2020-10-08 05:30:40 --> URI Class Initialized
DEBUG - 2020-10-08 05:30:40 --> No URI present. Default controller set.
INFO - 2020-10-08 05:30:40 --> Router Class Initialized
INFO - 2020-10-08 05:30:40 --> Output Class Initialized
INFO - 2020-10-08 05:30:40 --> Security Class Initialized
DEBUG - 2020-10-08 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:30:40 --> Input Class Initialized
INFO - 2020-10-08 05:30:40 --> Language Class Initialized
INFO - 2020-10-08 05:30:40 --> Language Class Initialized
INFO - 2020-10-08 05:30:40 --> Config Class Initialized
INFO - 2020-10-08 05:30:40 --> Loader Class Initialized
INFO - 2020-10-08 05:30:40 --> Helper loaded: url_helper
INFO - 2020-10-08 05:30:40 --> Helper loaded: file_helper
INFO - 2020-10-08 05:30:40 --> Database Driver Class Initialized
INFO - 2020-10-08 05:30:40 --> Email Class Initialized
INFO - 2020-10-08 05:30:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:30:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:30:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:30:40 --> Encryption Class Initialized
INFO - 2020-10-08 05:30:40 --> Model Class Initialized
INFO - 2020-10-08 05:30:40 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:30:40 --> Model Class Initialized
INFO - 2020-10-08 05:30:40 --> Model Class Initialized
INFO - 2020-10-08 05:30:40 --> Controller Class Initialized
DEBUG - 2020-10-08 05:30:40 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:30:40 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:30:40 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:30:40 --> File loaded: A:\Xampp\htdocs\salim_works\HighwayTreat\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:30:40 --> Final output sent to browser
DEBUG - 2020-10-08 05:30:40 --> Total execution time: 0.4675
INFO - 2020-10-08 05:36:29 --> Config Class Initialized
INFO - 2020-10-08 05:36:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:36:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:36:29 --> Utf8 Class Initialized
INFO - 2020-10-08 05:36:29 --> URI Class Initialized
DEBUG - 2020-10-08 05:36:29 --> No URI present. Default controller set.
INFO - 2020-10-08 05:36:29 --> Router Class Initialized
INFO - 2020-10-08 05:36:29 --> Output Class Initialized
INFO - 2020-10-08 05:36:29 --> Security Class Initialized
DEBUG - 2020-10-08 05:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:36:29 --> Input Class Initialized
INFO - 2020-10-08 05:36:29 --> Language Class Initialized
INFO - 2020-10-08 05:36:29 --> Language Class Initialized
INFO - 2020-10-08 05:36:29 --> Config Class Initialized
INFO - 2020-10-08 05:36:29 --> Loader Class Initialized
INFO - 2020-10-08 05:36:29 --> Helper loaded: url_helper
INFO - 2020-10-08 05:36:29 --> Helper loaded: file_helper
INFO - 2020-10-08 05:36:29 --> Database Driver Class Initialized
INFO - 2020-10-08 05:36:29 --> Email Class Initialized
INFO - 2020-10-08 05:36:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:36:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:36:30 --> Encryption Class Initialized
INFO - 2020-10-08 05:36:30 --> Model Class Initialized
INFO - 2020-10-08 05:36:30 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:36:30 --> Model Class Initialized
INFO - 2020-10-08 05:36:30 --> Model Class Initialized
INFO - 2020-10-08 05:36:30 --> Controller Class Initialized
DEBUG - 2020-10-08 05:36:30 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:36:30 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheam\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:36:30 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheam\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:36:30 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheam\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:36:30 --> Final output sent to browser
DEBUG - 2020-10-08 05:36:30 --> Total execution time: 0.9116
INFO - 2020-10-08 05:38:46 --> Config Class Initialized
INFO - 2020-10-08 05:38:46 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:38:46 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:38:46 --> Utf8 Class Initialized
INFO - 2020-10-08 05:38:46 --> URI Class Initialized
DEBUG - 2020-10-08 05:38:46 --> No URI present. Default controller set.
INFO - 2020-10-08 05:38:46 --> Router Class Initialized
INFO - 2020-10-08 05:38:46 --> Output Class Initialized
INFO - 2020-10-08 05:38:46 --> Security Class Initialized
DEBUG - 2020-10-08 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:38:46 --> Input Class Initialized
INFO - 2020-10-08 05:38:46 --> Language Class Initialized
INFO - 2020-10-08 05:38:46 --> Language Class Initialized
INFO - 2020-10-08 05:38:46 --> Config Class Initialized
INFO - 2020-10-08 05:38:46 --> Loader Class Initialized
INFO - 2020-10-08 05:38:46 --> Helper loaded: url_helper
INFO - 2020-10-08 05:38:46 --> Helper loaded: file_helper
INFO - 2020-10-08 05:38:46 --> Database Driver Class Initialized
INFO - 2020-10-08 05:38:46 --> Email Class Initialized
INFO - 2020-10-08 05:38:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:38:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:38:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:38:46 --> Encryption Class Initialized
INFO - 2020-10-08 05:38:46 --> Model Class Initialized
INFO - 2020-10-08 05:38:46 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:38:46 --> Model Class Initialized
INFO - 2020-10-08 05:38:46 --> Model Class Initialized
INFO - 2020-10-08 05:38:46 --> Controller Class Initialized
DEBUG - 2020-10-08 05:38:46 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:38:46 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:38:46 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:38:46 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:38:46 --> Final output sent to browser
DEBUG - 2020-10-08 05:38:46 --> Total execution time: 0.3954
INFO - 2020-10-08 05:47:08 --> Config Class Initialized
INFO - 2020-10-08 05:47:08 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:47:08 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:47:08 --> Utf8 Class Initialized
INFO - 2020-10-08 05:47:08 --> URI Class Initialized
DEBUG - 2020-10-08 05:47:08 --> No URI present. Default controller set.
INFO - 2020-10-08 05:47:08 --> Router Class Initialized
INFO - 2020-10-08 05:47:08 --> Output Class Initialized
INFO - 2020-10-08 05:47:08 --> Security Class Initialized
DEBUG - 2020-10-08 05:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:47:08 --> Input Class Initialized
INFO - 2020-10-08 05:47:08 --> Language Class Initialized
INFO - 2020-10-08 05:47:08 --> Language Class Initialized
INFO - 2020-10-08 05:47:08 --> Config Class Initialized
INFO - 2020-10-08 05:47:08 --> Loader Class Initialized
INFO - 2020-10-08 05:47:08 --> Helper loaded: url_helper
INFO - 2020-10-08 05:47:09 --> Helper loaded: file_helper
INFO - 2020-10-08 05:47:09 --> Database Driver Class Initialized
INFO - 2020-10-08 05:47:09 --> Email Class Initialized
INFO - 2020-10-08 05:47:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:47:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:47:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:47:09 --> Encryption Class Initialized
INFO - 2020-10-08 05:47:09 --> Model Class Initialized
INFO - 2020-10-08 05:47:09 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:47:09 --> Model Class Initialized
INFO - 2020-10-08 05:47:09 --> Model Class Initialized
INFO - 2020-10-08 05:47:09 --> Controller Class Initialized
DEBUG - 2020-10-08 05:47:09 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:47:09 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:47:09 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:47:09 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:47:09 --> Final output sent to browser
DEBUG - 2020-10-08 05:47:09 --> Total execution time: 0.4792
INFO - 2020-10-08 05:47:47 --> Config Class Initialized
INFO - 2020-10-08 05:47:47 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:47:47 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:47:47 --> Utf8 Class Initialized
INFO - 2020-10-08 05:47:47 --> URI Class Initialized
DEBUG - 2020-10-08 05:47:47 --> No URI present. Default controller set.
INFO - 2020-10-08 05:47:47 --> Router Class Initialized
INFO - 2020-10-08 05:47:47 --> Output Class Initialized
INFO - 2020-10-08 05:47:47 --> Security Class Initialized
DEBUG - 2020-10-08 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:47:47 --> Input Class Initialized
INFO - 2020-10-08 05:47:47 --> Language Class Initialized
INFO - 2020-10-08 05:47:47 --> Language Class Initialized
INFO - 2020-10-08 05:47:47 --> Config Class Initialized
INFO - 2020-10-08 05:47:47 --> Loader Class Initialized
INFO - 2020-10-08 05:47:47 --> Helper loaded: url_helper
INFO - 2020-10-08 05:47:47 --> Helper loaded: file_helper
INFO - 2020-10-08 05:47:47 --> Database Driver Class Initialized
INFO - 2020-10-08 05:47:47 --> Email Class Initialized
INFO - 2020-10-08 05:47:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:47:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:47:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:47:47 --> Encryption Class Initialized
INFO - 2020-10-08 05:47:47 --> Model Class Initialized
INFO - 2020-10-08 05:47:47 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:47:47 --> Model Class Initialized
INFO - 2020-10-08 05:47:47 --> Model Class Initialized
INFO - 2020-10-08 05:47:47 --> Controller Class Initialized
DEBUG - 2020-10-08 05:47:47 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:47:47 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:47:47 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:47:47 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:47:47 --> Final output sent to browser
DEBUG - 2020-10-08 05:47:47 --> Total execution time: 0.4901
INFO - 2020-10-08 05:48:37 --> Config Class Initialized
INFO - 2020-10-08 05:48:37 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:48:37 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:48:37 --> Utf8 Class Initialized
INFO - 2020-10-08 05:48:37 --> URI Class Initialized
DEBUG - 2020-10-08 05:48:37 --> No URI present. Default controller set.
INFO - 2020-10-08 05:48:37 --> Router Class Initialized
INFO - 2020-10-08 05:48:37 --> Output Class Initialized
INFO - 2020-10-08 05:48:37 --> Security Class Initialized
DEBUG - 2020-10-08 05:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:48:37 --> Input Class Initialized
INFO - 2020-10-08 05:48:37 --> Language Class Initialized
INFO - 2020-10-08 05:48:37 --> Language Class Initialized
INFO - 2020-10-08 05:48:37 --> Config Class Initialized
INFO - 2020-10-08 05:48:37 --> Loader Class Initialized
INFO - 2020-10-08 05:48:37 --> Helper loaded: url_helper
INFO - 2020-10-08 05:48:37 --> Helper loaded: file_helper
INFO - 2020-10-08 05:48:37 --> Database Driver Class Initialized
INFO - 2020-10-08 05:48:37 --> Email Class Initialized
INFO - 2020-10-08 05:48:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:48:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:48:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:48:37 --> Encryption Class Initialized
INFO - 2020-10-08 05:48:37 --> Model Class Initialized
INFO - 2020-10-08 05:48:37 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:48:37 --> Model Class Initialized
INFO - 2020-10-08 05:48:37 --> Model Class Initialized
INFO - 2020-10-08 05:48:37 --> Controller Class Initialized
DEBUG - 2020-10-08 05:48:37 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:48:37 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:48:37 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:48:37 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:48:37 --> Final output sent to browser
DEBUG - 2020-10-08 05:48:37 --> Total execution time: 0.4025
INFO - 2020-10-08 05:48:44 --> Config Class Initialized
INFO - 2020-10-08 05:48:44 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:48:44 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:48:44 --> Utf8 Class Initialized
INFO - 2020-10-08 05:48:44 --> URI Class Initialized
DEBUG - 2020-10-08 05:48:44 --> No URI present. Default controller set.
INFO - 2020-10-08 05:48:44 --> Router Class Initialized
INFO - 2020-10-08 05:48:44 --> Output Class Initialized
INFO - 2020-10-08 05:48:44 --> Security Class Initialized
DEBUG - 2020-10-08 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:48:44 --> Input Class Initialized
INFO - 2020-10-08 05:48:44 --> Language Class Initialized
INFO - 2020-10-08 05:48:44 --> Language Class Initialized
INFO - 2020-10-08 05:48:44 --> Config Class Initialized
INFO - 2020-10-08 05:48:44 --> Loader Class Initialized
INFO - 2020-10-08 05:48:44 --> Helper loaded: url_helper
INFO - 2020-10-08 05:48:44 --> Helper loaded: file_helper
INFO - 2020-10-08 05:48:44 --> Database Driver Class Initialized
INFO - 2020-10-08 05:48:44 --> Email Class Initialized
INFO - 2020-10-08 05:48:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:48:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:48:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:48:44 --> Encryption Class Initialized
INFO - 2020-10-08 05:48:44 --> Model Class Initialized
INFO - 2020-10-08 05:48:44 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:48:44 --> Model Class Initialized
INFO - 2020-10-08 05:48:44 --> Model Class Initialized
INFO - 2020-10-08 05:48:44 --> Controller Class Initialized
DEBUG - 2020-10-08 05:48:44 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:48:44 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:48:44 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:48:44 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:48:44 --> Final output sent to browser
DEBUG - 2020-10-08 05:48:44 --> Total execution time: 0.4796
INFO - 2020-10-08 05:48:47 --> Config Class Initialized
INFO - 2020-10-08 05:48:47 --> Config Class Initialized
INFO - 2020-10-08 05:48:47 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:48:47 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:48:47 --> Utf8 Class Initialized
INFO - 2020-10-08 05:48:47 --> URI Class Initialized
INFO - 2020-10-08 05:48:47 --> Router Class Initialized
INFO - 2020-10-08 05:48:47 --> Config Class Initialized
INFO - 2020-10-08 05:48:47 --> Hooks Class Initialized
INFO - 2020-10-08 05:48:47 --> Output Class Initialized
INFO - 2020-10-08 05:48:47 --> Security Class Initialized
DEBUG - 2020-10-08 05:48:47 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:48:47 --> Utf8 Class Initialized
DEBUG - 2020-10-08 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:48:47 --> Input Class Initialized
INFO - 2020-10-08 05:48:47 --> Language Class Initialized
INFO - 2020-10-08 05:48:47 --> URI Class Initialized
ERROR - 2020-10-08 05:48:47 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:48:47 --> Router Class Initialized
INFO - 2020-10-08 05:48:47 --> Output Class Initialized
INFO - 2020-10-08 05:48:47 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:48:47 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:48:47 --> Utf8 Class Initialized
INFO - 2020-10-08 05:48:47 --> URI Class Initialized
INFO - 2020-10-08 05:48:47 --> Router Class Initialized
INFO - 2020-10-08 05:48:47 --> Output Class Initialized
INFO - 2020-10-08 05:48:47 --> Security Class Initialized
DEBUG - 2020-10-08 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:48:47 --> Input Class Initialized
INFO - 2020-10-08 05:48:47 --> Language Class Initialized
ERROR - 2020-10-08 05:48:47 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:48:47 --> Security Class Initialized
DEBUG - 2020-10-08 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:48:47 --> Input Class Initialized
INFO - 2020-10-08 05:48:47 --> Language Class Initialized
ERROR - 2020-10-08 05:48:47 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:49:45 --> Config Class Initialized
INFO - 2020-10-08 05:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:49:45 --> Utf8 Class Initialized
INFO - 2020-10-08 05:49:45 --> URI Class Initialized
DEBUG - 2020-10-08 05:49:45 --> No URI present. Default controller set.
INFO - 2020-10-08 05:49:45 --> Router Class Initialized
INFO - 2020-10-08 05:49:45 --> Output Class Initialized
INFO - 2020-10-08 05:49:45 --> Security Class Initialized
DEBUG - 2020-10-08 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:49:45 --> Input Class Initialized
INFO - 2020-10-08 05:49:45 --> Language Class Initialized
INFO - 2020-10-08 05:49:45 --> Language Class Initialized
INFO - 2020-10-08 05:49:45 --> Config Class Initialized
INFO - 2020-10-08 05:49:45 --> Loader Class Initialized
INFO - 2020-10-08 05:49:45 --> Helper loaded: url_helper
INFO - 2020-10-08 05:49:45 --> Helper loaded: file_helper
INFO - 2020-10-08 05:49:45 --> Database Driver Class Initialized
INFO - 2020-10-08 05:49:45 --> Email Class Initialized
INFO - 2020-10-08 05:49:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:49:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:49:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:49:45 --> Encryption Class Initialized
INFO - 2020-10-08 05:49:45 --> Model Class Initialized
INFO - 2020-10-08 05:49:45 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:49:45 --> Model Class Initialized
INFO - 2020-10-08 05:49:45 --> Model Class Initialized
INFO - 2020-10-08 05:49:45 --> Controller Class Initialized
DEBUG - 2020-10-08 05:49:45 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:49:45 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:49:45 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:49:45 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:49:45 --> Final output sent to browser
DEBUG - 2020-10-08 05:49:45 --> Total execution time: 0.6035
INFO - 2020-10-08 05:49:45 --> Config Class Initialized
INFO - 2020-10-08 05:49:45 --> Config Class Initialized
INFO - 2020-10-08 05:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:49:45 --> Utf8 Class Initialized
INFO - 2020-10-08 05:49:45 --> URI Class Initialized
INFO - 2020-10-08 05:49:45 --> Router Class Initialized
INFO - 2020-10-08 05:49:45 --> Output Class Initialized
INFO - 2020-10-08 05:49:45 --> Security Class Initialized
DEBUG - 2020-10-08 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:49:45 --> Input Class Initialized
INFO - 2020-10-08 05:49:45 --> Language Class Initialized
ERROR - 2020-10-08 05:49:45 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:49:45 --> Hooks Class Initialized
INFO - 2020-10-08 05:49:45 --> Config Class Initialized
INFO - 2020-10-08 05:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:49:45 --> Utf8 Class Initialized
INFO - 2020-10-08 05:49:45 --> URI Class Initialized
INFO - 2020-10-08 05:49:45 --> Router Class Initialized
DEBUG - 2020-10-08 05:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:49:45 --> Utf8 Class Initialized
INFO - 2020-10-08 05:49:45 --> URI Class Initialized
INFO - 2020-10-08 05:49:45 --> Router Class Initialized
INFO - 2020-10-08 05:49:45 --> Output Class Initialized
INFO - 2020-10-08 05:49:45 --> Security Class Initialized
DEBUG - 2020-10-08 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:49:45 --> Input Class Initialized
INFO - 2020-10-08 05:49:45 --> Language Class Initialized
INFO - 2020-10-08 05:49:45 --> Output Class Initialized
INFO - 2020-10-08 05:49:45 --> Security Class Initialized
DEBUG - 2020-10-08 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:49:45 --> Input Class Initialized
INFO - 2020-10-08 05:49:45 --> Language Class Initialized
ERROR - 2020-10-08 05:49:45 --> 404 Page Not Found: /index
ERROR - 2020-10-08 05:49:45 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:50:05 --> Config Class Initialized
INFO - 2020-10-08 05:50:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:05 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:05 --> URI Class Initialized
DEBUG - 2020-10-08 05:50:05 --> No URI present. Default controller set.
INFO - 2020-10-08 05:50:05 --> Router Class Initialized
INFO - 2020-10-08 05:50:05 --> Output Class Initialized
INFO - 2020-10-08 05:50:05 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:05 --> Input Class Initialized
INFO - 2020-10-08 05:50:05 --> Language Class Initialized
INFO - 2020-10-08 05:50:05 --> Language Class Initialized
INFO - 2020-10-08 05:50:05 --> Config Class Initialized
INFO - 2020-10-08 05:50:05 --> Loader Class Initialized
INFO - 2020-10-08 05:50:05 --> Helper loaded: url_helper
INFO - 2020-10-08 05:50:05 --> Helper loaded: file_helper
INFO - 2020-10-08 05:50:05 --> Database Driver Class Initialized
INFO - 2020-10-08 05:50:05 --> Email Class Initialized
INFO - 2020-10-08 05:50:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:50:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:50:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:50:05 --> Encryption Class Initialized
INFO - 2020-10-08 05:50:05 --> Model Class Initialized
INFO - 2020-10-08 05:50:05 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:50:06 --> Model Class Initialized
INFO - 2020-10-08 05:50:06 --> Model Class Initialized
INFO - 2020-10-08 05:50:06 --> Controller Class Initialized
DEBUG - 2020-10-08 05:50:06 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:50:06 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:50:06 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:50:06 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:50:06 --> Final output sent to browser
DEBUG - 2020-10-08 05:50:06 --> Total execution time: 0.5470
INFO - 2020-10-08 05:50:06 --> Config Class Initialized
INFO - 2020-10-08 05:50:06 --> Config Class Initialized
INFO - 2020-10-08 05:50:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:06 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:06 --> URI Class Initialized
INFO - 2020-10-08 05:50:06 --> Config Class Initialized
INFO - 2020-10-08 05:50:06 --> Hooks Class Initialized
INFO - 2020-10-08 05:50:06 --> Router Class Initialized
DEBUG - 2020-10-08 05:50:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:06 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:06 --> Output Class Initialized
INFO - 2020-10-08 05:50:06 --> URI Class Initialized
INFO - 2020-10-08 05:50:06 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:06 --> Router Class Initialized
INFO - 2020-10-08 05:50:06 --> Input Class Initialized
INFO - 2020-10-08 05:50:06 --> Language Class Initialized
INFO - 2020-10-08 05:50:06 --> Output Class Initialized
ERROR - 2020-10-08 05:50:06 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:50:06 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:06 --> Input Class Initialized
INFO - 2020-10-08 05:50:06 --> Language Class Initialized
ERROR - 2020-10-08 05:50:06 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:50:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:06 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:06 --> URI Class Initialized
INFO - 2020-10-08 05:50:06 --> Router Class Initialized
INFO - 2020-10-08 05:50:06 --> Output Class Initialized
INFO - 2020-10-08 05:50:06 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:06 --> Input Class Initialized
INFO - 2020-10-08 05:50:06 --> Language Class Initialized
ERROR - 2020-10-08 05:50:06 --> 404 Page Not Found: /index
INFO - 2020-10-08 05:50:12 --> Config Class Initialized
INFO - 2020-10-08 05:50:12 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:12 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:12 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:12 --> URI Class Initialized
INFO - 2020-10-08 05:50:12 --> Router Class Initialized
INFO - 2020-10-08 05:50:12 --> Output Class Initialized
INFO - 2020-10-08 05:50:12 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:12 --> Input Class Initialized
INFO - 2020-10-08 05:50:12 --> Language Class Initialized
INFO - 2020-10-08 05:50:13 --> Language Class Initialized
INFO - 2020-10-08 05:50:13 --> Config Class Initialized
INFO - 2020-10-08 05:50:13 --> Loader Class Initialized
INFO - 2020-10-08 05:50:13 --> Helper loaded: url_helper
INFO - 2020-10-08 05:50:13 --> Helper loaded: file_helper
INFO - 2020-10-08 05:50:13 --> Database Driver Class Initialized
INFO - 2020-10-08 05:50:13 --> Email Class Initialized
INFO - 2020-10-08 05:50:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:50:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:50:13 --> Encryption Class Initialized
INFO - 2020-10-08 05:50:13 --> Model Class Initialized
INFO - 2020-10-08 05:50:13 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:50:13 --> Model Class Initialized
INFO - 2020-10-08 05:50:13 --> Model Class Initialized
INFO - 2020-10-08 05:50:13 --> Controller Class Initialized
DEBUG - 2020-10-08 05:50:13 --> Admin MX_Controller Initialized
INFO - 2020-10-08 05:50:13 --> Final output sent to browser
DEBUG - 2020-10-08 05:50:13 --> Total execution time: 0.3736
INFO - 2020-10-08 05:50:16 --> Config Class Initialized
INFO - 2020-10-08 05:50:16 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:16 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:16 --> URI Class Initialized
INFO - 2020-10-08 05:50:16 --> Router Class Initialized
INFO - 2020-10-08 05:50:16 --> Output Class Initialized
INFO - 2020-10-08 05:50:16 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:16 --> Input Class Initialized
INFO - 2020-10-08 05:50:16 --> Language Class Initialized
INFO - 2020-10-08 05:50:16 --> Language Class Initialized
INFO - 2020-10-08 05:50:16 --> Config Class Initialized
INFO - 2020-10-08 05:50:16 --> Loader Class Initialized
INFO - 2020-10-08 05:50:16 --> Helper loaded: url_helper
INFO - 2020-10-08 05:50:16 --> Helper loaded: file_helper
INFO - 2020-10-08 05:50:16 --> Database Driver Class Initialized
INFO - 2020-10-08 05:50:16 --> Email Class Initialized
INFO - 2020-10-08 05:50:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:50:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:50:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:50:16 --> Encryption Class Initialized
INFO - 2020-10-08 05:50:16 --> Model Class Initialized
INFO - 2020-10-08 05:50:16 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:50:16 --> Model Class Initialized
INFO - 2020-10-08 05:50:16 --> Model Class Initialized
INFO - 2020-10-08 05:50:16 --> Controller Class Initialized
DEBUG - 2020-10-08 05:50:16 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-10-08 05:50:16 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:50:17 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2020-10-08 05:50:17 --> Final output sent to browser
DEBUG - 2020-10-08 05:50:17 --> Total execution time: 0.7318
INFO - 2020-10-08 05:50:19 --> Config Class Initialized
INFO - 2020-10-08 05:50:19 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:19 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:19 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:19 --> URI Class Initialized
INFO - 2020-10-08 05:50:19 --> Router Class Initialized
INFO - 2020-10-08 05:50:19 --> Output Class Initialized
INFO - 2020-10-08 05:50:19 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:19 --> Input Class Initialized
INFO - 2020-10-08 05:50:19 --> Language Class Initialized
INFO - 2020-10-08 05:50:19 --> Language Class Initialized
INFO - 2020-10-08 05:50:19 --> Config Class Initialized
INFO - 2020-10-08 05:50:19 --> Loader Class Initialized
INFO - 2020-10-08 05:50:19 --> Helper loaded: url_helper
INFO - 2020-10-08 05:50:19 --> Helper loaded: file_helper
INFO - 2020-10-08 05:50:19 --> Database Driver Class Initialized
INFO - 2020-10-08 05:50:19 --> Email Class Initialized
INFO - 2020-10-08 05:50:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:50:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:50:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:50:19 --> Encryption Class Initialized
INFO - 2020-10-08 05:50:19 --> Model Class Initialized
INFO - 2020-10-08 05:50:19 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:50:19 --> Model Class Initialized
INFO - 2020-10-08 05:50:19 --> Model Class Initialized
INFO - 2020-10-08 05:50:19 --> Controller Class Initialized
DEBUG - 2020-10-08 05:50:19 --> Card MX_Controller Initialized
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/new_card.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:50:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2020-10-08 05:50:19 --> Final output sent to browser
DEBUG - 2020-10-08 05:50:19 --> Total execution time: 0.5187
INFO - 2020-10-08 05:50:36 --> Config Class Initialized
INFO - 2020-10-08 05:50:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:50:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:50:36 --> Utf8 Class Initialized
INFO - 2020-10-08 05:50:36 --> URI Class Initialized
INFO - 2020-10-08 05:50:36 --> Router Class Initialized
INFO - 2020-10-08 05:50:36 --> Output Class Initialized
INFO - 2020-10-08 05:50:36 --> Security Class Initialized
DEBUG - 2020-10-08 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:50:36 --> Input Class Initialized
INFO - 2020-10-08 05:50:36 --> Language Class Initialized
INFO - 2020-10-08 05:50:36 --> Language Class Initialized
INFO - 2020-10-08 05:50:36 --> Config Class Initialized
INFO - 2020-10-08 05:50:36 --> Loader Class Initialized
INFO - 2020-10-08 05:50:36 --> Helper loaded: url_helper
INFO - 2020-10-08 05:50:36 --> Helper loaded: file_helper
INFO - 2020-10-08 05:50:36 --> Database Driver Class Initialized
INFO - 2020-10-08 05:50:36 --> Email Class Initialized
INFO - 2020-10-08 05:50:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:50:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:50:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:50:36 --> Encryption Class Initialized
INFO - 2020-10-08 05:50:36 --> Model Class Initialized
INFO - 2020-10-08 05:50:36 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:50:36 --> Model Class Initialized
INFO - 2020-10-08 05:50:36 --> Model Class Initialized
INFO - 2020-10-08 05:50:36 --> Controller Class Initialized
DEBUG - 2020-10-08 05:50:36 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-10-08 05:50:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:50:37 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2020-10-08 05:50:37 --> Final output sent to browser
DEBUG - 2020-10-08 05:50:37 --> Total execution time: 0.6512
INFO - 2020-10-08 05:53:39 --> Config Class Initialized
INFO - 2020-10-08 05:53:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:53:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:53:39 --> Utf8 Class Initialized
INFO - 2020-10-08 05:53:39 --> URI Class Initialized
INFO - 2020-10-08 05:53:39 --> Router Class Initialized
INFO - 2020-10-08 05:53:39 --> Output Class Initialized
INFO - 2020-10-08 05:53:39 --> Security Class Initialized
DEBUG - 2020-10-08 05:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:53:39 --> Input Class Initialized
INFO - 2020-10-08 05:53:39 --> Language Class Initialized
INFO - 2020-10-08 05:53:39 --> Language Class Initialized
INFO - 2020-10-08 05:53:39 --> Config Class Initialized
INFO - 2020-10-08 05:53:39 --> Loader Class Initialized
INFO - 2020-10-08 05:53:39 --> Helper loaded: url_helper
INFO - 2020-10-08 05:53:39 --> Helper loaded: file_helper
INFO - 2020-10-08 05:53:39 --> Helper loaded: common_helper
INFO - 2020-10-08 05:53:39 --> Database Driver Class Initialized
INFO - 2020-10-08 05:53:39 --> Email Class Initialized
INFO - 2020-10-08 05:53:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:53:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:53:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:53:39 --> Encryption Class Initialized
INFO - 2020-10-08 05:53:39 --> Model Class Initialized
INFO - 2020-10-08 05:53:39 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:53:39 --> Model Class Initialized
INFO - 2020-10-08 05:53:39 --> Model Class Initialized
INFO - 2020-10-08 05:53:39 --> Controller Class Initialized
DEBUG - 2020-10-08 05:53:39 --> Admin_dashboard MX_Controller Initialized
INFO - 2020-10-08 05:53:39 --> Config Class Initialized
INFO - 2020-10-08 05:53:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 05:53:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 05:53:39 --> Utf8 Class Initialized
INFO - 2020-10-08 05:53:39 --> URI Class Initialized
DEBUG - 2020-10-08 05:53:39 --> No URI present. Default controller set.
INFO - 2020-10-08 05:53:39 --> Router Class Initialized
INFO - 2020-10-08 05:53:39 --> Output Class Initialized
INFO - 2020-10-08 05:53:39 --> Security Class Initialized
DEBUG - 2020-10-08 05:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 05:53:39 --> Input Class Initialized
INFO - 2020-10-08 05:53:39 --> Language Class Initialized
INFO - 2020-10-08 05:53:39 --> Language Class Initialized
INFO - 2020-10-08 05:53:39 --> Config Class Initialized
INFO - 2020-10-08 05:53:39 --> Loader Class Initialized
INFO - 2020-10-08 05:53:39 --> Helper loaded: url_helper
INFO - 2020-10-08 05:53:39 --> Helper loaded: file_helper
INFO - 2020-10-08 05:53:39 --> Helper loaded: common_helper
INFO - 2020-10-08 05:53:39 --> Database Driver Class Initialized
INFO - 2020-10-08 05:53:39 --> Email Class Initialized
INFO - 2020-10-08 05:53:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-10-08 05:53:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-10-08 05:53:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-10-08 05:53:39 --> Encryption Class Initialized
INFO - 2020-10-08 05:53:39 --> Model Class Initialized
INFO - 2020-10-08 05:53:39 --> Helper loaded: inflector_helper
INFO - 2020-10-08 05:53:40 --> Model Class Initialized
INFO - 2020-10-08 05:53:40 --> Model Class Initialized
INFO - 2020-10-08 05:53:40 --> Controller Class Initialized
DEBUG - 2020-10-08 05:53:40 --> Admin MX_Controller Initialized
DEBUG - 2020-10-08 05:53:40 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-10-08 05:53:40 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-10-08 05:53:40 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/Login.php
INFO - 2020-10-08 05:53:40 --> Final output sent to browser
DEBUG - 2020-10-08 05:53:40 --> Total execution time: 0.5134
