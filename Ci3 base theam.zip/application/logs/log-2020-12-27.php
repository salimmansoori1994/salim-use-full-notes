<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-27 17:35:10 --> Config Class Initialized
INFO - 2020-12-27 17:35:10 --> Hooks Class Initialized
DEBUG - 2020-12-27 17:35:10 --> UTF-8 Support Enabled
INFO - 2020-12-27 17:35:10 --> Utf8 Class Initialized
INFO - 2020-12-27 17:35:10 --> URI Class Initialized
INFO - 2020-12-27 17:35:10 --> Router Class Initialized
INFO - 2020-12-27 17:35:10 --> Output Class Initialized
INFO - 2020-12-27 17:35:10 --> Security Class Initialized
DEBUG - 2020-12-27 17:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-27 17:35:10 --> Input Class Initialized
INFO - 2020-12-27 17:35:10 --> Language Class Initialized
INFO - 2020-12-27 17:35:10 --> Language Class Initialized
INFO - 2020-12-27 17:35:10 --> Config Class Initialized
INFO - 2020-12-27 17:35:10 --> Loader Class Initialized
INFO - 2020-12-27 17:35:10 --> Helper loaded: url_helper
INFO - 2020-12-27 17:35:10 --> Helper loaded: file_helper
INFO - 2020-12-27 17:35:10 --> Helper loaded: common_helper
INFO - 2020-12-27 17:35:10 --> Database Driver Class Initialized
INFO - 2020-12-27 17:35:10 --> Email Class Initialized
INFO - 2020-12-27 17:35:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-12-27 17:35:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-12-27 17:35:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-12-27 17:35:10 --> Encryption Class Initialized
INFO - 2020-12-27 17:35:10 --> Model Class Initialized
INFO - 2020-12-27 17:35:10 --> Helper loaded: inflector_helper
INFO - 2020-12-27 17:35:10 --> Model Class Initialized
INFO - 2020-12-27 17:35:10 --> Model Class Initialized
INFO - 2020-12-27 17:35:10 --> Controller Class Initialized
DEBUG - 2020-12-27 17:35:11 --> Admin MX_Controller Initialized
INFO - 2020-12-27 17:35:11 --> Final output sent to browser
DEBUG - 2020-12-27 17:35:11 --> Total execution time: 0.5763
INFO - 2020-12-27 17:35:14 --> Config Class Initialized
INFO - 2020-12-27 17:35:14 --> Hooks Class Initialized
DEBUG - 2020-12-27 17:35:14 --> UTF-8 Support Enabled
INFO - 2020-12-27 17:35:14 --> Utf8 Class Initialized
INFO - 2020-12-27 17:35:14 --> URI Class Initialized
INFO - 2020-12-27 17:35:14 --> Router Class Initialized
INFO - 2020-12-27 17:35:14 --> Output Class Initialized
INFO - 2020-12-27 17:35:14 --> Security Class Initialized
DEBUG - 2020-12-27 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-27 17:35:14 --> Input Class Initialized
INFO - 2020-12-27 17:35:14 --> Language Class Initialized
INFO - 2020-12-27 17:35:14 --> Language Class Initialized
INFO - 2020-12-27 17:35:14 --> Config Class Initialized
INFO - 2020-12-27 17:35:14 --> Loader Class Initialized
INFO - 2020-12-27 17:35:14 --> Helper loaded: url_helper
INFO - 2020-12-27 17:35:14 --> Helper loaded: file_helper
INFO - 2020-12-27 17:35:14 --> Helper loaded: common_helper
INFO - 2020-12-27 17:35:14 --> Database Driver Class Initialized
INFO - 2020-12-27 17:35:14 --> Email Class Initialized
INFO - 2020-12-27 17:35:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-12-27 17:35:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-12-27 17:35:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-12-27 17:35:14 --> Encryption Class Initialized
INFO - 2020-12-27 17:35:14 --> Model Class Initialized
INFO - 2020-12-27 17:35:14 --> Helper loaded: inflector_helper
INFO - 2020-12-27 17:35:14 --> Model Class Initialized
INFO - 2020-12-27 17:35:14 --> Model Class Initialized
INFO - 2020-12-27 17:35:14 --> Controller Class Initialized
DEBUG - 2020-12-27 17:35:14 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2020-12-27 17:35:14 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2020-12-27 17:35:14 --> Final output sent to browser
DEBUG - 2020-12-27 17:35:14 --> Total execution time: 0.6980
