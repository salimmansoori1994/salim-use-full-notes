<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-28 08:36:21 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-28 08:36:21 --> Config Class Initialized
INFO - 2021-01-28 08:36:21 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:21 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:21 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:21 --> Config Class Initialized
INFO - 2021-01-28 08:36:21 --> Hooks Class Initialized
INFO - 2021-01-28 08:36:21 --> URI Class Initialized
DEBUG - 2021-01-28 08:36:21 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:21 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:21 --> URI Class Initialized
INFO - 2021-01-28 08:36:21 --> Router Class Initialized
INFO - 2021-01-28 08:36:21 --> Hooks Class Initialized
INFO - 2021-01-28 08:36:21 --> Output Class Initialized
INFO - 2021-01-28 08:36:21 --> Security Class Initialized
INFO - 2021-01-28 08:36:21 --> Router Class Initialized
DEBUG - 2021-01-28 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:21 --> Input Class Initialized
INFO - 2021-01-28 08:36:21 --> Output Class Initialized
INFO - 2021-01-28 08:36:21 --> Language Class Initialized
ERROR - 2021-01-28 08:36:21 --> 404 Page Not Found: /index
INFO - 2021-01-28 08:36:21 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:21 --> Input Class Initialized
INFO - 2021-01-28 08:36:21 --> Language Class Initialized
ERROR - 2021-01-28 08:36:21 --> 404 Page Not Found: /index
DEBUG - 2021-01-28 08:36:21 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:21 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:21 --> URI Class Initialized
INFO - 2021-01-28 08:36:21 --> Router Class Initialized
INFO - 2021-01-28 08:36:21 --> Output Class Initialized
INFO - 2021-01-28 08:36:21 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:21 --> Input Class Initialized
INFO - 2021-01-28 08:36:21 --> Language Class Initialized
ERROR - 2021-01-28 08:36:21 --> 404 Page Not Found: /index
INFO - 2021-01-28 08:36:30 --> Config Class Initialized
INFO - 2021-01-28 08:36:30 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:30 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:30 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:30 --> URI Class Initialized
INFO - 2021-01-28 08:36:30 --> Router Class Initialized
INFO - 2021-01-28 08:36:30 --> Output Class Initialized
INFO - 2021-01-28 08:36:30 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:31 --> Input Class Initialized
INFO - 2021-01-28 08:36:31 --> Language Class Initialized
INFO - 2021-01-28 08:36:31 --> Language Class Initialized
INFO - 2021-01-28 08:36:31 --> Config Class Initialized
INFO - 2021-01-28 08:36:31 --> Loader Class Initialized
INFO - 2021-01-28 08:36:31 --> Helper loaded: url_helper
INFO - 2021-01-28 08:36:31 --> Helper loaded: file_helper
INFO - 2021-01-28 08:36:31 --> Helper loaded: common_helper
INFO - 2021-01-28 08:36:31 --> Database Driver Class Initialized
INFO - 2021-01-28 08:36:31 --> Email Class Initialized
INFO - 2021-01-28 08:36:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:36:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:36:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:36:31 --> Encryption Class Initialized
INFO - 2021-01-28 08:36:31 --> Model Class Initialized
INFO - 2021-01-28 08:36:31 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:36:31 --> Model Class Initialized
INFO - 2021-01-28 08:36:31 --> Model Class Initialized
INFO - 2021-01-28 08:36:31 --> Controller Class Initialized
DEBUG - 2021-01-28 08:36:31 --> Admin MX_Controller Initialized
INFO - 2021-01-28 08:36:31 --> Final output sent to browser
DEBUG - 2021-01-28 08:36:31 --> Total execution time: 0.4431
INFO - 2021-01-28 08:36:34 --> Config Class Initialized
INFO - 2021-01-28 08:36:34 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:34 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:34 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:34 --> URI Class Initialized
INFO - 2021-01-28 08:36:34 --> Router Class Initialized
INFO - 2021-01-28 08:36:34 --> Output Class Initialized
INFO - 2021-01-28 08:36:34 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:34 --> Input Class Initialized
INFO - 2021-01-28 08:36:34 --> Language Class Initialized
INFO - 2021-01-28 08:36:34 --> Language Class Initialized
INFO - 2021-01-28 08:36:34 --> Config Class Initialized
INFO - 2021-01-28 08:36:34 --> Loader Class Initialized
INFO - 2021-01-28 08:36:34 --> Helper loaded: url_helper
INFO - 2021-01-28 08:36:34 --> Helper loaded: file_helper
INFO - 2021-01-28 08:36:34 --> Helper loaded: common_helper
INFO - 2021-01-28 08:36:34 --> Database Driver Class Initialized
INFO - 2021-01-28 08:36:34 --> Email Class Initialized
INFO - 2021-01-28 08:36:34 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:36:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:36:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:36:34 --> Encryption Class Initialized
INFO - 2021-01-28 08:36:34 --> Model Class Initialized
INFO - 2021-01-28 08:36:34 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:36:34 --> Model Class Initialized
INFO - 2021-01-28 08:36:34 --> Model Class Initialized
INFO - 2021-01-28 08:36:34 --> Controller Class Initialized
DEBUG - 2021-01-28 08:36:34 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-01-28 08:36:34 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:36:34 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-01-28 08:36:35 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-01-28 08:36:35 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-01-28 08:36:35 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-01-28 08:36:35 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:36:35 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-01-28 08:36:35 --> Final output sent to browser
DEBUG - 2021-01-28 08:36:35 --> Total execution time: 0.6195
INFO - 2021-01-28 08:36:35 --> Config Class Initialized
INFO - 2021-01-28 08:36:35 --> Config Class Initialized
INFO - 2021-01-28 08:36:35 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:35 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:35 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:35 --> URI Class Initialized
INFO - 2021-01-28 08:36:35 --> Router Class Initialized
INFO - 2021-01-28 08:36:35 --> Output Class Initialized
INFO - 2021-01-28 08:36:35 --> Security Class Initialized
INFO - 2021-01-28 08:36:35 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:35 --> Input Class Initialized
INFO - 2021-01-28 08:36:35 --> Language Class Initialized
ERROR - 2021-01-28 08:36:35 --> 404 Page Not Found: /index
INFO - 2021-01-28 08:36:35 --> Config Class Initialized
DEBUG - 2021-01-28 08:36:35 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:35 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:35 --> URI Class Initialized
INFO - 2021-01-28 08:36:35 --> Router Class Initialized
INFO - 2021-01-28 08:36:35 --> Output Class Initialized
INFO - 2021-01-28 08:36:35 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:35 --> Input Class Initialized
INFO - 2021-01-28 08:36:35 --> Language Class Initialized
ERROR - 2021-01-28 08:36:35 --> 404 Page Not Found: /index
INFO - 2021-01-28 08:36:35 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:36:35 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:36:35 --> Utf8 Class Initialized
INFO - 2021-01-28 08:36:35 --> URI Class Initialized
INFO - 2021-01-28 08:36:35 --> Router Class Initialized
INFO - 2021-01-28 08:36:35 --> Output Class Initialized
INFO - 2021-01-28 08:36:35 --> Security Class Initialized
DEBUG - 2021-01-28 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:36:35 --> Input Class Initialized
INFO - 2021-01-28 08:36:35 --> Language Class Initialized
ERROR - 2021-01-28 08:36:35 --> 404 Page Not Found: /index
INFO - 2021-01-28 08:38:18 --> Config Class Initialized
INFO - 2021-01-28 08:38:18 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:38:18 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:38:18 --> Utf8 Class Initialized
INFO - 2021-01-28 08:38:18 --> URI Class Initialized
INFO - 2021-01-28 08:38:18 --> Router Class Initialized
INFO - 2021-01-28 08:38:18 --> Output Class Initialized
INFO - 2021-01-28 08:38:18 --> Security Class Initialized
DEBUG - 2021-01-28 08:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:38:18 --> Input Class Initialized
INFO - 2021-01-28 08:38:18 --> Language Class Initialized
INFO - 2021-01-28 08:38:18 --> Language Class Initialized
INFO - 2021-01-28 08:38:18 --> Config Class Initialized
INFO - 2021-01-28 08:38:18 --> Loader Class Initialized
INFO - 2021-01-28 08:38:18 --> Helper loaded: url_helper
INFO - 2021-01-28 08:38:18 --> Helper loaded: file_helper
INFO - 2021-01-28 08:38:19 --> Helper loaded: common_helper
INFO - 2021-01-28 08:38:19 --> Database Driver Class Initialized
INFO - 2021-01-28 08:38:19 --> Email Class Initialized
INFO - 2021-01-28 08:38:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:38:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:38:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:38:19 --> Encryption Class Initialized
INFO - 2021-01-28 08:38:19 --> Model Class Initialized
INFO - 2021-01-28 08:38:19 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:38:19 --> Model Class Initialized
INFO - 2021-01-28 08:38:19 --> Model Class Initialized
INFO - 2021-01-28 08:38:19 --> Controller Class Initialized
DEBUG - 2021-01-28 08:38:19 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:38:19 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-01-28 08:38:19 --> Final output sent to browser
DEBUG - 2021-01-28 08:38:19 --> Total execution time: 0.7220
INFO - 2021-01-28 08:38:24 --> Config Class Initialized
INFO - 2021-01-28 08:38:24 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:38:24 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:38:24 --> Utf8 Class Initialized
INFO - 2021-01-28 08:38:24 --> URI Class Initialized
INFO - 2021-01-28 08:38:24 --> Router Class Initialized
INFO - 2021-01-28 08:38:24 --> Output Class Initialized
INFO - 2021-01-28 08:38:24 --> Security Class Initialized
DEBUG - 2021-01-28 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:38:24 --> Input Class Initialized
INFO - 2021-01-28 08:38:24 --> Language Class Initialized
INFO - 2021-01-28 08:38:24 --> Language Class Initialized
INFO - 2021-01-28 08:38:24 --> Config Class Initialized
INFO - 2021-01-28 08:38:24 --> Loader Class Initialized
INFO - 2021-01-28 08:38:24 --> Helper loaded: url_helper
INFO - 2021-01-28 08:38:24 --> Helper loaded: file_helper
INFO - 2021-01-28 08:38:24 --> Helper loaded: common_helper
INFO - 2021-01-28 08:38:24 --> Database Driver Class Initialized
INFO - 2021-01-28 08:38:24 --> Email Class Initialized
INFO - 2021-01-28 08:38:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:38:24 --> Encryption Class Initialized
INFO - 2021-01-28 08:38:24 --> Model Class Initialized
INFO - 2021-01-28 08:38:24 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:38:24 --> Model Class Initialized
INFO - 2021-01-28 08:38:24 --> Model Class Initialized
INFO - 2021-01-28 08:38:24 --> Controller Class Initialized
DEBUG - 2021-01-28 08:38:24 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:38:24 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-01-28 08:38:24 --> Final output sent to browser
DEBUG - 2021-01-28 08:38:24 --> Total execution time: 0.5692
INFO - 2021-01-28 08:38:29 --> Config Class Initialized
INFO - 2021-01-28 08:38:29 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:38:29 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:38:29 --> Utf8 Class Initialized
INFO - 2021-01-28 08:38:29 --> URI Class Initialized
INFO - 2021-01-28 08:38:30 --> Router Class Initialized
INFO - 2021-01-28 08:38:30 --> Output Class Initialized
INFO - 2021-01-28 08:38:30 --> Security Class Initialized
DEBUG - 2021-01-28 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:38:30 --> Input Class Initialized
INFO - 2021-01-28 08:38:30 --> Language Class Initialized
INFO - 2021-01-28 08:38:30 --> Language Class Initialized
INFO - 2021-01-28 08:38:30 --> Config Class Initialized
INFO - 2021-01-28 08:38:30 --> Loader Class Initialized
INFO - 2021-01-28 08:38:30 --> Helper loaded: url_helper
INFO - 2021-01-28 08:38:30 --> Helper loaded: file_helper
INFO - 2021-01-28 08:38:30 --> Helper loaded: common_helper
INFO - 2021-01-28 08:38:30 --> Database Driver Class Initialized
INFO - 2021-01-28 08:38:30 --> Email Class Initialized
INFO - 2021-01-28 08:38:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:38:30 --> Encryption Class Initialized
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Controller Class Initialized
DEBUG - 2021-01-28 08:38:30 --> Admin_dashboard MX_Controller Initialized
INFO - 2021-01-28 08:38:30 --> Config Class Initialized
INFO - 2021-01-28 08:38:30 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:38:30 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:38:30 --> Utf8 Class Initialized
INFO - 2021-01-28 08:38:30 --> URI Class Initialized
DEBUG - 2021-01-28 08:38:30 --> No URI present. Default controller set.
INFO - 2021-01-28 08:38:30 --> Router Class Initialized
INFO - 2021-01-28 08:38:30 --> Output Class Initialized
INFO - 2021-01-28 08:38:30 --> Security Class Initialized
DEBUG - 2021-01-28 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:38:30 --> Input Class Initialized
INFO - 2021-01-28 08:38:30 --> Language Class Initialized
INFO - 2021-01-28 08:38:30 --> Language Class Initialized
INFO - 2021-01-28 08:38:30 --> Config Class Initialized
INFO - 2021-01-28 08:38:30 --> Loader Class Initialized
INFO - 2021-01-28 08:38:30 --> Helper loaded: url_helper
INFO - 2021-01-28 08:38:30 --> Helper loaded: file_helper
INFO - 2021-01-28 08:38:30 --> Helper loaded: common_helper
INFO - 2021-01-28 08:38:30 --> Database Driver Class Initialized
INFO - 2021-01-28 08:38:30 --> Email Class Initialized
INFO - 2021-01-28 08:38:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:38:30 --> Encryption Class Initialized
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Model Class Initialized
INFO - 2021-01-28 08:38:30 --> Controller Class Initialized
DEBUG - 2021-01-28 08:38:30 --> Admin MX_Controller Initialized
DEBUG - 2021-01-28 08:38:31 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:38:31 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:38:31 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-01-28 08:38:31 --> Final output sent to browser
DEBUG - 2021-01-28 08:38:31 --> Total execution time: 0.5485
INFO - 2021-01-28 08:39:03 --> Config Class Initialized
INFO - 2021-01-28 08:39:03 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:39:03 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:39:03 --> Utf8 Class Initialized
INFO - 2021-01-28 08:39:03 --> URI Class Initialized
INFO - 2021-01-28 08:39:03 --> Router Class Initialized
INFO - 2021-01-28 08:39:03 --> Output Class Initialized
INFO - 2021-01-28 08:39:03 --> Security Class Initialized
DEBUG - 2021-01-28 08:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:39:03 --> Input Class Initialized
INFO - 2021-01-28 08:39:03 --> Language Class Initialized
INFO - 2021-01-28 08:39:03 --> Language Class Initialized
INFO - 2021-01-28 08:39:03 --> Config Class Initialized
INFO - 2021-01-28 08:39:03 --> Loader Class Initialized
INFO - 2021-01-28 08:39:03 --> Helper loaded: url_helper
INFO - 2021-01-28 08:39:03 --> Helper loaded: file_helper
INFO - 2021-01-28 08:39:03 --> Helper loaded: common_helper
INFO - 2021-01-28 08:39:03 --> Database Driver Class Initialized
INFO - 2021-01-28 08:39:03 --> Email Class Initialized
INFO - 2021-01-28 08:39:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:39:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:39:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:39:03 --> Encryption Class Initialized
INFO - 2021-01-28 08:39:03 --> Model Class Initialized
INFO - 2021-01-28 08:39:03 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:39:03 --> Model Class Initialized
INFO - 2021-01-28 08:39:03 --> Model Class Initialized
INFO - 2021-01-28 08:39:03 --> Controller Class Initialized
DEBUG - 2021-01-28 08:39:03 --> Admin MX_Controller Initialized
INFO - 2021-01-28 08:39:03 --> Final output sent to browser
DEBUG - 2021-01-28 08:39:03 --> Total execution time: 0.6161
INFO - 2021-01-28 08:39:08 --> Config Class Initialized
INFO - 2021-01-28 08:39:08 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:39:08 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:39:08 --> Utf8 Class Initialized
INFO - 2021-01-28 08:39:08 --> URI Class Initialized
INFO - 2021-01-28 08:39:08 --> Router Class Initialized
INFO - 2021-01-28 08:39:08 --> Output Class Initialized
INFO - 2021-01-28 08:39:08 --> Security Class Initialized
DEBUG - 2021-01-28 08:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:39:08 --> Input Class Initialized
INFO - 2021-01-28 08:39:08 --> Language Class Initialized
INFO - 2021-01-28 08:39:08 --> Language Class Initialized
INFO - 2021-01-28 08:39:08 --> Config Class Initialized
INFO - 2021-01-28 08:39:08 --> Loader Class Initialized
INFO - 2021-01-28 08:39:08 --> Helper loaded: url_helper
INFO - 2021-01-28 08:39:08 --> Helper loaded: file_helper
INFO - 2021-01-28 08:39:08 --> Helper loaded: common_helper
INFO - 2021-01-28 08:39:08 --> Database Driver Class Initialized
INFO - 2021-01-28 08:39:08 --> Email Class Initialized
INFO - 2021-01-28 08:39:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:39:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:39:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:39:08 --> Encryption Class Initialized
INFO - 2021-01-28 08:39:08 --> Model Class Initialized
INFO - 2021-01-28 08:39:08 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:39:08 --> Model Class Initialized
INFO - 2021-01-28 08:39:08 --> Model Class Initialized
INFO - 2021-01-28 08:39:08 --> Controller Class Initialized
DEBUG - 2021-01-28 08:39:08 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_head_bar.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_side_bar.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/comman_footer_text.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:39:08 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/view_template.php
INFO - 2021-01-28 08:39:08 --> Final output sent to browser
DEBUG - 2021-01-28 08:39:08 --> Total execution time: 0.6381
INFO - 2021-01-28 08:40:35 --> Config Class Initialized
INFO - 2021-01-28 08:40:35 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:40:35 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:40:35 --> Utf8 Class Initialized
INFO - 2021-01-28 08:40:35 --> URI Class Initialized
INFO - 2021-01-28 08:40:35 --> Router Class Initialized
INFO - 2021-01-28 08:40:35 --> Output Class Initialized
INFO - 2021-01-28 08:40:35 --> Security Class Initialized
DEBUG - 2021-01-28 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:40:36 --> Input Class Initialized
INFO - 2021-01-28 08:40:36 --> Language Class Initialized
INFO - 2021-01-28 08:40:36 --> Language Class Initialized
INFO - 2021-01-28 08:40:36 --> Config Class Initialized
INFO - 2021-01-28 08:40:36 --> Loader Class Initialized
INFO - 2021-01-28 08:40:36 --> Helper loaded: url_helper
INFO - 2021-01-28 08:40:36 --> Helper loaded: file_helper
INFO - 2021-01-28 08:40:36 --> Helper loaded: common_helper
INFO - 2021-01-28 08:40:36 --> Database Driver Class Initialized
INFO - 2021-01-28 08:40:36 --> Email Class Initialized
INFO - 2021-01-28 08:40:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:40:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:40:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:40:36 --> Encryption Class Initialized
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Controller Class Initialized
DEBUG - 2021-01-28 08:40:36 --> Admin_dashboard MX_Controller Initialized
INFO - 2021-01-28 08:40:36 --> Config Class Initialized
INFO - 2021-01-28 08:40:36 --> Hooks Class Initialized
DEBUG - 2021-01-28 08:40:36 --> UTF-8 Support Enabled
INFO - 2021-01-28 08:40:36 --> Utf8 Class Initialized
INFO - 2021-01-28 08:40:36 --> URI Class Initialized
DEBUG - 2021-01-28 08:40:36 --> No URI present. Default controller set.
INFO - 2021-01-28 08:40:36 --> Router Class Initialized
INFO - 2021-01-28 08:40:36 --> Output Class Initialized
INFO - 2021-01-28 08:40:36 --> Security Class Initialized
DEBUG - 2021-01-28 08:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-28 08:40:36 --> Input Class Initialized
INFO - 2021-01-28 08:40:36 --> Language Class Initialized
INFO - 2021-01-28 08:40:36 --> Language Class Initialized
INFO - 2021-01-28 08:40:36 --> Config Class Initialized
INFO - 2021-01-28 08:40:36 --> Loader Class Initialized
INFO - 2021-01-28 08:40:36 --> Helper loaded: url_helper
INFO - 2021-01-28 08:40:36 --> Helper loaded: file_helper
INFO - 2021-01-28 08:40:36 --> Helper loaded: common_helper
INFO - 2021-01-28 08:40:36 --> Database Driver Class Initialized
INFO - 2021-01-28 08:40:36 --> Email Class Initialized
INFO - 2021-01-28 08:40:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-01-28 08:40:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-01-28 08:40:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-01-28 08:40:36 --> Encryption Class Initialized
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Helper loaded: inflector_helper
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Model Class Initialized
INFO - 2021-01-28 08:40:36 --> Controller Class Initialized
DEBUG - 2021-01-28 08:40:36 --> Admin MX_Controller Initialized
DEBUG - 2021-01-28 08:40:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-01-28 08:40:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-01-28 08:40:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-01-28 08:40:36 --> Final output sent to browser
DEBUG - 2021-01-28 08:40:37 --> Total execution time: 0.5554
