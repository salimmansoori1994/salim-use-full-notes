<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-28 13:49:22 --> Config Class Initialized
INFO - 2020-08-28 13:49:22 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:49:22 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:49:22 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:22 --> URI Class Initialized
DEBUG - 2020-08-28 13:49:22 --> No URI present. Default controller set.
INFO - 2020-08-28 13:49:22 --> Router Class Initialized
INFO - 2020-08-28 13:49:22 --> Output Class Initialized
INFO - 2020-08-28 13:49:22 --> Security Class Initialized
DEBUG - 2020-08-28 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:22 --> Input Class Initialized
INFO - 2020-08-28 13:49:22 --> Language Class Initialized
INFO - 2020-08-28 13:49:22 --> Language Class Initialized
INFO - 2020-08-28 13:49:22 --> Config Class Initialized
INFO - 2020-08-28 13:49:22 --> Loader Class Initialized
INFO - 2020-08-28 13:49:22 --> Helper loaded: url_helper
INFO - 2020-08-28 13:49:22 --> Helper loaded: file_helper
INFO - 2020-08-28 13:49:22 --> Database Driver Class Initialized
INFO - 2020-08-28 13:49:22 --> Email Class Initialized
INFO - 2020-08-28 13:49:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:49:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:49:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:49:23 --> Encryption Class Initialized
INFO - 2020-08-28 13:49:23 --> Model Class Initialized
INFO - 2020-08-28 13:49:23 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:49:23 --> Model Class Initialized
INFO - 2020-08-28 13:49:23 --> Model Class Initialized
INFO - 2020-08-28 13:49:23 --> Controller Class Initialized
DEBUG - 2020-08-28 13:49:23 --> Admin MX_Controller Initialized
DEBUG - 2020-08-28 13:49:23 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:49:23 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:49:23 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/Login.php
INFO - 2020-08-28 13:49:23 --> Final output sent to browser
DEBUG - 2020-08-28 13:49:23 --> Total execution time: 1.2760
INFO - 2020-08-28 13:49:30 --> Config Class Initialized
INFO - 2020-08-28 13:49:30 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:49:30 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:49:30 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:30 --> URI Class Initialized
INFO - 2020-08-28 13:49:30 --> Router Class Initialized
INFO - 2020-08-28 13:49:30 --> Output Class Initialized
INFO - 2020-08-28 13:49:30 --> Security Class Initialized
DEBUG - 2020-08-28 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:30 --> Input Class Initialized
INFO - 2020-08-28 13:49:30 --> Language Class Initialized
INFO - 2020-08-28 13:49:30 --> Language Class Initialized
INFO - 2020-08-28 13:49:30 --> Config Class Initialized
INFO - 2020-08-28 13:49:30 --> Loader Class Initialized
INFO - 2020-08-28 13:49:30 --> Helper loaded: url_helper
INFO - 2020-08-28 13:49:30 --> Helper loaded: file_helper
INFO - 2020-08-28 13:49:30 --> Database Driver Class Initialized
INFO - 2020-08-28 13:49:30 --> Email Class Initialized
INFO - 2020-08-28 13:49:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:49:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:49:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:49:31 --> Encryption Class Initialized
INFO - 2020-08-28 13:49:31 --> Model Class Initialized
INFO - 2020-08-28 13:49:31 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:49:31 --> Model Class Initialized
INFO - 2020-08-28 13:49:31 --> Model Class Initialized
INFO - 2020-08-28 13:49:31 --> Controller Class Initialized
DEBUG - 2020-08-28 13:49:31 --> Admin MX_Controller Initialized
INFO - 2020-08-28 13:49:31 --> Final output sent to browser
DEBUG - 2020-08-28 13:49:31 --> Total execution time: 0.3211
INFO - 2020-08-28 13:49:34 --> Config Class Initialized
INFO - 2020-08-28 13:49:34 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:49:34 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:49:34 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:34 --> URI Class Initialized
INFO - 2020-08-28 13:49:34 --> Router Class Initialized
INFO - 2020-08-28 13:49:34 --> Output Class Initialized
INFO - 2020-08-28 13:49:34 --> Security Class Initialized
DEBUG - 2020-08-28 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:34 --> Input Class Initialized
INFO - 2020-08-28 13:49:34 --> Language Class Initialized
INFO - 2020-08-28 13:49:34 --> Language Class Initialized
INFO - 2020-08-28 13:49:34 --> Config Class Initialized
INFO - 2020-08-28 13:49:34 --> Loader Class Initialized
INFO - 2020-08-28 13:49:34 --> Helper loaded: url_helper
INFO - 2020-08-28 13:49:34 --> Helper loaded: file_helper
INFO - 2020-08-28 13:49:34 --> Database Driver Class Initialized
INFO - 2020-08-28 13:49:34 --> Email Class Initialized
INFO - 2020-08-28 13:49:34 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:49:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:49:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:49:34 --> Encryption Class Initialized
INFO - 2020-08-28 13:49:34 --> Model Class Initialized
INFO - 2020-08-28 13:49:34 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:49:34 --> Model Class Initialized
INFO - 2020-08-28 13:49:34 --> Model Class Initialized
INFO - 2020-08-28 13:49:34 --> Controller Class Initialized
DEBUG - 2020-08-28 13:49:34 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:49:34 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:49:34 --> Final output sent to browser
DEBUG - 2020-08-28 13:49:34 --> Total execution time: 0.5982
INFO - 2020-08-28 13:49:37 --> Config Class Initialized
INFO - 2020-08-28 13:49:37 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:49:37 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:49:37 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:37 --> URI Class Initialized
INFO - 2020-08-28 13:49:37 --> Router Class Initialized
INFO - 2020-08-28 13:49:37 --> Output Class Initialized
INFO - 2020-08-28 13:49:37 --> Security Class Initialized
DEBUG - 2020-08-28 13:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:37 --> Input Class Initialized
INFO - 2020-08-28 13:49:37 --> Language Class Initialized
INFO - 2020-08-28 13:49:37 --> Language Class Initialized
INFO - 2020-08-28 13:49:37 --> Config Class Initialized
INFO - 2020-08-28 13:49:37 --> Loader Class Initialized
INFO - 2020-08-28 13:49:37 --> Helper loaded: url_helper
INFO - 2020-08-28 13:49:37 --> Helper loaded: file_helper
INFO - 2020-08-28 13:49:37 --> Database Driver Class Initialized
INFO - 2020-08-28 13:49:37 --> Email Class Initialized
INFO - 2020-08-28 13:49:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:49:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:49:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:49:37 --> Encryption Class Initialized
INFO - 2020-08-28 13:49:37 --> Model Class Initialized
INFO - 2020-08-28 13:49:37 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:49:37 --> Model Class Initialized
INFO - 2020-08-28 13:49:37 --> Model Class Initialized
INFO - 2020-08-28 13:49:37 --> Controller Class Initialized
DEBUG - 2020-08-28 13:49:37 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:49:37 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:49:37 --> Final output sent to browser
DEBUG - 2020-08-28 13:49:37 --> Total execution time: 0.4696
INFO - 2020-08-28 13:49:47 --> Config Class Initialized
INFO - 2020-08-28 13:49:47 --> Config Class Initialized
INFO - 2020-08-28 13:49:47 --> Config Class Initialized
INFO - 2020-08-28 13:49:47 --> Hooks Class Initialized
INFO - 2020-08-28 13:49:47 --> Hooks Class Initialized
INFO - 2020-08-28 13:49:47 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:49:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:49:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:49:47 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:49:47 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:47 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:47 --> Utf8 Class Initialized
INFO - 2020-08-28 13:49:47 --> URI Class Initialized
INFO - 2020-08-28 13:49:47 --> URI Class Initialized
INFO - 2020-08-28 13:49:47 --> URI Class Initialized
INFO - 2020-08-28 13:49:47 --> Router Class Initialized
INFO - 2020-08-28 13:49:47 --> Router Class Initialized
INFO - 2020-08-28 13:49:47 --> Router Class Initialized
INFO - 2020-08-28 13:49:47 --> Output Class Initialized
INFO - 2020-08-28 13:49:47 --> Output Class Initialized
INFO - 2020-08-28 13:49:47 --> Output Class Initialized
INFO - 2020-08-28 13:49:48 --> Security Class Initialized
INFO - 2020-08-28 13:49:48 --> Security Class Initialized
INFO - 2020-08-28 13:49:48 --> Security Class Initialized
DEBUG - 2020-08-28 13:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:48 --> Input Class Initialized
DEBUG - 2020-08-28 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:49:48 --> Input Class Initialized
INFO - 2020-08-28 13:49:48 --> Language Class Initialized
INFO - 2020-08-28 13:49:48 --> Language Class Initialized
INFO - 2020-08-28 13:49:48 --> Input Class Initialized
INFO - 2020-08-28 13:49:48 --> Language Class Initialized
ERROR - 2020-08-28 13:49:48 --> 404 Page Not Found: /index
ERROR - 2020-08-28 13:49:48 --> 404 Page Not Found: /index
ERROR - 2020-08-28 13:49:48 --> 404 Page Not Found: /index
INFO - 2020-08-28 13:51:29 --> Config Class Initialized
INFO - 2020-08-28 13:51:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:51:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:51:29 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:29 --> URI Class Initialized
INFO - 2020-08-28 13:51:29 --> Router Class Initialized
INFO - 2020-08-28 13:51:29 --> Output Class Initialized
INFO - 2020-08-28 13:51:29 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:30 --> Input Class Initialized
INFO - 2020-08-28 13:51:30 --> Language Class Initialized
INFO - 2020-08-28 13:51:30 --> Language Class Initialized
INFO - 2020-08-28 13:51:30 --> Config Class Initialized
INFO - 2020-08-28 13:51:30 --> Loader Class Initialized
INFO - 2020-08-28 13:51:30 --> Helper loaded: url_helper
INFO - 2020-08-28 13:51:30 --> Helper loaded: file_helper
INFO - 2020-08-28 13:51:30 --> Database Driver Class Initialized
INFO - 2020-08-28 13:51:30 --> Email Class Initialized
INFO - 2020-08-28 13:51:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:51:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:51:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:51:30 --> Encryption Class Initialized
INFO - 2020-08-28 13:51:30 --> Model Class Initialized
INFO - 2020-08-28 13:51:30 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:51:30 --> Model Class Initialized
INFO - 2020-08-28 13:51:30 --> Model Class Initialized
INFO - 2020-08-28 13:51:30 --> Controller Class Initialized
DEBUG - 2020-08-28 13:51:30 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:51:30 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:51:30 --> Final output sent to browser
DEBUG - 2020-08-28 13:51:30 --> Total execution time: 1.2509
INFO - 2020-08-28 13:51:41 --> Config Class Initialized
INFO - 2020-08-28 13:51:41 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:51:41 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:51:41 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:41 --> URI Class Initialized
INFO - 2020-08-28 13:51:42 --> Router Class Initialized
INFO - 2020-08-28 13:51:42 --> Output Class Initialized
INFO - 2020-08-28 13:51:42 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:42 --> Input Class Initialized
INFO - 2020-08-28 13:51:42 --> Language Class Initialized
INFO - 2020-08-28 13:51:42 --> Language Class Initialized
INFO - 2020-08-28 13:51:42 --> Config Class Initialized
INFO - 2020-08-28 13:51:42 --> Loader Class Initialized
INFO - 2020-08-28 13:51:42 --> Helper loaded: url_helper
INFO - 2020-08-28 13:51:42 --> Helper loaded: file_helper
INFO - 2020-08-28 13:51:42 --> Database Driver Class Initialized
INFO - 2020-08-28 13:51:42 --> Email Class Initialized
INFO - 2020-08-28 13:51:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:51:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:51:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:51:42 --> Encryption Class Initialized
INFO - 2020-08-28 13:51:42 --> Model Class Initialized
INFO - 2020-08-28 13:51:42 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:51:42 --> Model Class Initialized
INFO - 2020-08-28 13:51:42 --> Model Class Initialized
INFO - 2020-08-28 13:51:42 --> Controller Class Initialized
DEBUG - 2020-08-28 13:51:42 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:51:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:51:42 --> Final output sent to browser
DEBUG - 2020-08-28 13:51:42 --> Total execution time: 0.7298
INFO - 2020-08-28 13:51:46 --> Config Class Initialized
INFO - 2020-08-28 13:51:46 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:51:46 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:51:46 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:46 --> URI Class Initialized
INFO - 2020-08-28 13:51:46 --> Router Class Initialized
INFO - 2020-08-28 13:51:46 --> Output Class Initialized
INFO - 2020-08-28 13:51:46 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:46 --> Input Class Initialized
INFO - 2020-08-28 13:51:46 --> Language Class Initialized
INFO - 2020-08-28 13:51:46 --> Language Class Initialized
INFO - 2020-08-28 13:51:46 --> Config Class Initialized
INFO - 2020-08-28 13:51:46 --> Loader Class Initialized
INFO - 2020-08-28 13:51:46 --> Helper loaded: url_helper
INFO - 2020-08-28 13:51:46 --> Helper loaded: file_helper
INFO - 2020-08-28 13:51:46 --> Database Driver Class Initialized
INFO - 2020-08-28 13:51:46 --> Email Class Initialized
INFO - 2020-08-28 13:51:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:51:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:51:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:51:46 --> Encryption Class Initialized
INFO - 2020-08-28 13:51:46 --> Model Class Initialized
INFO - 2020-08-28 13:51:46 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:51:46 --> Model Class Initialized
INFO - 2020-08-28 13:51:46 --> Model Class Initialized
INFO - 2020-08-28 13:51:46 --> Controller Class Initialized
DEBUG - 2020-08-28 13:51:46 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:51:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:51:46 --> Final output sent to browser
DEBUG - 2020-08-28 13:51:46 --> Total execution time: 0.5786
INFO - 2020-08-28 13:51:53 --> Config Class Initialized
INFO - 2020-08-28 13:51:53 --> Config Class Initialized
INFO - 2020-08-28 13:51:53 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:51:53 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:51:53 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:53 --> URI Class Initialized
INFO - 2020-08-28 13:51:53 --> Router Class Initialized
INFO - 2020-08-28 13:51:53 --> Config Class Initialized
INFO - 2020-08-28 13:51:53 --> Hooks Class Initialized
INFO - 2020-08-28 13:51:53 --> Output Class Initialized
INFO - 2020-08-28 13:51:53 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:53 --> Input Class Initialized
INFO - 2020-08-28 13:51:53 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:53 --> Language Class Initialized
INFO - 2020-08-28 13:51:53 --> URI Class Initialized
INFO - 2020-08-28 13:51:53 --> Router Class Initialized
INFO - 2020-08-28 13:51:53 --> Output Class Initialized
INFO - 2020-08-28 13:51:53 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:53 --> Input Class Initialized
INFO - 2020-08-28 13:51:53 --> Language Class Initialized
INFO - 2020-08-28 13:51:53 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:51:53 --> UTF-8 Support Enabled
ERROR - 2020-08-28 13:51:53 --> 404 Page Not Found: /index
ERROR - 2020-08-28 13:51:53 --> 404 Page Not Found: /index
INFO - 2020-08-28 13:51:53 --> Utf8 Class Initialized
INFO - 2020-08-28 13:51:53 --> URI Class Initialized
INFO - 2020-08-28 13:51:53 --> Router Class Initialized
INFO - 2020-08-28 13:51:53 --> Output Class Initialized
INFO - 2020-08-28 13:51:53 --> Security Class Initialized
DEBUG - 2020-08-28 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:51:53 --> Input Class Initialized
INFO - 2020-08-28 13:51:53 --> Language Class Initialized
ERROR - 2020-08-28 13:51:53 --> 404 Page Not Found: /index
INFO - 2020-08-28 13:54:12 --> Config Class Initialized
INFO - 2020-08-28 13:54:12 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:12 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:12 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:12 --> URI Class Initialized
INFO - 2020-08-28 13:54:12 --> Router Class Initialized
INFO - 2020-08-28 13:54:12 --> Output Class Initialized
INFO - 2020-08-28 13:54:12 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:12 --> Input Class Initialized
INFO - 2020-08-28 13:54:12 --> Language Class Initialized
INFO - 2020-08-28 13:54:12 --> Language Class Initialized
INFO - 2020-08-28 13:54:12 --> Config Class Initialized
INFO - 2020-08-28 13:54:12 --> Loader Class Initialized
INFO - 2020-08-28 13:54:12 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:12 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:12 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:12 --> Email Class Initialized
INFO - 2020-08-28 13:54:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:12 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:12 --> Model Class Initialized
INFO - 2020-08-28 13:54:13 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:13 --> Model Class Initialized
INFO - 2020-08-28 13:54:13 --> Model Class Initialized
INFO - 2020-08-28 13:54:13 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:13 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:13 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:13 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:13 --> Total execution time: 0.5067
INFO - 2020-08-28 13:54:16 --> Config Class Initialized
INFO - 2020-08-28 13:54:16 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:16 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:16 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:16 --> URI Class Initialized
INFO - 2020-08-28 13:54:16 --> Router Class Initialized
INFO - 2020-08-28 13:54:16 --> Output Class Initialized
INFO - 2020-08-28 13:54:16 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:16 --> Input Class Initialized
INFO - 2020-08-28 13:54:16 --> Language Class Initialized
INFO - 2020-08-28 13:54:16 --> Language Class Initialized
INFO - 2020-08-28 13:54:16 --> Config Class Initialized
INFO - 2020-08-28 13:54:16 --> Loader Class Initialized
INFO - 2020-08-28 13:54:16 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:16 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:16 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:16 --> Email Class Initialized
INFO - 2020-08-28 13:54:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:16 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:16 --> Model Class Initialized
INFO - 2020-08-28 13:54:16 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:16 --> Model Class Initialized
INFO - 2020-08-28 13:54:16 --> Model Class Initialized
INFO - 2020-08-28 13:54:16 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:16 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:16 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:16 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:16 --> Total execution time: 0.5001
INFO - 2020-08-28 13:54:19 --> Config Class Initialized
INFO - 2020-08-28 13:54:19 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:19 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:19 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:19 --> URI Class Initialized
INFO - 2020-08-28 13:54:19 --> Router Class Initialized
INFO - 2020-08-28 13:54:19 --> Output Class Initialized
INFO - 2020-08-28 13:54:19 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:19 --> Input Class Initialized
INFO - 2020-08-28 13:54:19 --> Language Class Initialized
INFO - 2020-08-28 13:54:19 --> Language Class Initialized
INFO - 2020-08-28 13:54:19 --> Config Class Initialized
INFO - 2020-08-28 13:54:19 --> Loader Class Initialized
INFO - 2020-08-28 13:54:19 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:19 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:19 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:19 --> Email Class Initialized
INFO - 2020-08-28 13:54:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:19 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:19 --> Model Class Initialized
INFO - 2020-08-28 13:54:19 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:19 --> Model Class Initialized
INFO - 2020-08-28 13:54:19 --> Model Class Initialized
INFO - 2020-08-28 13:54:19 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:19 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:19 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:19 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:19 --> Total execution time: 0.6879
INFO - 2020-08-28 13:54:41 --> Config Class Initialized
INFO - 2020-08-28 13:54:41 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:41 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:41 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:41 --> URI Class Initialized
INFO - 2020-08-28 13:54:41 --> Router Class Initialized
INFO - 2020-08-28 13:54:41 --> Output Class Initialized
INFO - 2020-08-28 13:54:41 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:41 --> Input Class Initialized
INFO - 2020-08-28 13:54:41 --> Language Class Initialized
INFO - 2020-08-28 13:54:41 --> Language Class Initialized
INFO - 2020-08-28 13:54:41 --> Config Class Initialized
INFO - 2020-08-28 13:54:41 --> Loader Class Initialized
INFO - 2020-08-28 13:54:41 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:41 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:41 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:41 --> Email Class Initialized
INFO - 2020-08-28 13:54:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:41 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:41 --> Model Class Initialized
INFO - 2020-08-28 13:54:41 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:41 --> Model Class Initialized
INFO - 2020-08-28 13:54:41 --> Model Class Initialized
INFO - 2020-08-28 13:54:41 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:41 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:41 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:41 --> Total execution time: 0.4580
INFO - 2020-08-28 13:54:47 --> Config Class Initialized
INFO - 2020-08-28 13:54:47 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:47 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:47 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:47 --> URI Class Initialized
INFO - 2020-08-28 13:54:47 --> Router Class Initialized
INFO - 2020-08-28 13:54:47 --> Output Class Initialized
INFO - 2020-08-28 13:54:47 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:47 --> Input Class Initialized
INFO - 2020-08-28 13:54:47 --> Language Class Initialized
INFO - 2020-08-28 13:54:47 --> Language Class Initialized
INFO - 2020-08-28 13:54:47 --> Config Class Initialized
INFO - 2020-08-28 13:54:47 --> Loader Class Initialized
INFO - 2020-08-28 13:54:47 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:47 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:47 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:47 --> Email Class Initialized
INFO - 2020-08-28 13:54:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:47 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:47 --> Model Class Initialized
INFO - 2020-08-28 13:54:47 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:47 --> Model Class Initialized
INFO - 2020-08-28 13:54:47 --> Model Class Initialized
INFO - 2020-08-28 13:54:47 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:47 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:47 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:47 --> Total execution time: 0.5666
INFO - 2020-08-28 13:54:49 --> Config Class Initialized
INFO - 2020-08-28 13:54:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:54:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:54:49 --> Utf8 Class Initialized
INFO - 2020-08-28 13:54:49 --> URI Class Initialized
INFO - 2020-08-28 13:54:49 --> Router Class Initialized
INFO - 2020-08-28 13:54:49 --> Output Class Initialized
INFO - 2020-08-28 13:54:49 --> Security Class Initialized
DEBUG - 2020-08-28 13:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:54:49 --> Input Class Initialized
INFO - 2020-08-28 13:54:49 --> Language Class Initialized
INFO - 2020-08-28 13:54:49 --> Language Class Initialized
INFO - 2020-08-28 13:54:49 --> Config Class Initialized
INFO - 2020-08-28 13:54:49 --> Loader Class Initialized
INFO - 2020-08-28 13:54:49 --> Helper loaded: url_helper
INFO - 2020-08-28 13:54:49 --> Helper loaded: file_helper
INFO - 2020-08-28 13:54:49 --> Database Driver Class Initialized
INFO - 2020-08-28 13:54:49 --> Email Class Initialized
INFO - 2020-08-28 13:54:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:54:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:54:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:54:49 --> Encryption Class Initialized
INFO - 2020-08-28 13:54:49 --> Model Class Initialized
INFO - 2020-08-28 13:54:49 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:54:49 --> Model Class Initialized
INFO - 2020-08-28 13:54:50 --> Model Class Initialized
INFO - 2020-08-28 13:54:50 --> Controller Class Initialized
DEBUG - 2020-08-28 13:54:50 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:54:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:54:50 --> Final output sent to browser
DEBUG - 2020-08-28 13:54:50 --> Total execution time: 0.5024
INFO - 2020-08-28 13:56:05 --> Config Class Initialized
INFO - 2020-08-28 13:56:05 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:56:05 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:56:05 --> Utf8 Class Initialized
INFO - 2020-08-28 13:56:05 --> URI Class Initialized
INFO - 2020-08-28 13:56:05 --> Router Class Initialized
INFO - 2020-08-28 13:56:05 --> Output Class Initialized
INFO - 2020-08-28 13:56:05 --> Security Class Initialized
DEBUG - 2020-08-28 13:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:56:05 --> Input Class Initialized
INFO - 2020-08-28 13:56:05 --> Language Class Initialized
INFO - 2020-08-28 13:56:05 --> Language Class Initialized
INFO - 2020-08-28 13:56:05 --> Config Class Initialized
INFO - 2020-08-28 13:56:05 --> Loader Class Initialized
INFO - 2020-08-28 13:56:05 --> Helper loaded: url_helper
INFO - 2020-08-28 13:56:05 --> Helper loaded: file_helper
INFO - 2020-08-28 13:56:05 --> Database Driver Class Initialized
INFO - 2020-08-28 13:56:05 --> Email Class Initialized
INFO - 2020-08-28 13:56:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:56:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:56:05 --> Encryption Class Initialized
INFO - 2020-08-28 13:56:06 --> Model Class Initialized
INFO - 2020-08-28 13:56:06 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:56:06 --> Model Class Initialized
INFO - 2020-08-28 13:56:06 --> Model Class Initialized
INFO - 2020-08-28 13:56:06 --> Controller Class Initialized
DEBUG - 2020-08-28 13:56:06 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:56:06 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:56:06 --> Final output sent to browser
DEBUG - 2020-08-28 13:56:06 --> Total execution time: 0.4476
INFO - 2020-08-28 13:58:40 --> Config Class Initialized
INFO - 2020-08-28 13:58:40 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:58:40 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:58:40 --> Utf8 Class Initialized
INFO - 2020-08-28 13:58:40 --> URI Class Initialized
INFO - 2020-08-28 13:58:40 --> Router Class Initialized
INFO - 2020-08-28 13:58:40 --> Output Class Initialized
INFO - 2020-08-28 13:58:40 --> Security Class Initialized
DEBUG - 2020-08-28 13:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:58:40 --> Input Class Initialized
INFO - 2020-08-28 13:58:40 --> Language Class Initialized
INFO - 2020-08-28 13:58:40 --> Language Class Initialized
INFO - 2020-08-28 13:58:40 --> Config Class Initialized
INFO - 2020-08-28 13:58:40 --> Loader Class Initialized
INFO - 2020-08-28 13:58:40 --> Helper loaded: url_helper
INFO - 2020-08-28 13:58:40 --> Helper loaded: file_helper
INFO - 2020-08-28 13:58:40 --> Database Driver Class Initialized
INFO - 2020-08-28 13:58:40 --> Email Class Initialized
INFO - 2020-08-28 13:58:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:58:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:58:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:58:40 --> Encryption Class Initialized
INFO - 2020-08-28 13:58:40 --> Model Class Initialized
INFO - 2020-08-28 13:58:40 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:58:40 --> Model Class Initialized
INFO - 2020-08-28 13:58:40 --> Model Class Initialized
INFO - 2020-08-28 13:58:40 --> Controller Class Initialized
DEBUG - 2020-08-28 13:58:40 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:58:40 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:58:41 --> Final output sent to browser
DEBUG - 2020-08-28 13:58:41 --> Total execution time: 0.5006
INFO - 2020-08-28 13:58:42 --> Config Class Initialized
INFO - 2020-08-28 13:58:42 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:58:42 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:58:42 --> Utf8 Class Initialized
INFO - 2020-08-28 13:58:43 --> URI Class Initialized
INFO - 2020-08-28 13:58:43 --> Router Class Initialized
INFO - 2020-08-28 13:58:43 --> Output Class Initialized
INFO - 2020-08-28 13:58:43 --> Security Class Initialized
DEBUG - 2020-08-28 13:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:58:43 --> Input Class Initialized
INFO - 2020-08-28 13:58:43 --> Language Class Initialized
INFO - 2020-08-28 13:58:43 --> Language Class Initialized
INFO - 2020-08-28 13:58:43 --> Config Class Initialized
INFO - 2020-08-28 13:58:43 --> Loader Class Initialized
INFO - 2020-08-28 13:58:43 --> Helper loaded: url_helper
INFO - 2020-08-28 13:58:43 --> Helper loaded: file_helper
INFO - 2020-08-28 13:58:43 --> Database Driver Class Initialized
INFO - 2020-08-28 13:58:43 --> Email Class Initialized
INFO - 2020-08-28 13:58:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:58:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:58:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:58:43 --> Encryption Class Initialized
INFO - 2020-08-28 13:58:43 --> Model Class Initialized
INFO - 2020-08-28 13:58:43 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:58:43 --> Model Class Initialized
INFO - 2020-08-28 13:58:43 --> Model Class Initialized
INFO - 2020-08-28 13:58:43 --> Controller Class Initialized
ERROR - 2020-08-28 13:58:43 --> 404 Page Not Found: ../modules/Admin/controllers/Admin/Videos
INFO - 2020-08-28 13:58:45 --> Config Class Initialized
INFO - 2020-08-28 13:58:45 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:58:45 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:58:45 --> Utf8 Class Initialized
INFO - 2020-08-28 13:58:45 --> URI Class Initialized
INFO - 2020-08-28 13:58:45 --> Router Class Initialized
INFO - 2020-08-28 13:58:45 --> Output Class Initialized
INFO - 2020-08-28 13:58:45 --> Security Class Initialized
DEBUG - 2020-08-28 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:58:45 --> Input Class Initialized
INFO - 2020-08-28 13:58:45 --> Language Class Initialized
INFO - 2020-08-28 13:58:45 --> Language Class Initialized
INFO - 2020-08-28 13:58:45 --> Config Class Initialized
INFO - 2020-08-28 13:58:45 --> Loader Class Initialized
INFO - 2020-08-28 13:58:45 --> Helper loaded: url_helper
INFO - 2020-08-28 13:58:45 --> Helper loaded: file_helper
INFO - 2020-08-28 13:58:45 --> Database Driver Class Initialized
INFO - 2020-08-28 13:58:45 --> Email Class Initialized
INFO - 2020-08-28 13:58:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:58:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:58:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:58:45 --> Encryption Class Initialized
INFO - 2020-08-28 13:58:45 --> Model Class Initialized
INFO - 2020-08-28 13:58:45 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:58:45 --> Model Class Initialized
INFO - 2020-08-28 13:58:45 --> Model Class Initialized
INFO - 2020-08-28 13:58:45 --> Controller Class Initialized
DEBUG - 2020-08-28 13:58:45 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:58:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:58:46 --> Final output sent to browser
DEBUG - 2020-08-28 13:58:46 --> Total execution time: 0.6056
INFO - 2020-08-28 13:58:54 --> Config Class Initialized
INFO - 2020-08-28 13:58:54 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:58:54 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:58:54 --> Utf8 Class Initialized
INFO - 2020-08-28 13:58:54 --> URI Class Initialized
INFO - 2020-08-28 13:58:54 --> Router Class Initialized
INFO - 2020-08-28 13:58:54 --> Output Class Initialized
INFO - 2020-08-28 13:58:54 --> Security Class Initialized
DEBUG - 2020-08-28 13:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:58:54 --> Input Class Initialized
INFO - 2020-08-28 13:58:54 --> Language Class Initialized
INFO - 2020-08-28 13:58:54 --> Language Class Initialized
INFO - 2020-08-28 13:58:54 --> Config Class Initialized
INFO - 2020-08-28 13:58:54 --> Loader Class Initialized
INFO - 2020-08-28 13:58:54 --> Helper loaded: url_helper
INFO - 2020-08-28 13:58:54 --> Helper loaded: file_helper
INFO - 2020-08-28 13:58:54 --> Database Driver Class Initialized
INFO - 2020-08-28 13:58:54 --> Email Class Initialized
INFO - 2020-08-28 13:58:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:58:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:58:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:58:54 --> Encryption Class Initialized
INFO - 2020-08-28 13:58:54 --> Model Class Initialized
INFO - 2020-08-28 13:58:54 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:58:54 --> Model Class Initialized
INFO - 2020-08-28 13:58:54 --> Model Class Initialized
INFO - 2020-08-28 13:58:54 --> Controller Class Initialized
ERROR - 2020-08-28 13:58:54 --> 404 Page Not Found: ../modules/Admin/controllers/Admin/Videos
INFO - 2020-08-28 13:58:56 --> Config Class Initialized
INFO - 2020-08-28 13:58:56 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:58:56 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:58:56 --> Utf8 Class Initialized
INFO - 2020-08-28 13:58:56 --> URI Class Initialized
INFO - 2020-08-28 13:58:56 --> Router Class Initialized
INFO - 2020-08-28 13:58:56 --> Output Class Initialized
INFO - 2020-08-28 13:58:56 --> Security Class Initialized
DEBUG - 2020-08-28 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:58:56 --> Input Class Initialized
INFO - 2020-08-28 13:58:56 --> Language Class Initialized
INFO - 2020-08-28 13:58:56 --> Language Class Initialized
INFO - 2020-08-28 13:58:56 --> Config Class Initialized
INFO - 2020-08-28 13:58:56 --> Loader Class Initialized
INFO - 2020-08-28 13:58:56 --> Helper loaded: url_helper
INFO - 2020-08-28 13:58:56 --> Helper loaded: file_helper
INFO - 2020-08-28 13:58:56 --> Database Driver Class Initialized
INFO - 2020-08-28 13:58:56 --> Email Class Initialized
INFO - 2020-08-28 13:58:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:58:56 --> Encryption Class Initialized
INFO - 2020-08-28 13:58:56 --> Model Class Initialized
INFO - 2020-08-28 13:58:56 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:58:56 --> Model Class Initialized
INFO - 2020-08-28 13:58:56 --> Model Class Initialized
INFO - 2020-08-28 13:58:56 --> Controller Class Initialized
DEBUG - 2020-08-28 13:58:56 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:58:56 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:58:56 --> Final output sent to browser
DEBUG - 2020-08-28 13:58:57 --> Total execution time: 0.6707
INFO - 2020-08-28 13:59:24 --> Config Class Initialized
INFO - 2020-08-28 13:59:24 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:59:24 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:59:24 --> Utf8 Class Initialized
INFO - 2020-08-28 13:59:25 --> URI Class Initialized
INFO - 2020-08-28 13:59:25 --> Router Class Initialized
INFO - 2020-08-28 13:59:25 --> Output Class Initialized
INFO - 2020-08-28 13:59:25 --> Security Class Initialized
DEBUG - 2020-08-28 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:59:25 --> Input Class Initialized
INFO - 2020-08-28 13:59:25 --> Language Class Initialized
INFO - 2020-08-28 13:59:25 --> Language Class Initialized
INFO - 2020-08-28 13:59:25 --> Config Class Initialized
INFO - 2020-08-28 13:59:25 --> Loader Class Initialized
INFO - 2020-08-28 13:59:25 --> Helper loaded: url_helper
INFO - 2020-08-28 13:59:25 --> Helper loaded: file_helper
INFO - 2020-08-28 13:59:25 --> Database Driver Class Initialized
INFO - 2020-08-28 13:59:25 --> Email Class Initialized
INFO - 2020-08-28 13:59:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:59:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:59:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:59:25 --> Encryption Class Initialized
INFO - 2020-08-28 13:59:25 --> Model Class Initialized
INFO - 2020-08-28 13:59:25 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:59:25 --> Model Class Initialized
INFO - 2020-08-28 13:59:25 --> Model Class Initialized
INFO - 2020-08-28 13:59:25 --> Controller Class Initialized
DEBUG - 2020-08-28 13:59:25 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:59:25 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:59:25 --> Final output sent to browser
DEBUG - 2020-08-28 13:59:25 --> Total execution time: 0.7214
INFO - 2020-08-28 13:59:27 --> Config Class Initialized
INFO - 2020-08-28 13:59:27 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:59:27 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:59:27 --> Utf8 Class Initialized
INFO - 2020-08-28 13:59:27 --> URI Class Initialized
INFO - 2020-08-28 13:59:27 --> Router Class Initialized
INFO - 2020-08-28 13:59:27 --> Output Class Initialized
INFO - 2020-08-28 13:59:27 --> Security Class Initialized
DEBUG - 2020-08-28 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:59:27 --> Input Class Initialized
INFO - 2020-08-28 13:59:27 --> Language Class Initialized
INFO - 2020-08-28 13:59:27 --> Language Class Initialized
INFO - 2020-08-28 13:59:27 --> Config Class Initialized
INFO - 2020-08-28 13:59:27 --> Loader Class Initialized
INFO - 2020-08-28 13:59:27 --> Helper loaded: url_helper
INFO - 2020-08-28 13:59:27 --> Helper loaded: file_helper
INFO - 2020-08-28 13:59:27 --> Database Driver Class Initialized
INFO - 2020-08-28 13:59:27 --> Email Class Initialized
INFO - 2020-08-28 13:59:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:59:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:59:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:59:27 --> Encryption Class Initialized
INFO - 2020-08-28 13:59:27 --> Model Class Initialized
INFO - 2020-08-28 13:59:27 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:59:27 --> Model Class Initialized
INFO - 2020-08-28 13:59:27 --> Model Class Initialized
INFO - 2020-08-28 13:59:27 --> Controller Class Initialized
ERROR - 2020-08-28 13:59:27 --> 404 Page Not Found: ../modules/Admin/controllers/Videos/index
INFO - 2020-08-28 13:59:46 --> Config Class Initialized
INFO - 2020-08-28 13:59:46 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:59:46 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:59:46 --> Utf8 Class Initialized
INFO - 2020-08-28 13:59:46 --> URI Class Initialized
INFO - 2020-08-28 13:59:46 --> Router Class Initialized
INFO - 2020-08-28 13:59:46 --> Output Class Initialized
INFO - 2020-08-28 13:59:46 --> Security Class Initialized
DEBUG - 2020-08-28 13:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:59:46 --> Input Class Initialized
INFO - 2020-08-28 13:59:46 --> Language Class Initialized
INFO - 2020-08-28 13:59:46 --> Language Class Initialized
INFO - 2020-08-28 13:59:46 --> Config Class Initialized
INFO - 2020-08-28 13:59:46 --> Loader Class Initialized
INFO - 2020-08-28 13:59:46 --> Helper loaded: url_helper
INFO - 2020-08-28 13:59:46 --> Helper loaded: file_helper
INFO - 2020-08-28 13:59:46 --> Database Driver Class Initialized
INFO - 2020-08-28 13:59:46 --> Email Class Initialized
INFO - 2020-08-28 13:59:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:59:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:59:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:59:46 --> Encryption Class Initialized
INFO - 2020-08-28 13:59:46 --> Model Class Initialized
INFO - 2020-08-28 13:59:46 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:59:46 --> Model Class Initialized
INFO - 2020-08-28 13:59:46 --> Model Class Initialized
INFO - 2020-08-28 13:59:46 --> Controller Class Initialized
DEBUG - 2020-08-28 13:59:46 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:59:46 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:59:46 --> Final output sent to browser
DEBUG - 2020-08-28 13:59:46 --> Total execution time: 0.4703
INFO - 2020-08-28 13:59:49 --> Config Class Initialized
INFO - 2020-08-28 13:59:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:59:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:59:49 --> Utf8 Class Initialized
INFO - 2020-08-28 13:59:49 --> URI Class Initialized
INFO - 2020-08-28 13:59:49 --> Router Class Initialized
INFO - 2020-08-28 13:59:49 --> Output Class Initialized
INFO - 2020-08-28 13:59:49 --> Security Class Initialized
DEBUG - 2020-08-28 13:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:59:49 --> Input Class Initialized
INFO - 2020-08-28 13:59:49 --> Language Class Initialized
INFO - 2020-08-28 13:59:49 --> Language Class Initialized
INFO - 2020-08-28 13:59:49 --> Config Class Initialized
INFO - 2020-08-28 13:59:49 --> Loader Class Initialized
INFO - 2020-08-28 13:59:49 --> Helper loaded: url_helper
INFO - 2020-08-28 13:59:49 --> Helper loaded: file_helper
INFO - 2020-08-28 13:59:49 --> Database Driver Class Initialized
INFO - 2020-08-28 13:59:49 --> Email Class Initialized
INFO - 2020-08-28 13:59:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:59:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:59:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:59:50 --> Encryption Class Initialized
INFO - 2020-08-28 13:59:50 --> Model Class Initialized
INFO - 2020-08-28 13:59:50 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:59:50 --> Model Class Initialized
INFO - 2020-08-28 13:59:50 --> Model Class Initialized
INFO - 2020-08-28 13:59:50 --> Controller Class Initialized
DEBUG - 2020-08-28 13:59:50 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 13:59:50 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 13:59:50 --> Final output sent to browser
DEBUG - 2020-08-28 13:59:50 --> Total execution time: 0.6607
INFO - 2020-08-28 13:59:51 --> Config Class Initialized
INFO - 2020-08-28 13:59:51 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:59:51 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:59:51 --> Utf8 Class Initialized
INFO - 2020-08-28 13:59:51 --> URI Class Initialized
INFO - 2020-08-28 13:59:51 --> Router Class Initialized
INFO - 2020-08-28 13:59:51 --> Output Class Initialized
INFO - 2020-08-28 13:59:51 --> Security Class Initialized
DEBUG - 2020-08-28 13:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:59:51 --> Input Class Initialized
INFO - 2020-08-28 13:59:51 --> Language Class Initialized
INFO - 2020-08-28 13:59:51 --> Language Class Initialized
INFO - 2020-08-28 13:59:51 --> Config Class Initialized
INFO - 2020-08-28 13:59:51 --> Loader Class Initialized
INFO - 2020-08-28 13:59:52 --> Helper loaded: url_helper
INFO - 2020-08-28 13:59:52 --> Helper loaded: file_helper
INFO - 2020-08-28 13:59:52 --> Database Driver Class Initialized
INFO - 2020-08-28 13:59:52 --> Email Class Initialized
INFO - 2020-08-28 13:59:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 13:59:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 13:59:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 13:59:52 --> Encryption Class Initialized
INFO - 2020-08-28 13:59:52 --> Model Class Initialized
INFO - 2020-08-28 13:59:52 --> Helper loaded: inflector_helper
INFO - 2020-08-28 13:59:52 --> Model Class Initialized
INFO - 2020-08-28 13:59:52 --> Model Class Initialized
INFO - 2020-08-28 13:59:52 --> Controller Class Initialized
ERROR - 2020-08-28 13:59:52 --> 404 Page Not Found: ../modules/Admin/controllers/Videos/index
INFO - 2020-08-28 14:00:41 --> Config Class Initialized
INFO - 2020-08-28 14:00:41 --> Hooks Class Initialized
DEBUG - 2020-08-28 14:00:41 --> UTF-8 Support Enabled
INFO - 2020-08-28 14:00:41 --> Utf8 Class Initialized
INFO - 2020-08-28 14:00:41 --> URI Class Initialized
INFO - 2020-08-28 14:00:41 --> Router Class Initialized
INFO - 2020-08-28 14:00:41 --> Output Class Initialized
INFO - 2020-08-28 14:00:41 --> Security Class Initialized
DEBUG - 2020-08-28 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 14:00:41 --> Input Class Initialized
INFO - 2020-08-28 14:00:41 --> Language Class Initialized
INFO - 2020-08-28 14:00:41 --> Language Class Initialized
INFO - 2020-08-28 14:00:41 --> Config Class Initialized
INFO - 2020-08-28 14:00:41 --> Loader Class Initialized
INFO - 2020-08-28 14:00:41 --> Helper loaded: url_helper
INFO - 2020-08-28 14:00:41 --> Helper loaded: file_helper
INFO - 2020-08-28 14:00:41 --> Database Driver Class Initialized
INFO - 2020-08-28 14:00:41 --> Email Class Initialized
INFO - 2020-08-28 14:00:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 14:00:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 14:00:41 --> Encryption Class Initialized
INFO - 2020-08-28 14:00:41 --> Model Class Initialized
INFO - 2020-08-28 14:00:41 --> Helper loaded: inflector_helper
INFO - 2020-08-28 14:00:41 --> Model Class Initialized
INFO - 2020-08-28 14:00:41 --> Model Class Initialized
INFO - 2020-08-28 14:00:41 --> Controller Class Initialized
DEBUG - 2020-08-28 14:00:41 --> Videos MX_Controller Initialized
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/view_videos.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 14:00:41 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 14:00:41 --> Final output sent to browser
DEBUG - 2020-08-28 14:00:41 --> Total execution time: 0.4741
INFO - 2020-08-28 14:00:41 --> Config Class Initialized
INFO - 2020-08-28 14:00:41 --> Hooks Class Initialized
DEBUG - 2020-08-28 14:00:41 --> UTF-8 Support Enabled
INFO - 2020-08-28 14:00:41 --> Utf8 Class Initialized
INFO - 2020-08-28 14:00:41 --> URI Class Initialized
INFO - 2020-08-28 14:00:41 --> Router Class Initialized
INFO - 2020-08-28 14:00:41 --> Output Class Initialized
INFO - 2020-08-28 14:00:41 --> Security Class Initialized
DEBUG - 2020-08-28 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 14:00:41 --> Input Class Initialized
INFO - 2020-08-28 14:00:41 --> Language Class Initialized
INFO - 2020-08-28 14:00:41 --> Language Class Initialized
INFO - 2020-08-28 14:00:41 --> Config Class Initialized
INFO - 2020-08-28 14:00:42 --> Loader Class Initialized
INFO - 2020-08-28 14:00:42 --> Helper loaded: url_helper
INFO - 2020-08-28 14:00:42 --> Helper loaded: file_helper
INFO - 2020-08-28 14:00:42 --> Database Driver Class Initialized
INFO - 2020-08-28 14:00:42 --> Email Class Initialized
INFO - 2020-08-28 14:00:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 14:00:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 14:00:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 14:00:42 --> Encryption Class Initialized
INFO - 2020-08-28 14:00:42 --> Model Class Initialized
INFO - 2020-08-28 14:00:42 --> Helper loaded: inflector_helper
INFO - 2020-08-28 14:00:42 --> Model Class Initialized
INFO - 2020-08-28 14:00:42 --> Model Class Initialized
INFO - 2020-08-28 14:00:42 --> Controller Class Initialized
DEBUG - 2020-08-28 14:00:42 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 14:00:42 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 14:00:42 --> Final output sent to browser
DEBUG - 2020-08-28 14:00:42 --> Total execution time: 0.4470
INFO - 2020-08-28 14:00:43 --> Config Class Initialized
INFO - 2020-08-28 14:00:43 --> Hooks Class Initialized
DEBUG - 2020-08-28 14:00:43 --> UTF-8 Support Enabled
INFO - 2020-08-28 14:00:43 --> Utf8 Class Initialized
INFO - 2020-08-28 14:00:44 --> URI Class Initialized
INFO - 2020-08-28 14:00:44 --> Router Class Initialized
INFO - 2020-08-28 14:00:44 --> Output Class Initialized
INFO - 2020-08-28 14:00:44 --> Security Class Initialized
DEBUG - 2020-08-28 14:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 14:00:44 --> Input Class Initialized
INFO - 2020-08-28 14:00:44 --> Language Class Initialized
INFO - 2020-08-28 14:00:44 --> Language Class Initialized
INFO - 2020-08-28 14:00:44 --> Config Class Initialized
INFO - 2020-08-28 14:00:44 --> Loader Class Initialized
INFO - 2020-08-28 14:00:44 --> Helper loaded: url_helper
INFO - 2020-08-28 14:00:44 --> Helper loaded: file_helper
INFO - 2020-08-28 14:00:44 --> Database Driver Class Initialized
INFO - 2020-08-28 14:00:44 --> Email Class Initialized
INFO - 2020-08-28 14:00:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 14:00:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 14:00:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 14:00:44 --> Encryption Class Initialized
INFO - 2020-08-28 14:00:44 --> Model Class Initialized
INFO - 2020-08-28 14:00:44 --> Helper loaded: inflector_helper
INFO - 2020-08-28 14:00:44 --> Model Class Initialized
INFO - 2020-08-28 14:00:44 --> Model Class Initialized
INFO - 2020-08-28 14:00:44 --> Controller Class Initialized
DEBUG - 2020-08-28 14:00:44 --> Course MX_Controller Initialized
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/course.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 14:00:44 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 14:00:44 --> Final output sent to browser
DEBUG - 2020-08-28 14:00:44 --> Total execution time: 0.9319
INFO - 2020-08-28 14:00:46 --> Config Class Initialized
INFO - 2020-08-28 14:00:46 --> Hooks Class Initialized
DEBUG - 2020-08-28 14:00:46 --> UTF-8 Support Enabled
INFO - 2020-08-28 14:00:46 --> Utf8 Class Initialized
INFO - 2020-08-28 14:00:46 --> URI Class Initialized
INFO - 2020-08-28 14:00:46 --> Router Class Initialized
INFO - 2020-08-28 14:00:46 --> Output Class Initialized
INFO - 2020-08-28 14:00:46 --> Security Class Initialized
DEBUG - 2020-08-28 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 14:00:46 --> Input Class Initialized
INFO - 2020-08-28 14:00:46 --> Language Class Initialized
INFO - 2020-08-28 14:00:46 --> Language Class Initialized
INFO - 2020-08-28 14:00:46 --> Config Class Initialized
INFO - 2020-08-28 14:00:46 --> Loader Class Initialized
INFO - 2020-08-28 14:00:46 --> Helper loaded: url_helper
INFO - 2020-08-28 14:00:46 --> Helper loaded: file_helper
INFO - 2020-08-28 14:00:47 --> Database Driver Class Initialized
INFO - 2020-08-28 14:00:47 --> Email Class Initialized
INFO - 2020-08-28 14:00:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-28 14:00:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-28 14:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-28 14:00:47 --> Encryption Class Initialized
INFO - 2020-08-28 14:00:47 --> Model Class Initialized
INFO - 2020-08-28 14:00:47 --> Helper loaded: inflector_helper
INFO - 2020-08-28 14:00:47 --> Model Class Initialized
INFO - 2020-08-28 14:00:47 --> Model Class Initialized
INFO - 2020-08-28 14:00:47 --> Controller Class Initialized
DEBUG - 2020-08-28 14:00:47 --> Videos MX_Controller Initialized
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/view_videos.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-28 14:00:47 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/view_template.php
INFO - 2020-08-28 14:00:47 --> Final output sent to browser
DEBUG - 2020-08-28 14:00:47 --> Total execution time: 0.4868
