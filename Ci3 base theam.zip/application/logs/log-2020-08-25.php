<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-25 18:40:47 --> Config Class Initialized
INFO - 2020-08-25 18:40:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:40:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:40:47 --> Utf8 Class Initialized
INFO - 2020-08-25 18:40:47 --> URI Class Initialized
DEBUG - 2020-08-25 18:40:48 --> No URI present. Default controller set.
INFO - 2020-08-25 18:40:48 --> Router Class Initialized
INFO - 2020-08-25 18:40:48 --> Output Class Initialized
INFO - 2020-08-25 18:40:48 --> Security Class Initialized
DEBUG - 2020-08-25 18:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:40:48 --> Input Class Initialized
INFO - 2020-08-25 18:40:48 --> Language Class Initialized
INFO - 2020-08-25 18:40:48 --> Language Class Initialized
INFO - 2020-08-25 18:40:48 --> Config Class Initialized
INFO - 2020-08-25 18:40:48 --> Loader Class Initialized
INFO - 2020-08-25 18:40:48 --> Helper loaded: url_helper
INFO - 2020-08-25 18:40:48 --> Helper loaded: file_helper
INFO - 2020-08-25 18:40:48 --> Database Driver Class Initialized
INFO - 2020-08-25 18:40:48 --> Email Class Initialized
INFO - 2020-08-25 18:40:48 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-08-25 18:40:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-08-25 18:40:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-08-25 18:40:48 --> Encryption Class Initialized
INFO - 2020-08-25 18:40:48 --> Model Class Initialized
INFO - 2020-08-25 18:40:48 --> Helper loaded: inflector_helper
INFO - 2020-08-25 18:40:48 --> Model Class Initialized
INFO - 2020-08-25 18:40:48 --> Model Class Initialized
INFO - 2020-08-25 18:40:48 --> Controller Class Initialized
DEBUG - 2020-08-25 18:40:48 --> Admin MX_Controller Initialized
DEBUG - 2020-08-25 18:40:48 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanheader.php
DEBUG - 2020-08-25 18:40:48 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\views\comman_data/commanfooter.php
DEBUG - 2020-08-25 18:40:48 --> File loaded: A:\Xampp\htdocs\salim_works\magic\application\modules/Admin/views/Login.php
INFO - 2020-08-25 18:40:48 --> Final output sent to browser
DEBUG - 2020-08-25 18:40:48 --> Total execution time: 1.2668
