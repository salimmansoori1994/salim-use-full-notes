<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-06 05:45:30 --> Config Class Initialized
INFO - 2020-12-06 05:45:30 --> Config Class Initialized
INFO - 2020-12-06 05:45:30 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:45:30 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:45:30 --> Utf8 Class Initialized
INFO - 2020-12-06 05:45:30 --> URI Class Initialized
INFO - 2020-12-06 05:45:30 --> Hooks Class Initialized
INFO - 2020-12-06 05:45:30 --> Router Class Initialized
INFO - 2020-12-06 05:45:30 --> Output Class Initialized
INFO - 2020-12-06 05:45:30 --> Security Class Initialized
DEBUG - 2020-12-06 05:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:45:30 --> Input Class Initialized
INFO - 2020-12-06 05:45:30 --> Language Class Initialized
ERROR - 2020-12-06 05:45:30 --> 404 Page Not Found: /index
DEBUG - 2020-12-06 05:45:30 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:45:30 --> Utf8 Class Initialized
INFO - 2020-12-06 05:45:30 --> URI Class Initialized
INFO - 2020-12-06 05:45:30 --> Router Class Initialized
INFO - 2020-12-06 05:45:30 --> Output Class Initialized
INFO - 2020-12-06 05:45:30 --> Security Class Initialized
INFO - 2020-12-06 05:45:30 --> Config Class Initialized
INFO - 2020-12-06 05:45:30 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:45:30 --> Input Class Initialized
INFO - 2020-12-06 05:45:30 --> Language Class Initialized
DEBUG - 2020-12-06 05:45:30 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:45:30 --> Utf8 Class Initialized
INFO - 2020-12-06 05:45:30 --> URI Class Initialized
INFO - 2020-12-06 05:45:30 --> Router Class Initialized
ERROR - 2020-12-06 05:45:30 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:45:30 --> Output Class Initialized
INFO - 2020-12-06 05:45:30 --> Security Class Initialized
DEBUG - 2020-12-06 05:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:45:30 --> Config Class Initialized
INFO - 2020-12-06 05:45:30 --> Input Class Initialized
INFO - 2020-12-06 05:45:30 --> Language Class Initialized
ERROR - 2020-12-06 05:45:30 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:45:30 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:45:30 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:45:30 --> Utf8 Class Initialized
INFO - 2020-12-06 05:45:30 --> URI Class Initialized
INFO - 2020-12-06 05:45:30 --> Router Class Initialized
INFO - 2020-12-06 05:45:31 --> Output Class Initialized
INFO - 2020-12-06 05:45:31 --> Security Class Initialized
DEBUG - 2020-12-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:45:31 --> Input Class Initialized
INFO - 2020-12-06 05:45:31 --> Language Class Initialized
ERROR - 2020-12-06 05:45:31 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
INFO - 2020-12-06 05:48:16 --> Config Class Initialized
INFO - 2020-12-06 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:16 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:16 --> URI Class Initialized
INFO - 2020-12-06 05:48:16 --> Router Class Initialized
INFO - 2020-12-06 05:48:16 --> Output Class Initialized
INFO - 2020-12-06 05:48:16 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:16 --> Input Class Initialized
INFO - 2020-12-06 05:48:16 --> Language Class Initialized
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
ERROR - 2020-12-06 05:48:16 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:17 --> Config Class Initialized
INFO - 2020-12-06 05:48:17 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:17 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:17 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:17 --> URI Class Initialized
INFO - 2020-12-06 05:48:17 --> Router Class Initialized
INFO - 2020-12-06 05:48:17 --> Output Class Initialized
INFO - 2020-12-06 05:48:17 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:17 --> Input Class Initialized
INFO - 2020-12-06 05:48:17 --> Language Class Initialized
ERROR - 2020-12-06 05:48:17 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:17 --> Config Class Initialized
INFO - 2020-12-06 05:48:17 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:17 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:17 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:17 --> URI Class Initialized
INFO - 2020-12-06 05:48:17 --> Router Class Initialized
INFO - 2020-12-06 05:48:17 --> Output Class Initialized
INFO - 2020-12-06 05:48:17 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:17 --> Input Class Initialized
INFO - 2020-12-06 05:48:17 --> Language Class Initialized
ERROR - 2020-12-06 05:48:17 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:17 --> Config Class Initialized
INFO - 2020-12-06 05:48:17 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:17 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:17 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:17 --> URI Class Initialized
INFO - 2020-12-06 05:48:17 --> Router Class Initialized
INFO - 2020-12-06 05:48:17 --> Output Class Initialized
INFO - 2020-12-06 05:48:17 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:17 --> Input Class Initialized
INFO - 2020-12-06 05:48:17 --> Language Class Initialized
ERROR - 2020-12-06 05:48:17 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:17 --> Config Class Initialized
INFO - 2020-12-06 05:48:17 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:17 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:17 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:17 --> URI Class Initialized
INFO - 2020-12-06 05:48:17 --> Router Class Initialized
INFO - 2020-12-06 05:48:17 --> Output Class Initialized
INFO - 2020-12-06 05:48:17 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:17 --> Input Class Initialized
INFO - 2020-12-06 05:48:17 --> Language Class Initialized
ERROR - 2020-12-06 05:48:17 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:51 --> Config Class Initialized
INFO - 2020-12-06 05:48:51 --> Config Class Initialized
INFO - 2020-12-06 05:48:51 --> Hooks Class Initialized
INFO - 2020-12-06 05:48:51 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:51 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:51 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:51 --> URI Class Initialized
INFO - 2020-12-06 05:48:51 --> Config Class Initialized
INFO - 2020-12-06 05:48:51 --> Hooks Class Initialized
INFO - 2020-12-06 05:48:51 --> Router Class Initialized
INFO - 2020-12-06 05:48:51 --> Config Class Initialized
INFO - 2020-12-06 05:48:51 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:48:51 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:51 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:51 --> Output Class Initialized
INFO - 2020-12-06 05:48:51 --> URI Class Initialized
DEBUG - 2020-12-06 05:48:51 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:51 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:51 --> Security Class Initialized
INFO - 2020-12-06 05:48:51 --> URI Class Initialized
INFO - 2020-12-06 05:48:51 --> Router Class Initialized
DEBUG - 2020-12-06 05:48:51 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:48:51 --> Utf8 Class Initialized
INFO - 2020-12-06 05:48:51 --> URI Class Initialized
INFO - 2020-12-06 05:48:51 --> Output Class Initialized
INFO - 2020-12-06 05:48:51 --> Security Class Initialized
INFO - 2020-12-06 05:48:51 --> Router Class Initialized
DEBUG - 2020-12-06 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:51 --> Input Class Initialized
INFO - 2020-12-06 05:48:51 --> Language Class Initialized
INFO - 2020-12-06 05:48:51 --> Output Class Initialized
ERROR - 2020-12-06 05:48:51 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:51 --> Security Class Initialized
DEBUG - 2020-12-06 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:51 --> Input Class Initialized
INFO - 2020-12-06 05:48:51 --> Language Class Initialized
DEBUG - 2020-12-06 05:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-12-06 05:48:51 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:51 --> Router Class Initialized
INFO - 2020-12-06 05:48:51 --> Output Class Initialized
INFO - 2020-12-06 05:48:51 --> Security Class Initialized
INFO - 2020-12-06 05:48:51 --> Input Class Initialized
DEBUG - 2020-12-06 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:48:51 --> Input Class Initialized
INFO - 2020-12-06 05:48:51 --> Language Class Initialized
ERROR - 2020-12-06 05:48:51 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:48:51 --> Language Class Initialized
ERROR - 2020-12-06 05:48:51 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
INFO - 2020-12-06 05:49:03 --> Config Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Hooks Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
DEBUG - 2020-12-06 05:49:03 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:03 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
INFO - 2020-12-06 05:49:03 --> URI Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
INFO - 2020-12-06 05:49:03 --> Router Class Initialized
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Output Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
INFO - 2020-12-06 05:49:03 --> Security Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
DEBUG - 2020-12-06 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:03 --> Input Class Initialized
INFO - 2020-12-06 05:49:03 --> Language Class Initialized
ERROR - 2020-12-06 05:49:03 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:04 --> Config Class Initialized
INFO - 2020-12-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:04 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:04 --> URI Class Initialized
INFO - 2020-12-06 05:49:04 --> Router Class Initialized
INFO - 2020-12-06 05:49:04 --> Output Class Initialized
INFO - 2020-12-06 05:49:04 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:04 --> Input Class Initialized
INFO - 2020-12-06 05:49:04 --> Language Class Initialized
ERROR - 2020-12-06 05:49:04 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:04 --> Config Class Initialized
INFO - 2020-12-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:04 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:04 --> URI Class Initialized
INFO - 2020-12-06 05:49:04 --> Router Class Initialized
INFO - 2020-12-06 05:49:04 --> Output Class Initialized
INFO - 2020-12-06 05:49:04 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:04 --> Input Class Initialized
INFO - 2020-12-06 05:49:04 --> Language Class Initialized
ERROR - 2020-12-06 05:49:04 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:04 --> Config Class Initialized
INFO - 2020-12-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:04 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:04 --> URI Class Initialized
INFO - 2020-12-06 05:49:04 --> Router Class Initialized
INFO - 2020-12-06 05:49:04 --> Output Class Initialized
INFO - 2020-12-06 05:49:04 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:04 --> Input Class Initialized
INFO - 2020-12-06 05:49:04 --> Language Class Initialized
ERROR - 2020-12-06 05:49:04 --> 404 Page Not Found: /index
INFO - 2020-12-06 05:49:04 --> Config Class Initialized
INFO - 2020-12-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2020-12-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2020-12-06 05:49:04 --> Utf8 Class Initialized
INFO - 2020-12-06 05:49:04 --> URI Class Initialized
INFO - 2020-12-06 05:49:04 --> Router Class Initialized
INFO - 2020-12-06 05:49:05 --> Output Class Initialized
INFO - 2020-12-06 05:49:05 --> Security Class Initialized
DEBUG - 2020-12-06 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-06 05:49:05 --> Input Class Initialized
INFO - 2020-12-06 05:49:05 --> Language Class Initialized
ERROR - 2020-12-06 05:49:05 --> 404 Page Not Found: /index
