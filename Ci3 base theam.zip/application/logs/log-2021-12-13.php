<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-13 05:21:35 --> Config Class Initialized
INFO - 2021-12-13 05:21:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 05:21:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 05:21:36 --> Utf8 Class Initialized
INFO - 2021-12-13 05:21:36 --> URI Class Initialized
DEBUG - 2021-12-13 05:21:36 --> No URI present. Default controller set.
INFO - 2021-12-13 05:21:36 --> Router Class Initialized
INFO - 2021-12-13 05:21:36 --> Output Class Initialized
INFO - 2021-12-13 05:21:36 --> Security Class Initialized
DEBUG - 2021-12-13 05:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 05:21:36 --> Input Class Initialized
INFO - 2021-12-13 05:21:36 --> Language Class Initialized
INFO - 2021-12-13 05:21:36 --> Language Class Initialized
INFO - 2021-12-13 05:21:36 --> Config Class Initialized
INFO - 2021-12-13 05:21:36 --> Loader Class Initialized
INFO - 2021-12-13 05:21:36 --> Helper loaded: url_helper
INFO - 2021-12-13 05:21:36 --> Helper loaded: file_helper
INFO - 2021-12-13 05:21:36 --> Helper loaded: common_helper
INFO - 2021-12-13 05:21:36 --> Database Driver Class Initialized
INFO - 2021-12-13 05:21:36 --> Email Class Initialized
INFO - 2021-12-13 05:21:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2021-12-13 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-12-13 05:21:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-12-13 05:21:36 --> Encryption Class Initialized
INFO - 2021-12-13 05:21:36 --> Model Class Initialized
INFO - 2021-12-13 05:21:36 --> Helper loaded: inflector_helper
INFO - 2021-12-13 05:21:36 --> Model Class Initialized
INFO - 2021-12-13 05:21:36 --> Model Class Initialized
INFO - 2021-12-13 05:21:36 --> Controller Class Initialized
DEBUG - 2021-12-13 05:21:36 --> Admin MX_Controller Initialized
DEBUG - 2021-12-13 05:21:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanheader.php
DEBUG - 2021-12-13 05:21:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\views\comman_data/commanfooter.php
DEBUG - 2021-12-13 05:21:36 --> File loaded: A:\Xampp\htdocs\salim_works\Basetheme\application\modules/Admin/views/login.php
INFO - 2021-12-13 05:21:36 --> Final output sent to browser
DEBUG - 2021-12-13 05:21:36 --> Total execution time: 0.6709
