<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-07 07:43:34 --> Config Class Initialized
INFO - 2020-09-07 07:43:34 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:35 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:35 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:35 --> URI Class Initialized
DEBUG - 2020-09-07 07:43:35 --> No URI present. Default controller set.
INFO - 2020-09-07 07:43:35 --> Router Class Initialized
INFO - 2020-09-07 07:43:35 --> Output Class Initialized
INFO - 2020-09-07 07:43:35 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:35 --> Input Class Initialized
INFO - 2020-09-07 07:43:35 --> Language Class Initialized
INFO - 2020-09-07 07:43:35 --> Language Class Initialized
INFO - 2020-09-07 07:43:35 --> Config Class Initialized
INFO - 2020-09-07 07:43:35 --> Loader Class Initialized
INFO - 2020-09-07 07:43:35 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:35 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:35 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:35 --> Email Class Initialized
INFO - 2020-09-07 07:43:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:36 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:36 --> Model Class Initialized
INFO - 2020-09-07 07:43:36 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:36 --> Model Class Initialized
INFO - 2020-09-07 07:43:36 --> Model Class Initialized
INFO - 2020-09-07 07:43:36 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:36 --> Admin MX_Controller Initialized
DEBUG - 2020-09-07 07:43:36 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:43:36 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:43:36 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/Login.php
INFO - 2020-09-07 07:43:36 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:36 --> Total execution time: 1.4755
INFO - 2020-09-07 07:43:42 --> Config Class Initialized
INFO - 2020-09-07 07:43:43 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:43 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:43 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:43 --> URI Class Initialized
INFO - 2020-09-07 07:43:43 --> Router Class Initialized
INFO - 2020-09-07 07:43:43 --> Output Class Initialized
INFO - 2020-09-07 07:43:43 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:43 --> Input Class Initialized
INFO - 2020-09-07 07:43:43 --> Language Class Initialized
INFO - 2020-09-07 07:43:43 --> Language Class Initialized
INFO - 2020-09-07 07:43:43 --> Config Class Initialized
INFO - 2020-09-07 07:43:43 --> Loader Class Initialized
INFO - 2020-09-07 07:43:43 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:43 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:43 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:43 --> Email Class Initialized
INFO - 2020-09-07 07:43:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:43 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:43 --> Model Class Initialized
INFO - 2020-09-07 07:43:43 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:43 --> Model Class Initialized
INFO - 2020-09-07 07:43:43 --> Model Class Initialized
INFO - 2020-09-07 07:43:43 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:43 --> Admin MX_Controller Initialized
INFO - 2020-09-07 07:43:43 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:43 --> Total execution time: 0.3670
INFO - 2020-09-07 07:43:46 --> Config Class Initialized
INFO - 2020-09-07 07:43:46 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:46 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:46 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:46 --> URI Class Initialized
INFO - 2020-09-07 07:43:46 --> Router Class Initialized
INFO - 2020-09-07 07:43:46 --> Output Class Initialized
INFO - 2020-09-07 07:43:46 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:46 --> Input Class Initialized
INFO - 2020-09-07 07:43:46 --> Language Class Initialized
INFO - 2020-09-07 07:43:46 --> Language Class Initialized
INFO - 2020-09-07 07:43:46 --> Config Class Initialized
INFO - 2020-09-07 07:43:46 --> Loader Class Initialized
INFO - 2020-09-07 07:43:46 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:46 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:46 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:46 --> Email Class Initialized
INFO - 2020-09-07 07:43:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:46 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:46 --> Model Class Initialized
INFO - 2020-09-07 07:43:46 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:46 --> Model Class Initialized
INFO - 2020-09-07 07:43:46 --> Model Class Initialized
INFO - 2020-09-07 07:43:46 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:46 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-07 07:43:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:43:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:43:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:43:46 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-07 07:43:47 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:43:47 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:43:47 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:43:47 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:47 --> Total execution time: 0.5758
INFO - 2020-09-07 07:43:50 --> Config Class Initialized
INFO - 2020-09-07 07:43:50 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:50 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:50 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:50 --> URI Class Initialized
INFO - 2020-09-07 07:43:50 --> Router Class Initialized
INFO - 2020-09-07 07:43:50 --> Output Class Initialized
INFO - 2020-09-07 07:43:50 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:50 --> Input Class Initialized
INFO - 2020-09-07 07:43:50 --> Language Class Initialized
INFO - 2020-09-07 07:43:50 --> Language Class Initialized
INFO - 2020-09-07 07:43:50 --> Config Class Initialized
INFO - 2020-09-07 07:43:50 --> Loader Class Initialized
INFO - 2020-09-07 07:43:50 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:50 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:50 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:50 --> Email Class Initialized
INFO - 2020-09-07 07:43:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:50 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:51 --> Model Class Initialized
INFO - 2020-09-07 07:43:51 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:51 --> Model Class Initialized
INFO - 2020-09-07 07:43:51 --> Model Class Initialized
INFO - 2020-09-07 07:43:51 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:51 --> Card MX_Controller Initialized
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:43:51 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:43:51 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:51 --> Total execution time: 0.5476
INFO - 2020-09-07 07:43:54 --> Config Class Initialized
INFO - 2020-09-07 07:43:54 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:54 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:54 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:54 --> URI Class Initialized
INFO - 2020-09-07 07:43:54 --> Router Class Initialized
INFO - 2020-09-07 07:43:54 --> Output Class Initialized
INFO - 2020-09-07 07:43:54 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:54 --> Input Class Initialized
INFO - 2020-09-07 07:43:54 --> Language Class Initialized
INFO - 2020-09-07 07:43:54 --> Language Class Initialized
INFO - 2020-09-07 07:43:54 --> Config Class Initialized
INFO - 2020-09-07 07:43:54 --> Loader Class Initialized
INFO - 2020-09-07 07:43:54 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:54 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:54 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:54 --> Email Class Initialized
INFO - 2020-09-07 07:43:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:54 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:54 --> Model Class Initialized
INFO - 2020-09-07 07:43:54 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:54 --> Model Class Initialized
INFO - 2020-09-07 07:43:54 --> Model Class Initialized
INFO - 2020-09-07 07:43:54 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:54 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:43:54 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:43:54 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:54 --> Total execution time: 0.5843
INFO - 2020-09-07 07:43:56 --> Config Class Initialized
INFO - 2020-09-07 07:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:43:56 --> Utf8 Class Initialized
INFO - 2020-09-07 07:43:56 --> URI Class Initialized
INFO - 2020-09-07 07:43:56 --> Router Class Initialized
INFO - 2020-09-07 07:43:56 --> Output Class Initialized
INFO - 2020-09-07 07:43:56 --> Security Class Initialized
DEBUG - 2020-09-07 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:43:56 --> Input Class Initialized
INFO - 2020-09-07 07:43:56 --> Language Class Initialized
INFO - 2020-09-07 07:43:56 --> Language Class Initialized
INFO - 2020-09-07 07:43:56 --> Config Class Initialized
INFO - 2020-09-07 07:43:56 --> Loader Class Initialized
INFO - 2020-09-07 07:43:56 --> Helper loaded: url_helper
INFO - 2020-09-07 07:43:56 --> Helper loaded: file_helper
INFO - 2020-09-07 07:43:56 --> Database Driver Class Initialized
INFO - 2020-09-07 07:43:56 --> Email Class Initialized
INFO - 2020-09-07 07:43:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:43:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:43:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:43:56 --> Encryption Class Initialized
INFO - 2020-09-07 07:43:56 --> Model Class Initialized
INFO - 2020-09-07 07:43:56 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:43:56 --> Model Class Initialized
INFO - 2020-09-07 07:43:56 --> Model Class Initialized
INFO - 2020-09-07 07:43:56 --> Controller Class Initialized
DEBUG - 2020-09-07 07:43:56 --> Card MX_Controller Initialized
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:43:56 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:43:56 --> Final output sent to browser
DEBUG - 2020-09-07 07:43:56 --> Total execution time: 0.5220
INFO - 2020-09-07 07:46:40 --> Config Class Initialized
INFO - 2020-09-07 07:46:40 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:46:40 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:46:40 --> Utf8 Class Initialized
INFO - 2020-09-07 07:46:41 --> URI Class Initialized
INFO - 2020-09-07 07:46:41 --> Router Class Initialized
INFO - 2020-09-07 07:46:41 --> Output Class Initialized
INFO - 2020-09-07 07:46:41 --> Security Class Initialized
DEBUG - 2020-09-07 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:46:41 --> Input Class Initialized
INFO - 2020-09-07 07:46:41 --> Language Class Initialized
INFO - 2020-09-07 07:46:41 --> Language Class Initialized
INFO - 2020-09-07 07:46:41 --> Config Class Initialized
INFO - 2020-09-07 07:46:41 --> Loader Class Initialized
INFO - 2020-09-07 07:46:41 --> Helper loaded: url_helper
INFO - 2020-09-07 07:46:41 --> Helper loaded: file_helper
INFO - 2020-09-07 07:46:41 --> Database Driver Class Initialized
INFO - 2020-09-07 07:46:41 --> Email Class Initialized
INFO - 2020-09-07 07:46:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:46:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:46:41 --> Encryption Class Initialized
INFO - 2020-09-07 07:46:41 --> Model Class Initialized
INFO - 2020-09-07 07:46:41 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:46:41 --> Model Class Initialized
INFO - 2020-09-07 07:46:41 --> Model Class Initialized
INFO - 2020-09-07 07:46:41 --> Controller Class Initialized
DEBUG - 2020-09-07 07:46:41 --> Admin_dashboard MX_Controller Initialized
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/admin_dashboard.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:46:41 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:46:41 --> Final output sent to browser
DEBUG - 2020-09-07 07:46:41 --> Total execution time: 0.6471
INFO - 2020-09-07 07:46:43 --> Config Class Initialized
INFO - 2020-09-07 07:46:43 --> Hooks Class Initialized
DEBUG - 2020-09-07 07:46:43 --> UTF-8 Support Enabled
INFO - 2020-09-07 07:46:43 --> Utf8 Class Initialized
INFO - 2020-09-07 07:46:43 --> URI Class Initialized
INFO - 2020-09-07 07:46:43 --> Router Class Initialized
INFO - 2020-09-07 07:46:43 --> Output Class Initialized
INFO - 2020-09-07 07:46:43 --> Security Class Initialized
DEBUG - 2020-09-07 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 07:46:43 --> Input Class Initialized
INFO - 2020-09-07 07:46:43 --> Language Class Initialized
INFO - 2020-09-07 07:46:43 --> Language Class Initialized
INFO - 2020-09-07 07:46:43 --> Config Class Initialized
INFO - 2020-09-07 07:46:43 --> Loader Class Initialized
INFO - 2020-09-07 07:46:43 --> Helper loaded: url_helper
INFO - 2020-09-07 07:46:43 --> Helper loaded: file_helper
INFO - 2020-09-07 07:46:43 --> Database Driver Class Initialized
INFO - 2020-09-07 07:46:43 --> Email Class Initialized
INFO - 2020-09-07 07:46:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-09-07 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-07 07:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-07 07:46:43 --> Encryption Class Initialized
INFO - 2020-09-07 07:46:43 --> Model Class Initialized
INFO - 2020-09-07 07:46:43 --> Helper loaded: inflector_helper
INFO - 2020-09-07 07:46:43 --> Model Class Initialized
INFO - 2020-09-07 07:46:43 --> Model Class Initialized
INFO - 2020-09-07 07:46:43 --> Controller Class Initialized
DEBUG - 2020-09-07 07:46:43 --> Card MX_Controller Initialized
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanheader.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_head_bar.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_side_bar.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\modules/Admin/views/new_card.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/comman_footer_text.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/commanfooter.php
DEBUG - 2020-09-07 07:46:43 --> File loaded: A:\Xampp\htdocs\salim_works\WebCard\application\views\comman_data/view_template.php
INFO - 2020-09-07 07:46:43 --> Final output sent to browser
DEBUG - 2020-09-07 07:46:43 --> Total execution time: 0.6061
