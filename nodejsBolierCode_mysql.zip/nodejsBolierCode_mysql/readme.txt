start project :   nodemon app.js

url : 
http://localhost:8080/loyalty_system/all_CustomerPoints