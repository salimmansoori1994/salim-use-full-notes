const express = require('express');


const loyalty_pointsController = require('../controllers/loyalty_points');

const isAuth = require('../middleware/pos-auth');

const router = express.Router();

//doamin/loyalty_system/----

router.get('/all_CustomerPoints',isAuth,loyalty_pointsController.all_CustomerPoints);

router.post('/get_CustomerListByShop',isAuth,loyalty_pointsController.CustomerListByShop);

router.post('/get_CustomerPoints',isAuth,loyalty_pointsController.get_CustomerPoints);

router.post('/CustomerPointsLogs',isAuth,loyalty_pointsController.CustomerPointsLogs);

router.post('/SubtractPoints',isAuth,loyalty_pointsController.SubtractPoints);

router.post('/AddPoints',isAuth,loyalty_pointsController.AddPoints);

router.post('/AddCustomer',isAuth,loyalty_pointsController.AddCustomer);

router.post('/AddCustomer_Pos_Loyalty',isAuth,loyalty_pointsController.AddCustomer_Pos_Loyalty);

router.post('/UpdateCustomer',isAuth,loyalty_pointsController.UpdateCustomer);

router.post('/DeleteCustomer',isAuth,loyalty_pointsController.DeleteCustomer);


module.exports = router;

