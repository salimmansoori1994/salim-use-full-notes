module.exports  = (req,res,next) =>{
    const token = req.get('Authorization').split(' ')[1];

    if(token == 'OXU0c0JkY3AyNU1acmFqRTM3U1kxeGx2azpCNFJ6VWRIcnB4RXVxVFdPUUdKWFBudEw4'){
        next();
    }else{
        res.status(400).json({
            status: false,
            mass: 'Token not match.',
        });
    }

    // console.log('TOKEn',token);
}