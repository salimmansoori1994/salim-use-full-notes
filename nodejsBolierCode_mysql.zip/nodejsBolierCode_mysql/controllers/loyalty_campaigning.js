const CampaigningServices = require('../services/loyaltyCampaigningServices');

const Campaigning = new CampaigningServices();

exports.All_campaigning_list = async (req, res, next) => {

    try {

        let data = await Campaigning.All_campaigning_list();
        res.status(200).json(data);

    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        });
    }

}

/************************************************************** */

exports.Campaigning_shopEnroll = async (req, res, next) => {

    try {

        let data = await Campaigning.Campaigning_shopEnroll(req.body);
        res.status(200).json(data);

    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        });
    }

}
/************************************************************** */

exports.Update_Campaigning_shopEnroll = async (req, res, next) => {

    try {

        let data = await Campaigning.Update_Campaigning_shopEnroll(req.body);
        res.status(200).json(data);

    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        });
    }

}
/************************************************************** */

exports.ShopEnrollList = async (req, res, next) => {

    try {
        let data = await Campaigning.ShopEnrollList();
        res.status(200).json(data);

    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        });
    }

}
/************************************************************** */

exports.ShopEnrolls = async (req, res, next) => {

    try {

        var shop_id = req.params.sid;

        let data = await Campaigning.ShopEnrolls(shop_id);
        res.status(200).json(data);

    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        });
    }

}
/************************************************************** */

exports.Update_campaigning = async (req, res, next) =>{ 
    try {
        let data = await Campaigning.Update_campaigning(req.body);
        res.status(200).json(data);
    } catch (error) {
        res.status(400).json({
            status: false,
            mass: 'error',
            data: error
        }); 
    }
}
