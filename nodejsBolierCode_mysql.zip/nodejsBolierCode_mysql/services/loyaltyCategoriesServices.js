const { execute } = require('../util/database');
const db = require('../util/database');

module.exports = class Services {

    /************************************************************** */
    Add_loyalty_ShopCategories = async (imageUrl,data) => {
        try {
                var category_name = data.category_name;
                var poiting_level = data.poiting_level;
                var discount_points = data.discount_points;
                var category_disctription = data.category_disctription;
                var shop_id = data.shop_id;
                var userfor = data.userfor;
            // let [rows, fields] = await db.execute("select * from customer_point");

            await db.execute("INSERT INTO shop_loyaltycategories(category_image,category_name,poiting_level,discount_points,category_disctription,shop_id,userfor) VALUES (?,?,?,?,?,?,?)", [imageUrl, category_name, poiting_level, discount_points,category_disctription,shop_id,userfor]);

            return {
                status: true, mass: 'Category has been added.'
            };

        } catch (error) {
            console.log(error);
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

        /************************************************************** */

    
        Get_loyalty_ShopCategories  = async (shop_id,userfor) =>{
            try {
                let [rows, fields] = await db.execute("select * from shop_loyaltycategories where shop_id = ? and userfor = ?",[shop_id,userfor]);
                if (rows.length >= 1) { 
                    return{
                        status: true, mass: 'All Categories List.',data:rows
                    };
                }else{
                    return{
                        status: false, mass: 'Not Avialble any Categories for this shop.'
                    };
                }
            } catch (error) {
                return {
                    status: false,
                    mass: 'error',
                    data: error
                } 
            }
        }
        
        /************************************************************** */

        Update_loyalty_ShopCategories = async (imageUrl,cat_id,data) =>{
            try {
                var category_name = data.category_name;
                var poiting_level = data.poiting_level;
                var discount_points = data.discount_points;
                var category_disctription = data.category_disctription;

                await db.execute("Update shop_loyaltycategories set category_name = ? , poiting_level = ? , discount_points = ? , category_disctription = ? where  category_id = ?",[category_name,poiting_level,discount_points,category_disctription,cat_id]);

                if(imageUrl){
                    await db.execute("Update shop_loyaltycategories set category_image = ?  where  category_id = ?",[category_name,cat_id]);    
                }
                
                return{
                    status: true, mass: 'Categories has been updated successfully.'
                };

            } catch (error) {
                return {
                    status: false,
                    mass: 'error',
                    data: error
                } 
            }
        }

                /************************************************************** */
                Delete_loyalty_ShopCategories = async  (cat_id)  =>{
                    try {
                        await db.execute("Delete from shop_loyaltycategories where category_id = ?",[cat_id]);
                        return{
                            status: true, mass: 'Categories has been deleted successfully.'
                        };
                    } catch (error) {
                        return {
                            status: false,
                            mass: 'error',
                            data: error
                        } 
                    }
                }

                /************************************************************** */
                Get_loyalty_ShopCategoriesDetails = async(cat_id) => {
                    try {
                        let [rows, fields] = await db.execute("select * from shop_loyaltycategories where category_id = ?",[cat_id]);
                        if (rows.length >= 1) { 
                            return{
                                status: true, mass: 'Categories Details.',data:rows
                            };
                        }else{
                            return{
                                status: false, mass: 'Categories Not Avialble for this shop.'
                            };
                        } 
                    } catch (error) {
                        return {
                            status: false,
                            mass: 'error',
                            data: error
                        } 
                    }
                }
              

} 