const mysql = require('mysql2');

const pool = mysql.createPool({
    host:'localhost',
    // user:'bestloyalty_loyalty_system',
    // database:'bestloyalty_loyalty_system_sanbox',
    // password:'PiVTM)xzeSqK'
    user:'root',
    database:'salim_qrordr_loyalty_system',
    password:''
});


module.exports = pool.promise(); 
	