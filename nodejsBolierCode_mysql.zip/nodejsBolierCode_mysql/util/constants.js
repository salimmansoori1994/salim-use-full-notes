//satbox
const POS_API = 'https://retransformx.online/';
const POS_Authorization = 'OXU0c0JkY3AyNU1acmFqRTM3U1kxeGx2azpCNFJ6VWRIcnB4RXVxVFdPUUdKWFBudEw4';
const Loyalty_verification_baseurl = 'https://sandbox.qrordr.com/loyaltyVerification/';

//live
// const POS_API = 'https://sandbox.sendio.online/';
// const POS_Authorization = 'OXU0c0JkY3AyNU1acmFqRTM3U1kxeGx2azpCNFJ6VWRIcnB4RXVxVFdPUUdKWFBudEw4';
// const Loyalty_verification_baseurl = 'https://qrordr.com/loyaltyVerification/';
// const MAX_THREADS = 5

exports.POS_API = POS_API
exports.POS_Authorization = POS_Authorization
exports.Loyalty_verification_baseurl = Loyalty_verification_baseurl
// exports.MAX_THREADS = MAX_THREADS