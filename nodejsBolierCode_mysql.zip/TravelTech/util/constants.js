
const POS_API = 'https://retransformx.online/';
exports.POS_API = POS_API
