const db = require('../util/database');

module.exports = class Campaigning {

    /************************************************************** */
    All_campaigning_list = async () => {

        try {

            let [rows, fields] = await db.execute("select * from loyalty_campaigning");

            if (rows.length >= 1) {
                return { status: true, mass: 'campaigning list.', data: rows }
            } else {
                return { status: false, mass: 'campaigning not found.' }
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }

    }

    /************************************************************** */

    Campaigning_shopEnroll = async (data) => {

        var campaigning_id = data.campaigning_id;
        var shop_id = data.shop_id;
        var providing_points = data.providing_points;
        var shopCampaigning_fromdate = data.shopCampaigning_fromdate;
        var shopCampaigning_todate = data.shopCampaigning_todate;
        var shopEnroll_status = data.shopEnroll_status;

        try {

            let [rows, fields] = await db.execute("select * from loyalty_campaigning_shopEnroll where campaigning_id=? and shop_id=?", [campaigning_id, shop_id]);
            if (rows.length >= 1) {
                return { status: false, mass: 'Alredy Added the campaigning for this shop.' }
            } else {
                await db.execute("INSERT INTO loyalty_campaigning_shopEnroll(campaigning_id,shop_id,providing_points,shopCampaigning_fromdate,shopCampaigning_todate,shopEnroll_status) VALUES (?,?,?,?,?,?)", [campaigning_id, shop_id, providing_points, shopCampaigning_fromdate , shopCampaigning_todate , shopEnroll_status]);

                return { status: true, mass: 'Campaigning has been added in this shop.' }
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    ShopEnrollList = async () => {

        try {


            var [rows, fields] = await db.execute("select * from loyalty_campaigning_shopEnroll");


            if (rows.length >= 1) {
                return { status: true, mass: 'All Enrolled Shops. ', data: rows }
            } else {
                return { status: false, mass: 'Enrolled Shop not found.' }
            }

        } catch (error) {
            console.log(error);
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }

    }
    /************************************************************** */

    ShopEnrolls = async (shop_id) => {

        try {

            var [rows, fields] = await db.execute("select * from loyalty_campaigning_shopEnroll join loyalty_campaigning on loyalty_campaigning.campaigning_id = loyalty_campaigning_shopEnroll.campaigning_id where loyalty_campaigning_shopEnroll.shop_id = ?", [shop_id]);


            if (rows.length >= 1) {
                return { status: true, mass: 'All Enrollments of this Shop. ', data: rows }
            } else {
                return { status: false, mass: 'Enrollment not found for this shop.' }
            }

        } catch (error) {
            console.log(error);
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }

    }
    /************************************************************** */
    
    Update_Campaigning_shopEnroll = async (data) => {
        try {
            var providing_points = data.providing_points;
            var shopEnroll_status = data.shopEnroll_status;
            var EnrollID = data.EnrollID;

            var shopCampaigning_fromdate = data.shopCampaigning_fromdate;
            var shopCampaigning_todate = data.shopCampaigning_todate;

            await db.execute('Update loyalty_campaigning_shopEnroll set  providing_points = ? , shopEnroll_status = ? , shopCampaigning_fromdate = ? , shopCampaigning_todate = ? where  EnrollID = ? ', [providing_points, shopEnroll_status, shopCampaigning_fromdate , shopCampaigning_todate , EnrollID]);

            return {
                status: true, mass: 'Shop campaigning Updated successfully.'
            };


        } catch (error) {
            console.log(error);
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

     /************************************************************** */

     Update_campaigning = async (data) => {
        try {
            var campaigning_name = data.campaigning_name;
            var campaigning_status = data.campaigning_status;
            var campaigning_id = data.campaigning_id;

            await db.execute('Update loyalty_campaigning set  campaigning_name = ? , campaigning_status = ? where  campaigning_id = ? ', [campaigning_name, campaigning_status, campaigning_id]);

            return {
                status: true, mass: 'Campaigning Updated successfully.'
            };


        } catch (error) {
            console.log(error);
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    
}