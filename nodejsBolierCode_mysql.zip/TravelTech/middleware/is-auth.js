const jwt = require('jsonwebtoken');
require('dotenv').config();
/** Token creation start */

/*
module.exports  = (req,res,next) =>{
// Payload jo aap token me rakhna chahte ho
const payload = {
  userId: 'Trval Tech',
  Password: "Salim@Tech"
};
// Token generate
var token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });
console.log("JWT Token:", token);
    next();
}
*/

/** Token creation end */

module.exports = (req, res, next) => {
    const authHeader = req.get('Authorization');
    if (!authHeader) {
        return res.status(401).json({ message: 'No token provided' });
    }

    const token = authHeader.split(' ')[1];
    let decodedToken;
    try {
        decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
        return res.status(401).json({ message: 'Invalid token,Create new token again.' });
    }

    req.userId = decodedToken.userId;
    next();
};

