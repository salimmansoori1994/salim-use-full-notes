

const Pointsset = require('../../services/loyaltyPointsServices');

const Points  = new Pointsset();

/************************************************************** */
exports.all_CustomerPoints = async (req, res, next) => {
    let data = await Points.all_CustomerPoints();
    res.status(200).json(data);
}
/************************************************************** */
exports.AddCustomer = async (req, res, next) => {
    let customer_id = req.body.customer_id;
    let available_for = req.body.available_for;
    let customer_shop_id = req.body.customer_shop_id; 
    let POS_customer_loyalty_status = req.body.POS_customer_loyalty_status;

    let data = await Points.AddCustomer(customer_id,customer_shop_id,available_for,POS_customer_loyalty_status);
    res.status(200).json(data);
}
/************************************************************** */
exports.UpdateCustomer = async (req, res, next) => {
    let customer_id = req.body.customer_id;
    let customer_shop_id = req.body.customer_shop_id; 
    let POS_customer_loyalty_status = req.body.POS_customer_loyalty_status;

    let data = await Points.UpdateCustomer(customer_id,POS_customer_loyalty_status,customer_shop_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.DeleteCustomer = async (req, res, next) => {
    let customer_id = req.body.customer_id;
    let customer_shop_id = req.body.customer_shop_id; 

    let data = await Points.DeleteCustomer(customer_id,customer_shop_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.CustomerPointsLogs = async (req, res, next) => {
    var customer_id = req.body.customer_id;

    let data = await Points.CustomerPointsLogs(customer_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.get_CustomerPoints = async (req, res, next) => {
    var customer_id = req.body.customer_id;
    
    let data = await Points.get_CustomerPoints(customer_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.SubtractPoints = async (req, res, next) => {
    var customer_id = req.body.customer_id;
    var reduce_points = req.body.reduce_points;
    var customer_shop_id = req.body.customer_shop_id;
    let POS_order_id = req.body.POS_order_id;
  

    let data = await Points.SubtractPoints(customer_id,reduce_points,customer_shop_id,POS_order_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.AddPoints = async (req, res, next) => {
    let customer_id = req.body.customer_id;
    let points = req.body.points;
    let available_for = req.body.available_for;
    let customer_shop_id = req.body.customer_shop_id;
    let POS_order_id = req.body.POS_order_id; 
    var POS_customer_loyalty_status=false;
    if(req.body.POS_customer_loyalty_status){
        POS_customer_loyalty_status=req.body.POS_customer_loyalty_status;
    }

    let data = await Points.AddPoints(customer_id,points,available_for,customer_shop_id,POS_order_id,POS_customer_loyalty_status);
    res.status(200).json(data);
}

/************************************************************** */
exports.AddCustomer_Pos_Loyalty = async (req, res, next) =>{

    let data = await Points.AddCustomer_Pos_Loyalty(req.body);
    res.status(200).json(data);

}

/************************************************************** */
exports.CustomerListByShop = async (req,res,next) =>{
    let customer_shop_id = req.body.customer_shop_id;

    let data = await Points.CustomerListByShop(customer_shop_id);
    res.status(200).json(data);
}
 