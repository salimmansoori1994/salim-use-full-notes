// const fetch = require("node-fetch"); // npm install node-fetch
const util = require("util");
const db = require('../../util/database');
const { Loyalty_verification_baseurl } = require('../../util/constants');
const { POS_API, POS_Authorization } = require('../../util/constants');
const axios = require('axios');
// import { get_shop_details_pos } from '../services/loyaltyPointsServices'; 
/************************************************************** */
exports.trigger_sms = async (req, res, next) => {
  try {


    let [rows, fields] = await db.execute("select * from customer_point where  `POS_customer_loyalty_status` = 'Requested' ");

    if (rows.length >= 1) {
      for (const value of rows.values()) {


        // var customer_id = '2081';
        var customer_id = value.customer_id;

        var shop_id = value.customer_shop_id;

        var get_shop_details_pos = await this.get_customer_details_pos(customer_id, shop_id);
        // console.log('ssss',get_shop_details_pos);

        if (get_shop_details_pos.status == 'success') {

          var phon = get_shop_details_pos.data.phone;
          if (phon) {
            var msg = "Dear Customer, Please find the link for the Accept the Loyalty System. " + Loyalty_verification_baseurl + "?cp=" + btoa(customer_id) + "&sh=" + btoa(shop_id) + "";

            var responce = await sendSMS(phon, msg);

            // console.log(responce);

            await db.execute("INSERT INTO trigger_sms_logs(sms_link,customer_id,phone,status,resons,channel) VALUES (?,?,?,?,?,?)", [msg, customer_id, phon, 'sent', responce, 'Loyalty verification']);

          } else {
            // console.log('phon not found.');
            await db.execute("INSERT INTO trigger_sms_logs(sms_link,customer_id,phone,status,resons,channel) VALUES (?,?,?,?,?,?)", ['', customer_id, phon, 'fail', 'phon not found.', 'Loyalty verification']);
          }
        } else {
          // console.log('USer not found.');
          await db.execute("INSERT INTO trigger_sms_logs(sms_link,customer_id,phone,status,resons,channel) VALUES (?,?,?,?,?,?)", ['', customer_id,'', 'fail', 'USer not found.', 'Loyalty verification']);
        }
      }

      res.status(200).json({ 'status': 'ok' });

    }

  } catch (error) {
    res.status(200).json({ 'status': 'false', data:error });
  }
}


/************************************************************** */
exports.get_customer_details_pos = async (customer_id, shop_id) => {


  try {

    const { data: res } = await axios.get(`${POS_API}/rest-api/users/${customer_id}`, {
      headers: { 'shop_id': shop_id, Authorization: `${POS_Authorization}` },
    });
    return res;

  } catch (error) {
    return {
      status: false,
      mass: 'error',
      data: error
    }
  }
}

/************************************************************** */
async function sendSMS(customer_number, msg) {

  const payload = {
    sender: "ExampleSMS",
    message: msg,
  //  message: "Hello World Salim mansoori testing for loyalty accept reminder.",
    recipients: [
      { msisdn: +4793487101 },
      // { msisdn: customer_number },
    ],
  };

  const apiToken = "qSTMaGKBSPOsf3XuI3DePemFqqzoasSknC3Iv3xPJu_GjP4s4f34hYavcHvs8OBk";
  const encodedAuth = Buffer.from(`${apiToken}:`).toString("base64");

  const resp = await fetch("https://gatewayapi.com/rest/mtsms", {
    method: "post",
    body: JSON.stringify(payload),
    headers: {
      Authorization: `Basic ${encodedAuth}`,
      "Content-Type": "application/json",
    },
  });

  const json = await resp.json();

  console.log(util.inspect(json, { showHidden: false, depth: null }));

  if (resp.ok) {
    return "congrats! messages are on their way!";
    // console.log("congrats! messages are on their way!");
  } else {
    return "oh-no! something went wrong...";
    // console.log("oh-no! something went wrong...");
  }
}
/************************************************************** */

async function sendSMS_testing() {
  const payload = {
    sender: "ExampleSMS",
    message: "Hello World Salim mansoori testing for loyalty accept reminder.",
    recipients: [
      { msisdn: +4793487101 },
      // { msisdn: +917828278779 },
    ],
  };

  const apiToken = "qSTMaGKBSPOsf3XuI3DePemFqqzoasSknC3Iv3xPJu_GjP4s4f34hYavcHvs8OBk";
  const encodedAuth = Buffer.from(`${apiToken}:`).toString("base64");

  const resp = await fetch("https://gatewayapi.com/rest/mtsms", {
    method: "post",
    body: JSON.stringify(payload),
    headers: {
      Authorization: `Basic ${encodedAuth}`,
      "Content-Type": "application/json",
    },
  });
  const json = await resp.json()
  console.log(util.inspect(json, { showHidden: false, depth: null }));
  if (resp.ok) {
    console.log("congrats! messages are on their way!");
  } else {
    console.log("oh-no! something went wrong...");
  }
}