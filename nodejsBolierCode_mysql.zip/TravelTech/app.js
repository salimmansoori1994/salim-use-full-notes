require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');


const Logins = require("./routes/Logins");

const multer  = require('multer');
const logger = require('./util/logger');
const app = express();

const fileStorage = multer.diskStorage({
        destination : (req,file,cb) =>{
                cb(null,'images');
        },
        filename:(req,file,cb)=>{
                cb(null,new Date().toISOString() + '-' + file.originalname );
        }
});

const fileFilter = (req,file,cb) =>{
        if( 
                file.mimetype === 'image/png' ||
                file.mimetype === 'image/jpg' ||
                file.mimetype === 'image/jpeg'
         ){
                cb(null,true);
         }else{
                cb(null,false);
         }
};

// app.use(bodyParser.urlencoded()); //x-www-form-urlencoded
app.use(bodyParser.json()); //json/type

app.use((req, res, next) => {
        logger.info(`Request Method: ${req.method}, Request URL: ${req.url}`);
        next();
      });


app.use(
        multer({ storage : fileStorage , fileFilter : fileFilter  }).single('image_selected')
);
app.use('/images',express.static(path.join(__dirname,'images')));   

app.use((req , res , next)=>{
        res.setHeader('Access-Control-Allow-Origin','*');
        res.setHeader('Access-Control-Allow-Methods','GET,PUT,POST,PATCH,DELETE');
        res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');
        next();
}) 

//localhost
app.use('/TravelTech/',Logins);

app.use((err, req, res, next) => {
        logger.error(err.message);
        res.status(500).send('Something broke!');
      });


const PORT = process.env.PORT || 0;
if (PORT === 0) {
    const server = app.listen(() => {
        const actualPort = server.address().port;
        console.log(`Server running on random port ${actualPort}`);
          logger.info(`Server running on random port ${actualPort}`);
    });
} else {
    app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
              logger.info(`Server running on port ${PORT}`);
    });
} 

