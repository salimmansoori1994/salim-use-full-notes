-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 10, 2024 at 11:28 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salim_qrordr_loyalty_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_point`
--

CREATE TABLE `customer_point` (
  `point_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `available_points` float NOT NULL,
  `available_for` varchar(255) NOT NULL COMMENT 'channel',
  `customer_shop_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `POS_customer_loyalty_status` varchar(255) NOT NULL DEFAULT 'Requested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_point`
--

INSERT INTO `customer_point` (`point_id`, `customer_id`, `available_points`, `available_for`, `customer_shop_id`, `create_date`, `POS_customer_loyalty_status`) VALUES
(1, 24103, 300, 'POS', 42, '2024-01-10 10:11:54', 'Signed'),
(2, 24102, 300, 'POS', 42, '2024-01-10 10:26:07', 'Signed');

-- --------------------------------------------------------

--
-- Table structure for table `loyalty_campaigning`
--

CREATE TABLE `loyalty_campaigning` (
  `campaigning_id` int(10) NOT NULL,
  `campaigning_name` varchar(255) NOT NULL,
  `campaigning_status` enum('active','inactive') NOT NULL,
  `campaigning_creation_data` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loyalty_campaigning`
--

INSERT INTO `loyalty_campaigning` (`campaigning_id`, `campaigning_name`, `campaigning_status`, `campaigning_creation_data`) VALUES
(1, 'Joining Points Bouns', 'active', '2024-01-03 12:43:32');

-- --------------------------------------------------------

--
-- Table structure for table `loyalty_campaigning_shopEnroll`
--

CREATE TABLE `loyalty_campaigning_shopEnroll` (
  `EnrollID` int(10) NOT NULL,
  `campaigning_id` int(10) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `providing_points` varchar(255) NOT NULL,
  `shopCampaigning_fromdate` varchar(255) NOT NULL,
  `shopCampaigning_todate` varchar(255) NOT NULL,
  `shopEnroll_status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `shopEnroll_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loyalty_campaigning_shopEnroll`
--

INSERT INTO `loyalty_campaigning_shopEnroll` (`EnrollID`, `campaigning_id`, `shop_id`, `providing_points`, `shopCampaigning_fromdate`, `shopCampaigning_todate`, `shopEnroll_status`, `shopEnroll_date`) VALUES
(1, 1, 42, '300', '2024-01-01', '2024-01-10', 'active', '2024-01-03 15:02:18');

-- --------------------------------------------------------

--
-- Table structure for table `point_logs`
--

CREATE TABLE `point_logs` (
  `point_logs_id` int(10) NOT NULL,
  `used_points` varchar(255) NOT NULL,
  `action_type` enum('add','sub') NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `userfor` varchar(255) NOT NULL COMMENT 'channel',
  `customer_id` int(10) NOT NULL,
  `POS_order_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `point_logs`
--

INSERT INTO `point_logs` (`point_logs_id`, `used_points`, `action_type`, `timestamp`, `userfor`, `customer_id`, `POS_order_id`) VALUES
(1, '300', 'add', '2024-01-10 15:41:54', 'Joining Points', 24103, ''),
(2, '300', 'add', '2024-01-10 15:56:07', 'Joining Points', 24102, '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_loyaltycategories`
--

CREATE TABLE `shop_loyaltycategories` (
  `category_id` int(10) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL,
  `poiting_level` varchar(255) NOT NULL,
  `discount_points` varchar(255) NOT NULL,
  `category_disctription` text NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT current_timestamp(),
  `shop_id` int(10) NOT NULL,
  `userfor` varchar(255) NOT NULL COMMENT 'channel'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shop_loyaltycategories`
--

INSERT INTO `shop_loyaltycategories` (`category_id`, `category_name`, `category_image`, `poiting_level`, `discount_points`, `category_disctription`, `creation_date`, `shop_id`, `userfor`) VALUES
(18, 'Silver level', 'images/2023-11-02T05:00:06.841Z-15603576.jpg', '400', '100', 'this is the Silver card for user', '2023-11-02 06:00:06', 42, 'POS'),
(20, 'Platinum level', 'images/2023-11-06T05:34:15.741Z-2023-11-02T04_53_27.622Z-SFCU_Platinum-Cash-Rewards-Credit-Card_800x500.png', '800', '200', 'this is the Platinum car for user', '2023-11-06 06:34:15', 42, 'POS'),
(23, 'Basic', 'images/2023-11-09T07:39:29.383Z-1.png', '1', '100', 'Basic entry level loyalty ', '2023-11-09 08:39:33', 42, 'POS');

-- --------------------------------------------------------

--
-- Table structure for table `trigger_sms_logs`
--

CREATE TABLE `trigger_sms_logs` (
  `id` int(10) NOT NULL,
  `sms_link` varchar(255) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `resons` varchar(255) NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp(),
  `channel` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trigger_sms_logs`
--

INSERT INTO `trigger_sms_logs` (`id`, `sms_link`, `customer_id`, `phone`, `status`, `resons`, `update_date`, `channel`) VALUES
(7, 'Dear Customer, Please find the link for the Accept the Loyalty System. https://qrordr.com/loyaltyVerification/?cp=MjA4MQ==&sh=NDI=', 2005, '2121211', 'sent', 'congrats! messages are on their way!', '2023-12-19 13:36:06', 'Loyalty verification'),
(8, 'Dear Customer, Please find the link for the Accept the Loyalty System. https://qrordr.com/loyaltyVerification/?cp=MjA4MQ==&sh=NDI=', 2081, '2121211', 'sent', 'congrats! messages are on their way!', '2023-12-19 13:44:48', 'Loyalty verification'),
(9, '', 2005, '', 'fail', 'USer not found.', '2023-12-19 13:50:23', 'Loyalty verification');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_point`
--
ALTER TABLE `customer_point`
  ADD PRIMARY KEY (`point_id`);

--
-- Indexes for table `loyalty_campaigning`
--
ALTER TABLE `loyalty_campaigning`
  ADD PRIMARY KEY (`campaigning_id`);

--
-- Indexes for table `loyalty_campaigning_shopEnroll`
--
ALTER TABLE `loyalty_campaigning_shopEnroll`
  ADD PRIMARY KEY (`EnrollID`);

--
-- Indexes for table `point_logs`
--
ALTER TABLE `point_logs`
  ADD PRIMARY KEY (`point_logs_id`);

--
-- Indexes for table `shop_loyaltycategories`
--
ALTER TABLE `shop_loyaltycategories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `trigger_sms_logs`
--
ALTER TABLE `trigger_sms_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_point`
--
ALTER TABLE `customer_point`
  MODIFY `point_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `loyalty_campaigning`
--
ALTER TABLE `loyalty_campaigning`
  MODIFY `campaigning_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loyalty_campaigning_shopEnroll`
--
ALTER TABLE `loyalty_campaigning_shopEnroll`
  MODIFY `EnrollID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `point_logs`
--
ALTER TABLE `point_logs`
  MODIFY `point_logs_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shop_loyaltycategories`
--
ALTER TABLE `shop_loyaltycategories`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `trigger_sms_logs`
--
ALTER TABLE `trigger_sms_logs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
