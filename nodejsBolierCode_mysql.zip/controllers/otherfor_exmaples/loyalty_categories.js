
const CategoriesSet = require('../../services/loyaltyCategoriesServices');

const Categories  = new CategoriesSet();

/************************************************************** */
exports.Add_loyalty_ShopCategories = async (req, res, next) => {
    try {

        if (!req.file) {
            const error = new Error('Validation failed ,  Enterd data is incorrect.');
            error.statusCode = 422;
            throw error;   
        }

        const imageUrl = req.file.path;

        let data = await Categories.Add_loyalty_ShopCategories(imageUrl,req.body);
        res.status(200).json(data);
        
    } catch (error) {
        console.log(error);
        res.status(400).json({
            status: false,
            mass: 'error ok',
            data: error
        });
    }
}
/************************************************************** */
exports.Get_loyalty_ShopCategories = async (req,res,next)=>{
        var shop_id = req.body.shop_id;
        var userfor = req.body.userfor;
        let data = await Categories.Get_loyalty_ShopCategories(shop_id,userfor);
        res.status(200).json(data);
}
/************************************************************** */
exports.Update_loyalty_ShopCategories = async (req,res,next) =>{

    var imageUrl = '';

    if (req.file) {
         imageUrl = req.file.path; 
    }

    var cat_id = req.params.cid;


    let data = await Categories.Update_loyalty_ShopCategories(imageUrl,cat_id,req.body);
        res.status(200).json(data);
}
/************************************************************** */
exports.Delete_loyalty_ShopCategories = async (req,res,next) =>{
    var cat_id = req.params.cid;
    let data = await Categories.Delete_loyalty_ShopCategories(cat_id);
    res.status(200).json(data);
}
/************************************************************** */
exports.Get_loyalty_ShopCategoriesDetails = async(req,res,next) =>{
    var cat_id = req.params.cid;
    let data = await Categories.Get_loyalty_ShopCategoriesDetails(cat_id);
    res.status(200).json(data);
}
