const express  = require('express');

const Login = require('../controllers/LoginPannelController');

const isAuth = require('../middleware/is-auth');
const router = express.Router();

router.post('/LoginPannels',isAuth,Login.LoginPannels);

module.exports = router;  