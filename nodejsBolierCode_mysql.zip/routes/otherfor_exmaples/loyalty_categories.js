const express = require('express');

const loyalty_ShopCategories = require('../controllers/loyalty_categories');

const isAuth = require('../middleware/pos-auth');

const router = express.Router();

//doamin/loyalty_system/----

router.post('/Add_loyalty_ShopCategories',isAuth,loyalty_ShopCategories.Add_loyalty_ShopCategories); 

router.post('/Get_loyalty_ShopCategories',isAuth,loyalty_ShopCategories.Get_loyalty_ShopCategories); 

router.get('/Get_loyalty_ShopCategoriesDetails/:cid',isAuth,loyalty_ShopCategories.Get_loyalty_ShopCategoriesDetails); 

router.put('/Update_loyalty_ShopCategories/:cid',isAuth,loyalty_ShopCategories.Update_loyalty_ShopCategories); 

router.delete('/Delete_loyalty_ShopCategories/:cid',isAuth,loyalty_ShopCategories.Delete_loyalty_ShopCategories); 


module.exports = router;