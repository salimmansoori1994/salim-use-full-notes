const express = require('express');

const loyalty_campaigning = require('../controllers/loyalty_campaigning');
const isAuth = require('../middleware/pos-auth');
const router = express.Router();

//doamin/loyalty_system/----
router.get('/All_campaigning_list', isAuth, loyalty_campaigning.All_campaigning_list);

router.post('/Update_campaigning', isAuth, loyalty_campaigning.Update_campaigning);

router.post('/Campaigning_shopEnroll', isAuth, loyalty_campaigning.Campaigning_shopEnroll);

router.post('/Update_Campaigning_shopEnroll', isAuth, loyalty_campaigning.Update_Campaigning_shopEnroll);

router.get('/ShopEnrollList', isAuth, loyalty_campaigning.ShopEnrollList);

router.get('/ShopEnrolls/:sid', isAuth, loyalty_campaigning.ShopEnrolls);

module.exports = router;