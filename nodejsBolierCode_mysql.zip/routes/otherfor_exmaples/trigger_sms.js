const express = require('express');

const loyalty_trigger_sms = require('../controllers/trigger_sms');

const isAuth = require('../middleware/pos-auth');
const router = express.Router();

// router.get('/trigger_sms',isAuth,loyalty_trigger_sms.trigger_sms);
router.get('/trigger_sms',loyalty_trigger_sms.trigger_sms);


module.exports = router;