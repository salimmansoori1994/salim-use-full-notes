const db = require('../util/database');
const axios = require('axios');
const { POS_API, POS_Authorization } = require('../util/constants');



module.exports = class Points {

    /************************************************************** */
    all_CustomerPoints = async () => {
        try {

            let [rows, fields] = await db.execute("select * from customer_point");

            return {
                status: true, mass: 'All Customers Points', data: rows
            };

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }
    /************************************************************** */

    CustomerPointsLogs = async (customer_id) => {
        try {

            let [rows, fields] = await db.execute("select * from point_logs where customer_id = ?", [customer_id]);
            return {
                status: true, mass: 'Points logs', data: rows
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }


    /************************************************************** */
    get_CustomerPoints = async (customer_id) => {
        try {
            var get_user = await this.get_user_details(customer_id);
            if (get_user.status) {

                var shop_details = await this.get_shop_details_pos(get_user.data.customer_shop_id);

                if (shop_details) {

                    var accept_reward = shop_details.data.accept_reward;


                    var ret = accept_reward.split("/");
                    var bu_ret_amount = ret[0];
                    var bu_ret_point = ret[1];

                    var bu_reatio_point = bu_ret_amount / bu_ret_point;

                    var available_points_amount = bu_reatio_point * get_user.data.available_points;

                    get_user.data.available_amount = available_points_amount;

                    return {
                        status: true, mass: 'Customer Details Get', data: get_user.data
                    };

                }

            } else {

                return {
                    status: false, mass: 'Customer not Availble'
                };
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }
    /************************************************************** */

    SubtractPoints = async (customer_id, reduce_points, customer_shop_id, POS_order_id) => {
        try {
            var get_user = await this.get_user_details(customer_id);
            if (get_user.status) {

                var available_points = get_user.data.available_points;

                if (available_points >= reduce_points) {
                    var available_points_set = parseInt(available_points) - reduce_points;
                    var set = await db.execute('Update customer_point set  available_points = ? where customer_id = ? and customer_shop_id = ? ', [available_points_set, customer_id, customer_shop_id]);

                    this.update_point_logs(reduce_points, 'sub', 'POS Order Payment', customer_id, POS_order_id);
                    return {
                        status: true, mass: 'Points Subtract has been done.'
                    };

                } else {
                    return {
                        status: false, mass: 'Points are not sufficient.'
                    };
                }

            } else {
                return {
                    status: false, mass: 'Customer not Availble'
                };
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    AddPoints = async (customer_id, points, available_for, customer_shop_id, POS_order_id, POS_customer_loyalty_status) => {
        try {

            let [rows, fields] = await db.execute("select * from customer_point where customer_id = ?  and customer_shop_id = ?", [customer_id, customer_shop_id]);

            if (rows.length >= 1) {
                //   console.log(POS_customer_loyalty_status);
                // console.log('add point true');

                if (rows[0].POS_customer_loyalty_status == 'Signed' || POS_customer_loyalty_status) {
                    var available_points = parseInt(rows[0].available_points) + parseInt(points);
                    await db.execute('Update customer_point set  available_points = ?  where customer_id = ? and customer_shop_id = ? ', [available_points,customer_id, customer_shop_id]);
                } else { 
                    return {
                        status: true, mass: 'The Customer is not Signed Status. Point not added'
                    };
                }

                this.update_point_logs(points, 'add', available_for, customer_id, POS_order_id);

                return {
                    status: true, mass: 'The Points has been Added successfully .'
                };

            } else if (POS_customer_loyalty_status) {

                await db.execute("INSERT INTO customer_point(customer_id,available_points,available_for,customer_shop_id,POS_customer_loyalty_status) VALUES (?,?,?,?,?)", [customer_id, points, available_for, customer_shop_id, 'Signed']);

                this.update_point_logs(points, 'add', available_for, customer_id, POS_order_id);

                let JoiningPointProvider_campaigning_set = await this.JoiningPointProvider_campaigning(customer_id, customer_shop_id);

                return {
                    status: true, mass: 'The Points has been Added successfully.'
                };

            }


            return {
                status: false, mass: 'The Points not Added'
            };



        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    CustomerListByShop = async (customer_shop_id) => {
        try {
            let [rows, fields] = await db.execute("select * from customer_point where customer_shop_id = ?", [customer_shop_id]);
            if (rows.length >= 1) {
                return {
                    status: true, mass: 'Customer & Point list.', data: rows
                };
            } else {
                return {
                    status: false, mass: 'Not Avialble any Customer for this shop.'
                };
            }
        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    get_user_details = async (customer_id) => {
        let [rows, fields] = await db.execute("select * from customer_point where customer_id = ?", [customer_id]);
        if (rows.length >= 1) {
            return {
                status: true,
                data: rows[0]
            }
        } else {
            return {
                status: false,
            }
        }
    }

    /************************************************************** */
    update_point_logs = (used_points, action_type, userfor, customer_id, POS_order_id) => {
        db.execute("INSERT INTO point_logs(used_points,action_type,userfor,customer_id,POS_order_id) VALUES (?,?,?,?,?)", [used_points, action_type, userfor, customer_id, POS_order_id]);
    }

    /************************************************************** */


    AddCustomer = async (customer_id, customer_shop_id, available_for, POS_customer_loyalty_status) => {
        try {

            console.log('POS_customer_loyalty_status',POS_customer_loyalty_status);
            let [rows, fields] = await db.execute("select * from customer_point where customer_id = ?  and customer_shop_id = ?", [customer_id, customer_shop_id]);

            if (rows.length >= 1) {

                if (POS_customer_loyalty_status == 'Signed') {
                    await db.execute('Update customer_point set  POS_customer_loyalty_status = ? where customer_id = ? and customer_shop_id = ? ', [POS_customer_loyalty_status, customer_id, customer_shop_id]);
                }

                return {
                    status: true, mass: 'The Customer ID Alredy Available.', data: rows
                };

            } else {

                await db.execute("INSERT INTO customer_point(customer_id,available_points,available_for,customer_shop_id,POS_customer_loyalty_status) VALUES (?,?,?,?,?)", [customer_id, '0', available_for, customer_shop_id, POS_customer_loyalty_status]);

                let JoiningPointProvider_campaigning_set = await this.JoiningPointProvider_campaigning(customer_id, customer_shop_id);

                return {
                    status: true, mass: 'The Customer  has been Added successfully.', data: [{ 'customer_id': customer_id }]
                };

            }
        } catch (error) {
            return {
                status: false,
                mass: 'error AddCustomer',
                data: error
            }
        }
    }


    /************************************************************** */

    UpdateCustomer = async (customer_id, POS_customer_loyalty_status, customer_shop_id) => {
        try {

            let [rows, fields] = await db.execute("select * from customer_point where customer_id = ?  and customer_shop_id = ?", [customer_id, customer_shop_id]);

            if (rows.length >= 1) {
                await db.execute('Update customer_point set  POS_customer_loyalty_status = ? where customer_id = ? and customer_shop_id = ? ', [POS_customer_loyalty_status, customer_id, customer_shop_id]);
            } else {

                return {
                    status: true, mass: 'The customer ID not Available.'
                };

            }

            return {
                status: true, mass: 'The customer ID status has been Updated successfully.'
            };


        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */
    DeleteCustomer = async (customer_id, customer_shop_id) => {
        try {

            let [rows, fields] = await db.execute("select * from customer_point where customer_id = ?  and customer_shop_id = ?", [customer_id, customer_shop_id]);

            if (rows.length >= 1) {
                await db.execute('DELETE FROM customer_point where customer_id = ? and customer_shop_id = ?', [customer_id, customer_shop_id]);
                await db.execute('DELETE FROM point_logs where customer_id = ?', [customer_id]);
            } else {

                return {
                    status: true, mass: 'The customer ID not Available.'
                };

            }

            return {
                status: true, mass: 'The customer Delete and Points has been successfully.'
            };


        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    AddCustomer_Pos_Loyalty = async (data_res) => {

        var find_POS_customer = await this.find_POS_customer(data_res);

        // console.log('salim ok ', find_POS_customer.customer_id);


        var create = await this.AddCustomer(find_POS_customer.customer_id, data_res.shop_id, "POS And Loyalty Customer creation", 'Signed');


        if (create) {
            return create;
        }

    }

    /************************************************************** */

    get_shop_details_pos = async (shop_id) => {

        try {

            const { data: res } = await axios.get(`${POS_API}/rest-api/shop/${shop_id}`, {
                headers: { 'shop_id': shop_id, Authorization: `${POS_Authorization}` },
            });
            return res;

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }

    /************************************************************** */

    find_POS_customer = async (data_res) => {

        try {

            let data = data_res
            let shop_id = data_res.shop_id;

            // console.log('salom amsnoori');

            let config = {
                method: 'post',
                maxBodyLength: Infinity,
                url: POS_API + '/rest-api/users',
                headers: {
                    'shop_id': shop_id,
                    'Authorization': POS_Authorization,
                    'Content-Type': 'application/json'
                },
                data: data
            };

            let re_data = await axios.request(config);
            if (re_data) {
                // console.log('salimss', re_data.data.data.user_id);
                return {
                    customer_id: re_data.data.data.user_id
                };
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }


    /******************************  campaigning  * ******************************* */

    JoiningPointProvider_campaigning = async (customer_id, customer_shop_id) => {
        try {
            let [Check_campaigning, fields] = await db.execute("select campaigning_id from loyalty_campaigning where campaigning_id = ?  and campaigning_status = ?", ["1", "active"]);

            if (Check_campaigning.length >= 1) {

                let [CampaigningPoint, fields] = await db.execute("select providing_points,shopCampaigning_fromdate,shopCampaigning_todate from loyalty_campaigning_shopEnroll where shop_id = ?  and campaigning_id = ? and shopEnroll_status = ?", [customer_shop_id, Check_campaigning[0].campaigning_id, 'active']);

                if (CampaigningPoint.length >= 1) {

                    //check the data
                    let today_date = new Date().toISOString().slice(0, 10);
                    // console.log(today_date);
                    // console.log(CampaigningPoint[0].shopCampaigning_fromdate);
                    // console.log(CampaigningPoint[0].shopCampaigning_todate);

                    if (today_date >= CampaigningPoint[0].shopCampaigning_fromdate && today_date <= CampaigningPoint[0].shopCampaigning_todate) {
                        this.AddPoints(customer_id, CampaigningPoint[0].providing_points, "Joining Points", customer_shop_id, "", true);
                    } else {
                        //  return { status: false, mass: 'Dates not match beetween.' };
                    }

                } else {

                    // return { status: false, mass: 'loyalty campaigning enrollment of shop  is not active.' };
                }

            } else {
                // return { status: false, mass: 'loyalty campaigning of Joining Points is not active.' };
            }

        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            }
        }
    }


}