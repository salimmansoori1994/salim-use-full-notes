const db = require('../util/database');
const bcrypt = require('bcryptjs');

module.exports = class LoginPannel {

     
 UserLogin = async (reqData) => {
        try {
            const { username, password } = reqData;

             // this.creatPassword(password);
            // Find user by username
            let [rows] = await db.execute("SELECT id,username,role,passwords FROM loginusers WHERE username = ?", [username]);
            if (rows.length === 0) {
                return { status: false, mass: 'Login failed' };
            }
            
            const storedHash = rows[0].passwords; // hashed password from DB
            delete rows[0].passwords;
            // Compare password with hash
            const isMatch = await bcrypt.compare(password, storedHash);
            if (!isMatch) {
                return { status: false, mass: 'Invalid credentials' };
            }

            return { status: true, mass: 'Login Successfully', data: rows };
        } catch (error) {
            return {
                status: false,
                mass: 'error',
                data: error
            };
        }
    }


    creatPassword = async (plainPassword) =>{
     const hashedPassword = await bcrypt.hash(plainPassword, 10); // 10 = salt rounds
       console.log("User registered with hashed password",hashedPassword);
    } 

}