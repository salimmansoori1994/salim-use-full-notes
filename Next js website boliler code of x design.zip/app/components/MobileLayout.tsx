'use client';

import React, { useState } from 'react';
import { 
  Home, 
  Search, 
  Bell, 
  Mail, 
  User,
  X,
  MessageCircle, 
  List, 
  Bookmark, 
  Users, 
  DollarSign, 
  Zap, // Business
  Settings,
  MoreHorizontal
} from 'lucide-react';

// =========================================================
// 1. Mobile Drawer Menu (Based on image_ad279f.png)
// =========================================================

const MobileDrawer = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
    // Drawer Menu Items
    const menuItems = [
        { icon: MessageCircle, text: 'Chat', beta: true },
        { icon: User, text: 'Profile' },
        { icon: X, text: 'Premium' },
        { icon: Users, text: 'Communities' },
        { icon: List, text: 'Lists' },
        { icon: Bookmark, text: 'Bookmarks' },
        { icon: Zap, text: 'Business' },
        { icon: DollarSign, text: 'Monetization' },
        { icon: Settings, text: 'Settings and privacy' },
    ];

    const MenuItem = ({ icon: Icon, text, beta }: { icon: React.ElementType, text: string, beta?: boolean }) => (
        <a 
            href="#" 
            className="flex items-center space-x-4 p-3 hover:bg-gray-100 transition duration-200 cursor-pointer text-base rounded-md"
            onClick={onClose}
        >
            <Icon size={24} className="text-gray-900" />
            <span className="font-semibold text-lg">{text}</span>
            {beta && (
                <span className="ml-auto text-blue-500 font-bold text-xs bg-blue-100 rounded-lg px-2 py-0.5">Beta</span>
            )}
        </a>
    );

    return (
        <>
            {/* Backdrop: Menu open होने पर बाकी स्क्रीन को डार्क करता है */}
            {isOpen && (
                <div 
                    className="fixed inset-0 bg-black bg-opacity-40 z-40 lg:hidden" 
                    onClick={onClose}
                ></div>
            )}

            {/* Actual Drawer Menu */}
            <div
                className={`fixed top-0 left-0 h-full w-3/4 max-w-xs bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out lg:hidden
                    ${isOpen ? 'translate-x-0' : '-translate-x-full'}`
                }
            >
                <div className="p-4 border-b border-gray-200">
                    {/* Top Section: Profile Info (image_ad279f.png) */}
                    <div className="flex items-center justify-between">
                        <div className="w-12 h-12 bg-yellow-600 rounded-full flex-shrink-0" onClick={onClose}></div>
                        <div className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-full border border-gray-300">
                             <MoreHorizontal size={20} />
                        </div>
                    </div>
                    <div className="mt-3 leading-tight">
                        <div className="font-bold text-xl">salim</div>
                        <div className="text-gray-500 text-sm">@salimmansoori94</div>
                    </div>
                    <div className="flex space-x-4 mt-2 text-sm">
                        <span className="text-gray-500">
                            <span className="font-bold text-black">7</span> Following
                        </span>
                        <span className="text-gray-500">
                            <span className="font-bold text-black">2</span> Followers
                        </span>
                    </div>
                </div>
                
                {/* Menu Items */}
                <div className="p-2 space-y-1">
                    {menuItems.map((item, index) => (
                        <MenuItem key={index} {...item} />
                    ))}
                </div>
            </div>
        </>
    );
};

// =========================================================
// 2. Mobile Header (Top)
// =========================================================

const MobileHeader = ({ onProfileClick }: { onProfileClick: () => void }) => (
    <div className="sticky top-0 bg-white border-b border-gray-200 p-2 z-20 flex justify-between items-center lg:hidden">
        {/* Profile Avatar (Clickable to open Drawer) */}
        <div className="w-10 h-10 bg-yellow-600 rounded-full" onClick={onProfileClick}></div>
        
        {/* X Logo in the center */}
        <X size={28} className="text-black" />

        {/* Post Button / Plus Icon */}
        <div className="w-10 h-10 flex items-center justify-center">
            <div className="w-8 h-8 flex items-center justify-center bg-blue-500 text-white rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            </div>
        </div>
    </div>
);

// =========================================================
// 3. Mobile Bottom Navigation (Based on image_ad2817.png)
// =========================================================

const MobileBottomNav = () => {
    const navItems = [
        { icon: Home, active: true },
        { icon: Search, active: false },
        { icon: Bell, active: false },
        { icon: Mail, active: false },
    ];

    return (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30 flex justify-around p-2 lg:hidden">
            {navItems.map((item, index) => {
                const Icon = item.icon;
                return (
                    <a key={index} href="#" className="flex-1 text-center py-1">
                        <Icon size={28} className={item.active ? 'text-black' : 'text-gray-500'} />
                    </a>
                );
            })}
        </div>
    );
};

// =========================================================
// Main Mobile Layout Component
// =========================================================

const MobileLayout = ({ children }: { children: React.ReactNode }) => {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    return (
        <div className="lg:hidden"> {/* Only show this layout on small screens */}
            {/* Top Header */}
            <MobileHeader onProfileClick={() => setIsDrawerOpen(true)} />

            {/* Main Content (Feed) */}
            <div className="pb-16"> {/* Add padding for the bottom nav bar */}
                {children}
            </div>

            {/* Bottom Navigation */}
            <MobileBottomNav />

            {/* Drawer Menu */}
            <MobileDrawer 
                isOpen={isDrawerOpen} 
                onClose={() => setIsDrawerOpen(false)} 
            />
        </div>
    );
};

export default MobileLayout;