'use client';

import React, { useState } from 'react';
import { 
  Home, 
  Search, 
  Bell, 
  Mail, 
  Compass, 
  User, 
  MoreHorizontal, 
  X,
  MessageCircle, // Chat
  List, // Lists
  Bookmark, // Bookmarks
  Users, // Communities
  DollarSign, // Monetization
  Megaphone, // Ads
  Mic, // Create your Space
  Settings // Settings and privacy
} from 'lucide-react';

// =========================================================
// Reusable Components
// =========================================================

// Navigation Item
const NavItem = ({ icon: Icon, text, active }: { icon: React.ElementType, text: string, active?: boolean }) => (
  <a 
    href="#" 
    className={`flex items-center space-x-5 p-3 rounded-full transition duration-200 
    hover:bg-gray-100 ${active ? 'font-bold' : ''}`}
  >
    <Icon size={28} className={active ? 'text-black' : 'text-gray-900'} />
    <span className="hidden xl:inline text-xl">{text}</span>
  </a>
);

// Dropdown Menu Component (Based on image_acb322.png)
const MoreMenu = ({ onClose }: { onClose: () => void }) => {
    // Dropdown Items
    const menuItems = [
        { icon: MessageCircle, text: 'Chat', beta: true },
        { icon: List, text: 'Lists' },
        { icon: X, text: 'Premium' },
        { icon: Bookmark, text: 'Bookmarks' },
        { icon: Users, text: 'Communities' },
        { icon: DollarSign, text: 'Monetization' },
        { icon: Megaphone, text: 'Ads' },
        { icon: Mic, text: 'Create your Space' },
        { icon: Settings, text: 'Settings and privacy' },
    ];

    const MenuItem = ({ icon: Icon, text, beta }: { icon: React.ElementType, text: string, beta?: boolean }) => (
        <a 
            href="#" 
            className="flex items-center space-x-3 p-3 hover:bg-gray-100 transition duration-200 cursor-pointer text-base rounded-md"
            onClick={onClose}
        >
            <Icon size={20} className="text-gray-900" />
            <span className="font-medium">{text}</span>
            {beta && (
                <span className="ml-auto text-blue-500 font-bold text-xs bg-blue-100 rounded-lg px-2 py-0.5">Beta</span>
            )}
        </a>
    );

    return (
        // positioning is relative to the parent LeftSidebar which has 'relative' class
        // On small screen it appears to the right of the icon, on large screen it appears next to the 'More' text
     <div 
            className="absolute z-50 left-20 bottom-[100px] xl:bottom-28 xl:left-5 w-64 bg-white shadow-2xl rounded-2xl p-2 border border-gray-100"
        >
            
            {menuItems.map((item, index) => (
                <MenuItem key={index} {...item} />
            ))}
        </div>
    );
};


// =========================================================
// Left Sidebar Component
// =========================================================

const LeftSidebar = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    // Nav Links
    const navLinks = [
        { icon: X, text: '' }, // Top Left X Logo
        { icon: Home, text: 'Home', active: true },
        { icon: Search, text: 'Explore' },
        { icon: Bell, text: 'Notifications' },
        { icon: Mail, text: 'Messages' },
        { icon: Compass, text: 'Grok' },
        { icon: User, text: 'Profile' },
        { icon: MoreHorizontal, text: 'More', isMenuTrigger: true }, // Menu Trigger
    ];

    return (
        // 'relative' is crucial for positioning the 'MoreMenu' component
        <div className="hidden md:block xl:w-[275px] w-20 px-2 lg:px-4 h-screen sticky top-0 relative"> 
            
            {/* Navigation Links */}
            <div className="flex flex-col items-center xl:items-start pt-2">
                {navLinks.map((link, index) => (
                    <div 
                        key={link.text || index} 
                        className={index === 0 ? 'mb-2' : 'mt-1'}
                        // Toggle menu if 'More' link is clicked
                        onClick={link.isMenuTrigger ? () => setIsMenuOpen(!isMenuOpen) : undefined} 
                    >
                        <NavItem 
                            icon={link.icon} 
                            text={link.text} 
                            active={link.active || (link.isMenuTrigger && isMenuOpen)} 
                        />
                    </div>
                ))}
            </div>

            {/* Post Button */}
            <button className="mt-4 xl:w-11/12 w-14 h-14 xl:h-auto py-3 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-full transition duration-200 flex items-center justify-center">
                <span className="hidden xl:inline text-lg">Post</span>
                <span className="inline xl:hidden text-2xl">
                  {/* Plus Icon */}
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </span>
            </button>
            
            {/* NEW: More Menu Display */}
            {/* The menu is positioned absolutely, so it can overlay other elements */}
            {isMenuOpen && <MoreMenu onClose={() => setIsMenuOpen(false)} />}


            {/* User Info (Bottom) - Clickable to open/close menu */}
            <div 
                className="absolute bottom-4 xl:w-11/12 w-14"
                onClick={() => setIsMenuOpen(!isMenuOpen)} // User info पर क्लिक करने पर भी मेनू खोलें
            >
                <a href="#" className="flex items-center xl:justify-between p-3 rounded-full hover:bg-gray-100 transition duration-200">
                    <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-yellow-600 rounded-full"></div> {/* Avatar Placeholder */}
                        <div className="hidden xl:block leading-tight">
                            <div className="font-bold text-sm">salim</div>
                            <div className="text-gray-500 text-sm">@salimmansoori94</div>
                        </div>
                    </div>
                    <MoreHorizontal className="hidden xl:block text-gray-500" size={20} />
                </a>
            </div>
        </div>
    );
};

export default LeftSidebar;