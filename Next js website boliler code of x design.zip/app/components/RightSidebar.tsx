import React from 'react';
import { Search } from 'lucide-react';

// Trend/News Item Component
const NewsItem = ({ title, category, count }: { title: string, category: string, count: string }) => (
    <a href="#" className="p-3 hover:bg-gray-50 transition duration-200 block">
      <div className="text-xs text-gray-500">{category}</div>
      <div className="font-bold text-sm">{title}</div>
      <div className="text-xs text-gray-500">{count}</div>
    </a>
  );
  
  // Right Sidebar Search/Subscribe Button
  const SidebarButton = ({ text, className = "bg-blue-500 hover:bg-blue-600 text-white" }: { text: string, className?: string }) => (
      <button className={`w-full py-2.5 font-bold rounded-full transition duration-200 text-sm ${className}`}>
          {text}
      </button>
  );

// Right Sidebar Component
const RightSidebar = () => {
    return (
        <div className="hidden lg:block w-[350px] px-6 py-2 h-screen sticky top-0">
            {/* Search Bar (Sticky at Top) */}
            <div className="sticky top-0 py-1 z-10 bg-white">
                <div className="relative">
                    <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                    <input 
                        type="text" 
                        placeholder="Search" 
                        className="w-full pl-10 pr-4 py-2.5 rounded-full bg-gray-100 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white border border-transparent focus:border-blue-500"
                    />
                </div>
            </div>

            <div className="mt-4">
                {/* Subscribe Button */}
                <SidebarButton text="Subscribe" />
            </div>

            {/* Today's News / What's Happening Section */}
            <div className="bg-gray-100 rounded-xl mt-4">
                <h2 className="text-xl font-extrabold p-3 border-b border-gray-200">Today's News</h2>
                
                {/* News Items (Based on your screenshot) */}
                <NewsItem 
                  category="2 days ago · Entertainment · 505.3K posts" 
                  title="BTS's V Makes History as First Invited K-Pop Artist at Vogue World Hollywood" 
                  count=""
                />
                <NewsItem 
                  category="23 hours ago · News · 3,292 posts" 
                  title="Cyclone Month Strengthens in Bay of Bengal, Prompts Evacuations in Andhra..." 
                  count=""
                />
                <NewsItem 
                  category="6,052 posts" 
                  title="Bigg Boss 19 Evicts Baseer Ali and Nehal Chudasama in Double Elimination" 
                  count=""
                />

                <h2 className="text-xl font-extrabold p-3">What's happening</h2>
                <NewsItem 
                  category="Trending in India" 
                  title="Messages" 
                  count=""
                />
            </div>
        </div>
    );
};

export default RightSidebar;