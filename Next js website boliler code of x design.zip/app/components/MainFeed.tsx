
import React from 'react';
import { MessageCircle, Repeat2, Heart, Share2, BarChart3,MoreHorizontal } from 'lucide-react';

// Post/Tweet Card Component
const PostCard = () => (
    <div className="p-3 border-b border-gray-200 hover:bg-gray-50 transition duration-200">
      <div className="flex space-x-3">
        {/* User Avatar */}
        <div className="w-10 h-10 bg-pink-500 rounded-full flex-shrink-0"></div>
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1 leading-tight">
              <span className="font-bold">Science girl</span>
              <span className="text-gray-500">@gunsrosesgirl3 · 2h</span>
            </div>
            <MoreHorizontal size={18} className="text-gray-500 hover:text-blue-500 cursor-pointer" />
          </div>

          <p className="mt-1 text-sm">Street food in Kazakhstan with a surprise inside</p>
          <p className="mt-1 text-sm">Would you eat this</p>
          
          {/* Image/Video Placeholder */}
          <div className="mt-2 rounded-xl overflow-hidden border border-gray-200">
            {/*  */}
            <img src="/images/street-food-placeholder.jpg" alt="Post content" className="w-full h-auto object-cover max-h-96" />
          </div>
          
          {/* Action buttons (Like, Comment, Share) */}
          <div className="flex justify-between mt-3 px-2 text-gray-500">
            <MessageCircle size={18} className="hover:text-blue-500 cursor-pointer" />
            <Repeat2 size={18} className="hover:text-green-500 cursor-pointer" />
            <Heart size={18} className="hover:text-pink-500 cursor-pointer" />
            <Share2 size={18} className="hover:text-blue-500 cursor-pointer" />
            <BarChart3 size={18} className="hover:text-blue-500 cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );

// Main Feed Component
const MainFeed = () => {
    return (
        <main className="flex-1 min-h-screen border-x border-gray-200 max-w-[600px]">
        {/* Sticky Header: Home / For You / Following */}
        <div className="sticky top-0 bg-white/80 backdrop-blur-md z-10 border-b border-gray-200">
            <h1 className="text-xl font-bold p-3 hidden sm:block">Home ok</h1>
            <div className="flex justify-around text-gray-500">
            <div className="flex-1 text-center py-3 cursor-pointer hover:bg-gray-100 relative">
                <span className="font-bold text-black">For you oj</span>
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-14 h-1 bg-blue-500 rounded-full"></div>
            </div>
            <div className="flex-1 text-center py-3 cursor-pointer hover:bg-gray-100">
                <span>Following</span>
            </div>
            </div>
        </div>
        
        {/* Main Feed Content */}
        <PostCard />
        
        </main>
    );
};

export default MainFeed;