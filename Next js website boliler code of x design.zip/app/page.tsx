import LeftSidebar from './components/LeftSidebar';
import MainFeed from './components/MainFeed';
import RightSidebar from './components/RightSidebar';
import MobileLayout from './components/MobileLayout'; // <-- New Import

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-black">
      
      {/* ========================================= */}
      {/* 1. Desktop/Tablet View (3-Column) - Show on lg screens and up */}
      {/* ========================================= */}
      <div className="max-w-7xl mx-auto hidden lg:flex">
        {/* 1. Left Sidebar / Navigation */}
        <LeftSidebar />

        {/* 2. Main Content / Feed */}
        <MainFeed />

        {/* 3. Right Sidebar / Widgets */}
        <RightSidebar />
      </div>

      {/* ========================================= */}
      {/* 2. Mobile View - Hide on lg screens and up */}
      {/* ========================================= */}
      <MobileLayout>
        {/* Main Feed Content Mobile Layout के अंदर जाएगा */}
        <MainFeed />
      </MobileLayout>

    </div>
  );
}