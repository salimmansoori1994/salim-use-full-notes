import './globals.css'; 
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    // 'light' क्लास Tailwind को Light Mode के लिए बाध्य करती है 
    <html lang="en" className="light"> 
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}