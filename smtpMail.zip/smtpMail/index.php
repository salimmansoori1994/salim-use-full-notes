<?php
require('mailer/PHPMailer/PHPMailer.php');

$subject = "Cyber Elite";

$message = "
<html>
<head>
<title>Cyber Elite test salim</title>
</head>
<body>
<p>This email contains from harshainstitutions.com</p>
<table border='1' cellspacing='1' cellpadding='5' width='300' align='center'>
<tr>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Age</th>
<th>DOB</th>
<th>Message</th>
</tr>
</table>
</body>
</html>
";

$mail = new PHPMailer;
//$mail->isSMTP();
$mail->SMTPSecure = "ssl"; 
//$mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) );
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'salimmansoori1994@gmail.com'; 
$mail->Password = 'Mansoori@salim1994';
// $mail->Username = 'info@harshainstitutions.com'; 
// $mail->Password = 'Blr@1234#';
$mail->Port = 465;
//$mail->setFrom('salimmansoori1994@gmail.com', '');
$mail->setFrom('info@harshainstitutions.com', '');

//$mail->addReplyTo('info@harshainstitutions.com', 'harshainstitutions');
$mail->isHTML(true);
$mail->AddAddress('info@harshainstitutions.com'); 
$mail->AddCC('namit@cyberelite.in', 'Person One');
$mail->AddCC('salimmansoori1994@gmail.com', 'Person two'); 
$mail->Subject = $subject; 
$mail->Body = $message;
//$mail->SMTPDebug = 2;

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
    
//    echo  json_encode(array('status'=>1,'mass'=>'The Qurey has been sent.'));

  
?>