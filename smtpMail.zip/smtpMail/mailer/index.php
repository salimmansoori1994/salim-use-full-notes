<?php 

//phpinfo();
//die;
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'PHPMailer/PHPMailer.php';
$mail = new PHPMailer;
// SMTP configuration
$mail->isSMTP();
$mail->Host = '135.53.31.2';
$mail->SMTPAuth = false;
$mail->Username = 'it.office@tatainternational.com';
$mail->Password = 'tata@4321';
//$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->SMTPDebug  = 2;
/*$mail->SMTPOptions = array(
    'tls' => [
        'verify_peer' => true,
        'verify_depth' => 3,
        'allow_self_signed' => true,
        'peer_name' => 'smtp.office365.com',
        'cafile' => '/etc/ssl/ca_cert.pem',
    ],
);*/
$mail->setFrom('it.office@tatainternational.com', 'Tata International');
$mail->addReplyTo('it.office@tatainternational.com', 'Tata International');

// Add a recipient
$mail->addAddress('mansoori.salim1994@gmail.com');

// Add cc or bcc 
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

// Email subject
$mail->Subject = 'Send Email via SMTP using PHPMailer';

// Set email format to HTML
//$mail->isHTML(true);

// Email body content
$mailContent = "<h1>Send HTML Email using SMTP in PHP</h1>
    <p>This is a test email has sent using SMTP mail server with PHPMailer.</p>";
$mail->Body = $mailContent;

// Send email
if(!$//mail->send()){
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}else{
    echo 'Message has been sent';
}
?>