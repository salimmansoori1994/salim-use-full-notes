// Layout.js
import Head from 'next/head';
import Script from 'next/script';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useEffect } from 'react'; // useEffect को इम्पोर्ट करें

const Layout = ({ children, title = 'Finanzi - Finance and Business Finance HTML Template', description = 'Finanzi template exclusively build for finance, accounting, financial and business planning. It is built using bootstrap 3.3.2 framework, works totally responsive, easy to customise, well commented codes and seo friendly.' }) => {
  const router = useRouter();

  useEffect(() => {
    // यह प्रभाव प्रारंभिक रेंडर पर और जब भी router.pathname बदलता है तब चलता है।
    // यह सुनिश्चित करता है कि सभी jQuery-आधारित स्क्रिप्ट नई सामग्री के लिए पुनः आरंभ हों।
    // वैश्विक फ़ंक्शन मौजूद है या नहीं, इसकी जांच करें।
    if (typeof window !== 'undefined' && window.initThemeScripts) {
      // थोड़ा विलंब जोड़ना कभी-कभी आवश्यक हो सकता है
      // ताकि नया DOM सामग्री पूरी तरह से रेंडर हो जाए।
      setTimeout(() => {
        window.initThemeScripts();
      }, 100); // 100ms का विलंब एक अच्छा शुरुआती बिंदु है
    }

    // यदि आप चाहते हैं कि लोडर प्रत्येक रूट परिवर्तन पर फिर से दिखाई दे
    // और फिर गायब हो जाए, तो आप router.events का उपयोग कर सकते हैं।
    // अन्यथा, यदि लोडर केवल प्रारंभिक लोड के लिए है, तो इस हिस्से को छोड़ दें।
    const handleRouteChangeStart = () => {
        if ($(".animationload").length) {
            $(".animationload").show(); // लोडर दिखाएं
        }
    };

    const handleRouteChangeComplete = () => {
        if ($(".animationload").length) {
            $(".animationload").delay(500).fadeOut("slow"); // लोडर छुपाएं
        }
    };

    router.events.on('routeChangeStart', handleRouteChangeStart);
    router.events.on('routeChangeComplete', handleRouteChangeComplete);

    // क्लीनअप फ़ंक्शन
    return () => {
      router.events.off('routeChangeStart', handleRouteChangeStart);
      router.events.off('routeChangeComplete', handleRouteChangeComplete);
    };
  }, [router.pathname, router.events]); // निर्भरता सरणी: जब pathname या router.events बदलता है तो प्रभाव चलाएं

  return (
    <>
      <Head>
        {/* ... (Head सामग्री वही रहती है) ... */}
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" crossOrigin="anonymous" referrerPolicy="no-referrer" />
      </Head>

      {/* LOAD PAGE */}
      <div className="animationload">
        <div className="loader"></div>
      </div>

      {/* BACK TO TOP SECTION */}
      <a href="#0" className="cd-top cd-is-visible cd-fade-out">Top</a>

      {/* HEADER */}
      <div className="header header-1">
        {/* TOPBAR */}
        <div className="topbar">
          <div className="container">
            <div className="row">
              <div className="col-sm-7 col-md-7">
                <div className="info">
                  <div className="info-item">
                    <span className="fa fa-phone"></span> +62 7144 3300
                  </div>
                  <div className="info-item">
                    <span className="fa fa-clock-o"></span> Mon-Sat: 9.00-18.00
                  </div>
                  <div className="info-item">
                    <span className="fa fa-envelope-o"></span> <a href="mailto:info@finanzi.com" title="">info@finanzi.com</a>
                  </div>
                </div>
              </div>
              <div className="col-sm-5 col-md-5">
                <div className="request-quote pull-right">
                  <a href="#" title="">GET A QUOTE</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* NAVBAR SECTION */}
        <div className="navbar navbar-main">
          <div className="container container-nav">
            <div className="row">
              <div className="navbar-header">
                <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span className="icon-bar"></span>
                  <span className="icon-bar"></span>
                  <span className="icon-bar"></span>
                </button>
                <Link href="/" className="navbar-brand" legacyBehavior>
                  <a>
                    <img src="/images/logo.png" alt="" />
                  </a>
                </Link>
              </div>

              <nav className="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations="fadeInDown fadeInRight fadeInUp fadeInLeft">
                <ul className="nav navbar-nav navbar-right">
                  <li className={`dropdown ${router.pathname.startsWith('/home') || router.pathname === '/' ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">HOME <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/' ? 'active' : ''}>
                        <Link href="/" legacyBehavior>
                          <a>Homepage 1</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/homepage-2' ? 'active' : ''}>
                        <Link href="/homepage-2" legacyBehavior>
                          <a>Homepage 2</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/homepage-3' ? 'active' : ''}>
                        <Link href="/homepage-3" legacyBehavior>
                          <a>Homepage 3</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={`dropdown ${router.pathname.startsWith('/about') ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ABOUT <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/about' ? 'active' : ''}>
                        <Link href="/about" legacyBehavior>
                          <a>Our Company</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/about/history' ? 'active' : ''}>
                        <Link href="/about/history" legacyBehavior>
                          <a>Company History</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={`dropdown ${router.pathname.startsWith('/services') ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SERVICES <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/services' ? 'active' : ''}>
                        <Link href="/services" legacyBehavior>
                          <a>Financial Analysis</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/services/detail' ? 'active' : ''}>
                        <Link href="/services/detail" legacyBehavior>
                          <a>Services Detail</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={`dropdown ${router.pathname.startsWith('/projects') ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PROJECTS <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/projects' ? 'active' : ''}>
                        <Link href="/projects" legacyBehavior>
                          <a>Grid Layout</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/projects/single' ? 'active' : ''}>
                        <Link href="/projects/single" legacyBehavior>
                          <a>Single Project</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={`dropdown ${router.pathname.startsWith('/news') ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">NEWS <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/news' ? 'active' : ''}>
                        <Link href="/news" legacyBehavior>
                          <a>Grid Bar</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/news/sidebar' ? 'active' : ''}>
                        <Link href="/news/sidebar" legacyBehavior>
                          <a>Sidebar</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/news/detail' ? 'active' : ''}>
                        <Link href="/news/detail" legacyBehavior>
                          <a>News Detail</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={`dropdown ${router.pathname.startsWith('/faq') || router.pathname.startsWith('/pricing') || router.pathname.startsWith('/404') ? 'active' : ''}`}>
                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PAGES <span className="caret"></span></a>
                    <ul className="dropdown-menu">
                      <li className={router.pathname === '/faq' ? 'active' : ''}>
                        <Link href="/faq" legacyBehavior>
                          <a>Faq</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/pricing' ? 'active' : ''}>
                        <Link href="/pricing" legacyBehavior>
                          <a>Pricing Table</a>
                        </Link>
                      </li>
                      <li className={router.pathname === '/404' ? 'active' : ''}>
                        <Link href="/404" legacyBehavior>
                          <a>404 Page</a>
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li className={router.pathname === '/contact' ? 'active' : ''}>
                    <Link href="/contact" legacyBehavior>
                      <a>CONTACT</a>
                    </Link>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {children}

      {/* FOOTER SECTION */}
      <div className="footer">
        {/* ... (footer content remains the same) ... */}
        <div className="f-info">
          <div className="container">
            <div className="row">
              <div className="col-sm-4 col-md-4">
                <div className="box-info">
                  <div className="box-info-icon">
                    <span className="fa fa-phone"></span>
                  </div>
                  <div className="box-info-body">
                    <p>Have a question? call us now</p>
                    <h4>+62 1234 567 8910</h4>
                  </div>
                </div>
              </div>
              <div className="col-sm-4 col-md-4">
                <div className="box-info">
                  <div className="box-info-icon">
                    <span className="fa fa-clock-o"></span>
                  </div>
                  <div className="box-info-body">
                    <p>We are open on</p>
                    <h4>Mon - Fri 08:00 - 20:00</h4>
                  </div>
                </div>
              </div>
              <div className="col-sm-4 col-md-4">
                <div className="box-info">
                  <div className="box-info-icon">
                    <span className="fa fa-phone"></span>
                  </div>
                  <div className="box-info-body">
                    <p>Need support? Drop us an email</p>
                    <h4><a href="mailto:info@finanzi.com" title="">info@finanzi.com</a></h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container">
          <div className="row">
            <div className="col-sm-3 col-md-3">
              <div className="footer-item">
                <Link href="/" className="logo-bottom" legacyBehavior>
                  <a>
                    <img src="/images/logo-light.png" alt="logo bottom" />
                  </a>
                </Link>
                <div className="spacer-30"></div>
                <p>99 S.t Jomblo Park <br />Pekanbaru 28292. Indonesia<br /><br />info@finanzi.com <br />+1 301-736-4321</p>
                <div className="footer-sosmed">
                  <a href="#" title=""><div className="item"><i className="fa fa-facebook"></i></div></a>
                  <a href="#" title=""><div className="item"><i className="fa fa-twitter"></i></div></a>
                  <a href="#" title=""><div className="item"><i className="fa fa-instagram"></i></div></a>
                  <a href="#" title=""><div className="item"><i className="fa fa-pinterest"></i></div></a>
                </div>
              </div>
            </div>
            <div className="col-sm-3 col-md-3">
              <div className="footer-item">
                <div className="footer-title">Recent Post</div>
                <ul className="recent-post">
                  <li><Link href="/news/post-1" title="" legacyBehavior><a>The Best in dolor sit amet consectetur adipisicing elit sed</a></Link><span className="date"><i className="fa fa-clock-o"></i> June 16, 2017</span></li>
                  <li><Link href="/news/post-2" title="" legacyBehavior><a>The Best in dolor sit amet consectetur adipisicing elit sed</a></Link><span className="date"><i className="fa fa-clock-o"></i> June 16, 2017</span></li>
                </ul>
              </div>
            </div>
            <div className="col-sm-3 col-md-3">
              <div className="footer-item">
                <div className="footer-title">PAGES</div>
                <ul className="list">
                  <li><Link href="/about" title="" legacyBehavior><a>About</a></Link></li>
                  <li><Link href="/projects" title="" legacyBehavior><a>Projects</a></Link></li>
                  <li><Link href="/pricing" title="" legacyBehavior><a>Pricing</a></Link></li>
                  <li><Link href="/news" title="" legacyBehavior><a>Blog</a></Link></li>
                  <li><Link href="/faq" title="" legacyBehavior><a>Faq</a></Link></li>
                  <li><Link href="/contact" title="" legacyBehavior><a>Contact</a></Link></li>
                </ul>
              </div>
            </div>
            <div className="col-sm-3 col-md-3">
              <div className="footer-item">
                <div className="footer-title">Subscribe</div>
                <p>Lit sed The Best in dolor sit amet consectetur adipisicing elit sedconsectetur adipisicing</p>
                <form action="#" className="footer-subscribe">
                  <input type="email" name="EMAIL" className="form-control" placeholder="enter your email" />
                  <input id="p_submit" type="submit" value="send" />
                  <label htmlFor="p_submit"><i className="fa fa-envelope"></i></label>
                  <p>Get latest updates and offers.</p>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div className="fcopy">
          <div className="container">
            <div className="row">
              <div className="col-sm-12 col-md-12">
                <p className="ftex">© 2017 Finanzi by Rudhi Sasmito - All Rights Reserved</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* JS VENDOR - These are interactive and should run after the main content is visible */}
      {/* (JQuery and Modernizr are now in _document.js) */}
      <Script src="/js/vendor/bootstrap.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/jquery.superslides.js" strategy="afterInteractive" />
      <Script src="/js/vendor/owl.carousel.js" strategy="afterInteractive" />
      <Script src="/js/vendor/bootstrap-dropdownhover.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/jquery.magnific-popup.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/isotope.pkgd.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/imagesloaded.pkgd.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/validator.min.js" strategy="afterInteractive" />
      <Script src="/js/vendor/form-scripts.js" strategy="afterInteractive" />
      <Script src="https://maps.google.com/maps/api/js?sensor=false&ver=4.1.5" strategy="afterInteractive" />
      <Script src="/js/script.js" strategy="afterInteractive" />

    </>
  );
};

export default Layout;