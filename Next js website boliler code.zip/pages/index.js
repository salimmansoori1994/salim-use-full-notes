import Layout from '../components/Layout';
import Script from 'next/script'; // Import Script component for external JS

const HomePage = () => {

  return (
    <Layout title="Realnet Technology - Home">
      {/* BANNER */}
      <div id="slides" className="section banner">
        <ul className="slides-container">
          <li>
            <img src="/images/hero-1.jpg" alt="" />
            <div className="overlay-bg"></div>
            <div className="container">
              <div className="wrap-caption center">
                <h2 className="caption-heading">
                  <span>Balance Your Best Interests</span>
                </h2>
                <p className="excerpt">Ipsum dolor sit amet consectetur adipisicing</p>
              </div>
            </div>
          </li>
          <li>
            <img src="/images/hero-2.jpg" alt="" />
            <div className="overlay-bg"></div>
            <div className="container">
              <div className="wrap-caption right">
                <h2 className="caption-heading">
                  <span>Helping You Make Smart Financial Choices</span>
                </h2>
                <p className="excerpt">remipsum dolor sit amet consectetur adipisicing</p>
              </div>
            </div>
          </li>
          <li>
            <img src="/images/hero-3.jpg" alt="" />
            <div className="overlay-bg"></div>
            <div className="container">
              <div className="wrap-caption center">
                <h2 className="caption-heading">
                  <span>Let’s Grow Together</span>
                </h2>
                <p className="excerpt">orem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod</p>
              </div>
            </div>
          </li>
        </ul>

        <nav className="slides-navigation">
          <div className="container">
            <a href="#" className="next">
              <i className="fa fa-chevron-right"></i>
            </a>
            <a href="#" className="prev">
              <i className="fa fa-chevron-left"></i>
            </a>
          </div>
        </nav>
      </div>

      {/* ABOUT */}
      <div className="section">
        <div className="container">
          <div className="row">
            <div className="col-sm-5 col-md-5">
              <img src="/images/businessman.png" alt="" className="img-responsive" />
            </div>
            <div className="col-sm-7 col-md-7">
              <h2 className="section-heading">ABOUT US</h2>
              <h2 className="jumbolead reset-section-heading">We have the experience with combine quality workmanship.</h2>
              <p>We provide a professional dignissim at cursus elefeind norma arcu. Pellentesque accumsan est in tempus etos ullamcorper sem quam suscipit lacus maecenas tortor. Suspendisse gravida ornare non mattis velit rutrum modest.</p>
              <div className="row">
                <div className="col-sm-6 col-md-6">
                  <ul className="checklist">
                    <li>Suspendisse gravida</li>
                    <li>Bullamcorper sem quam</li>
                    <li>Pellentesque accumsan</li>
                  </ul>
                </div>
                <div className="col-sm-6 col-md-6">
                  <ul className="checklist">
                    <li>Suspendisse gravida</li>
                    <li>Bullamcorper sem quam</li>
                    <li>Pellentesque accumsan</li>
                  </ul>
                </div>
              </div>
              <div className="spacer-30"></div>
              <div className="row">
                <div className="col-sm-4 col-md-4">
                  <div className="counter-1 color-2">
                    <div className="counter-number">1238</div>
                    <div className="counter-title">Satisfied Customers</div>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4">
                  <div className="counter-1 color-2">
                    <div className="counter-number">850</div>
                    <div className="counter-title">People Across</div>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4">
                  <div className="counter-1 color-2">
                    <div className="counter-number">10</div>
                    <div className="counter-title">Years Experience</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SERVICES */}
      <div className="section bg-grey">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 col-md-12">
              <h2 className="section-heading center">SERVICES</h2>
              <p className="subheading text-center">With over 15 years experience and real focus on customer satisfaction, you can rely on us for your next renovation, driveway sett or home repair. We provide a professional service for private and commercial customers.</p>
            </div>
            <div className="col-sm-12 col-md-12">
              <div className="row tabsection">
                <div className="col-sm-3 col-md-3">
                  <ul className="nav nav-pills nav-stacked">
                    <li className="active"><a href="#tab_a" data-toggle="pill">Financial Analysis</a></li>
                    <li><a href="#tab_b" data-toggle="pill">Business Solutions</a></li>
                    <li><a href="#tab_c" data-toggle="pill">Client Management</a></li>
                    <li><a href="#tab_d" data-toggle="pill">Online Consulting</a></li>
                    <li><a href="#tab_e" data-toggle="pill">Business Opportunities</a></li>
                    <li><a href="#tab_f" data-toggle="pill">IT Consulting</a></li>
                  </ul>
                </div>
                <div className="col-sm-9 col-md-9">
                  <div className="tab-content">
                    <div className="tab-pane active" id="tab_a">
                      <div className="media">
                        <img src="/images/why-image-1.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>Financial Analysis</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_b">
                      <div className="media">
                        <img src="/images/why-image-2.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>Business Solutions</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_c">
                      <div className="media">
                        <img src="/images/why-image-3.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>Client Management</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_d">
                      <div className="media">
                        <img src="/images/why-image-5.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>Online Consulting</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_e">
                      <div className="media">
                        <img src="/images/why-image-4.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>Business Opportunities</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_f">
                      <div className="media">
                        <img src="/images/why-image-6.jpg" className="img-responsive" alt="" />
                      </div>
                      <div className="body">
                        <h4>IT Consulting</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                        <a href="/services" className="readmore">read more <i className="fa fa-angle-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* PROJECTS */}
      <div className="section project">
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 col-md-12">
              <h2 className="section-heading center">PROJECTS</h2>
              <p className="subheading text-center">With over 15 years experience and real focus on customer satisfaction, you can rely on us for your next renovation, driveway sett or home repair. We provide a professional service for private and commercial customers.</p>
            </div>
          </div>

          <div className="row">
            <div className="col-sm-12 col-md-12">
              <div id="caro-4">
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 1"><img src="/images/portfolio-1.jpg" alt="" /></a>
                  </div>
                </div>
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 2"><img src="/images/portfolio-2.jpg" alt="" /></a>
                  </div>
                </div>
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 3"><img src="/images/portfolio-3.jpg" alt="" /></a>
                  </div>
                </div>
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 4"><img src="/images/portfolio-4.jpg" alt="" /></a>
                  </div>
                </div>
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 5"><img src="/images/portfolio-5.jpg" alt="" /></a>
                  </div>
                </div>
                <div className="item">
                  <div className="box-image-5">
                    <div className="info-box">
                      <h4 className="title">Posandu</h4>
                      <p> Business Services Consulting</p>
                    </div>
                    <a href="/projects" title="Portfolio 6"><img src="/images/portfolio-6.jpg" alt="" /></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="spacer-70"></div>
          <div className="row">
            <div className="col-sm-12 col-md-12">
              <div className="text-center">
                <h3>Interested in working with us?</h3>
                <p className="subheading">Let's Talk Now!</p>
                <a href="/contact" className="btn btn-primary">HIRE US NOW</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* APPOINTMENT */}
      <div className="section appointment bg-1">
        <div className="container">
          <div className="row">
            <div className="col-sm-3 col-md-3">
              <h2 className="section-heading light">Free Consultation</h2>
              <p className="font__color-white">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
            <div className="col-sm-9 col-md-8 col-md-offset-1">
              <form action="#" className="form-appointment" id="contactForm" data-toggle="validator" noValidate={true}>
                <div className="row">
                  <div className="col-sm-6 col-md-6">
                    <div className="form-group">
                      <input type="text" className="form-control" id="p_name" placeholder="Full Name..." required="" />
                      <div className="help-block with-errors"></div>
                    </div>
                  </div>
                  <div className="col-sm-6 col-md-6">
                    <div className="form-group">
                      <input type="email" className="form-control" id="p_email" placeholder="Enter Address..." required="" />
                      <div className="help-block with-errors"></div>
                    </div>
                  </div>
                </div>
                <div className="form-group">
                  <input type="text" className="form-control" id="p_subject" placeholder="Subject..." />
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <textarea id="p_message" className="form-control" rows="6" placeholder="Write message"></textarea>
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <div id="success"></div>
                  <button type="submit" className="btn btn-secondary">SUBMIT MESSAGE</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* PARTNER & OFFERS */}
      <div className="section section-border">
        <div className="container">
          <div className="row">
            <div className="col-sm-6 col-md-6">
              <h2 className="section-heading">CLIENTS / PARTNERS</h2>
              <div className="row partner-col-3">
                <div className="col-sm-4 col-md-4 border-bottom border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-1.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-bottom border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-2.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-bottom">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-3.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-bottom border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-4.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-bottom border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-5.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-bottom">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-6.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-1.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4 border-right">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-1.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
                <div className="col-sm-4 col-md-4">
                  <div className="client-img">
                    <a href="#"><img src="/images/partners-1.png" alt="" className="img-responsive" /></a>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-sm-6 col-md-6">
              <h2 className="section-heading">WHAT WE OFFER</h2>
              <div className="panel-group panel-faq" id="accordion" role="tablist" aria-multiselectable="true">
                <div className="panel panel-default active">
                  <div className="panel-heading" role="tab" id="heading1">
                    <h4 className="panel-title">
                      <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true" aria-controls="collapse1">
                        Income Tax Planning with respect to Individual assets
                      </a>
                    </h4>
                  </div>
                  <div id="collapse1" className="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading1" aria-expanded="true">
                    <div className="panel-body">
                      <p>Create and publilsh dynamic websites for desktop, tablet, and mobile devices that meet the latest web standards- without writing code. Design freely using familiar tools and hundreds of web fonts. easily add interactivity, including slide shows, forms, and more.</p>
                    </div>
                  </div>
                </div>
                <div className="panel panel-default">
                  <div className="panel-heading" role="tab" id="heading2">
                    <h4 className="panel-title">
                      <a className="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="false" aria-controls="collapse2">
                        accusantium dolore mque laud antium dolore mque
                      </a>
                    </h4>
                  </div>
                  <div id="collapse2" className="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2" aria-expanded="false">
                    <div className="panel-body">
                      <p>When you click "Buy" button you'll be directed to our web store "Themeforest". You can purchase our template there, and you will given permission to download our templates.</p>
                      <ul className="list-unstyled">
                        <li><i className="fa fa-check"></i> Ready for all devices.</li>
                        <li><i className="fa fa-check"></i> HTML template</li>
                        <li><i className="fa fa-check"></i> Made with Bootstrap Framework.</li>
                        <li><i className="fa fa-check"></i> Easy Costumizable.</li>
                        <li><i className="fa fa-check"></i> Affordable Price.</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="panel panel-default">
                  <div className="panel-heading" role="tab" id="heading3">
                    <h4 className="panel-title">
                      <a className="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
                        Financial Adds Value to Your life worth how to know ?
                      </a>
                    </h4>
                  </div>
                  <div id="collapse3" className="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3" aria-expanded="false">
                    <div className="panel-body">
                      <p>Unzip the file, locate muse file and double click the file and you will directly to adobe muse. Next step you can modifications our template, you can customize color, text, font, content, logo and image with your need using familiar tools on adobe muse without writing any code.</p>
                      <p>You can't re-distribute the Item as stock, in a tool or template, or with source files. You can't re-distribute or make available the Item as-is or with superficial modifications. These things are not allowed even if the re-distribution is for Free.</p>
                    </div>
                  </div>
                </div>
                <div className="panel panel-default">
                  <div className="panel-heading" role="tab" id="heading4">
                    <h4 className="panel-title">
                      <a className="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
                        Better Late Than Never
                      </a>
                    </h4>
                  </div>
                  <div id="collapse4" className="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4" aria-expanded="false">
                    <div className="panel-body">
                      <p>Open muse file, on the top bar adobe muse you will see text tool. click and add web font do you want. Over 100+ typekit web font ready to use.</p>
                      <p>You just need open "asset" bar on the right side adobe muse. Next right click on the image asset, then "Relink" image asset with your image fit. All image automatically change on tablet and phone too. it's fast and simple. we make your life easier.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* TESTIMONY */}
      <div className="section testimony bg-2-overlay">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 col-md-8 col-md-offset-2">
              <div id="owl-testimony">
                <div className="item">
                  <div className="testimonial-1">
                    <div className="media">
                      <img src="/images/testimony-thumb-2.jpg" alt="" className="img-circle" />
                    </div>
                    <div className="body">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor in eleifend blanditullam ut ligula et neque. Nulla interdum dapibus erat nec elementum. Simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor.</p>
                      <div className="title">Gael story</div>
                      <div className="subtitle">Designer @ Buka Kreasi & co.</div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-1">
                    <div className="media">
                      <img src="/images/testimony-thumb-3.jpg" alt="" className="img-circle" />
                    </div>
                    <div className="body">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor in eleifend blanditullam ut ligula et neque. Nulla interdum dapibus erat nec elementum. Simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor.</p>
                      <div className="title">Dedo</div>
                      <div className="subtitle">Designer @ Buka Kreasi & co.</div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-1">
                    <div className="media">
                      <img src="/images/testimony-thumb-4.jpg" alt="" className="img-circle" />
                    </div>
                    <div className="body">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor in eleifend blanditullam ut ligula et neque. Nulla interdum dapibus erat nec elementum. Simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor.</p>
                      <div className="title">Maggy</div>
                      <div className="subtitle">Designer @ Buka Kreasi & co.</div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-1">
                    <div className="media">
                      <img src="/images/testimony-thumb-5.jpg" alt="" className="img-circle" />
                    </div>
                    <div className="body">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor in eleifend blanditullam ut ligula et neque. Nulla interdum dapibus erat nec elementum. Simply dummy text of the printing and typesetting industry orem Ipsum has been. Mauris ornare tortor.</p>
                      <div className="company">Gaspol ltd</div>
                      <div className="title">Robert Lav</div>
                      <div className="subtitle">Designer @ Buka Kreasi & co.</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* BLOG */}
      <div className="section blog">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 col-md-12">
              <h2 className="section-heading center">RECENT NEWS</h2>
              <p className="subheading text-center">With over 15 years experience and real focus on customer satisfaction, you can rely on us for your next renovation, driveway sett or home repair. We provide a professional service for private and commercial customers.</p>
            </div>

            <div className="col-sm-6 col-md-3">
              <div className="box-news-1">
                <div className="media gbr">
                  <img src="/images/blog-1.jpg" alt="" className="img-responsive" />
                </div>
                <div className="body">
                  <div className="title"><a href="/news" title="">The Best in dolor sit amet consectetur adipisicing elit sed</a></div>
                  <div className="meta">
                    <span className="date"><i className="fa fa-clock-o"></i> Aug 24, 2017</span>
                    <span className="comments"><i className="fa fa-comment-o"></i> 0 Comments</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-sm-6 col-md-3">
              <div className="box-news-1">
                <div className="media gbr">
                  <img src="/images/blog-2.jpg" alt="" className="img-responsive" />
                </div>
                <div className="body">
                  <div className="title"><a href="/news" title="">The Best in dolor sit amet consectetur adipisicing elit sed</a></div>
                  <div className="meta">
                    <span className="date"><i className="fa fa-clock-o"></i> Aug 24, 2017</span>
                    <span className="comments"><i className="fa fa-comment-o"></i> 0 Comments</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-sm-6 col-md-3">
              <div className="box-news-1">
                <div className="media gbr">
                  <img src="/images/blog-3.jpg" alt="" className="img-responsive" />
                </div>
                <div className="body">
                  <div className="title"><a href="/news" title="">The Best in dolor sit amet consectetur adipisicing elit sed</a></div>
                  <div className="meta">
                    <span className="date"><i className="fa fa-clock-o"></i> Aug 24, 2017</span>
                    <span className="comments"><i className="fa fa-comment-o"></i> 0 Comments</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-sm-6 col-md-3">
              <div className="box-news-1">
                <div className="media gbr">
                  <img src="/images/blog-4.jpg" alt="" className="img-responsive" />
                </div>
                <div className="body">
                  <div className="title"><a href="/news" title="">The Best in dolor sit amet consectetur adipisicing elit sed</a></div>
                  <div className="meta">
                    <span className="date"><i className="fa fa-clock-o"></i> Aug 24, 2017</span>
                    <span className="comments"><i className="fa fa-comment-o"></i> 0 Comments</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="section cta section-no-padding">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 col-md-12">
              <div className="cta-1">
                <div className="body-text color_white ">
                  <h3>Don't hesitate to contact us any time.</h3>
                </div>
                <div className="body-action">
                  <a href="/contact" className="btn btn-secondary">GET A QUOTE</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;