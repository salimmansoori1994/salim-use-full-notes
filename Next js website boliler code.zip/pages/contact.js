import Layout from '../components/Layout';

const ContactPage = () => {
  return (
    <Layout title="Realnet Technology - Contact Us">
      <div className="section">
        <div className="container">
          <h2 className="section-heading center">Contact Realnet Technology</h2>
          <p className="subheading text-center">
            We'd love to hear from you! Reach out to us through the form below or using our contact details.
          </p>
          <div className="spacer-30"></div>
          <div className="row">
            <div className="col-md-6">
              <h3 className="section-heading">Get in Touch</h3>
              <form action="#" className="form-appointment" id="contactForm" data-toggle="validator" noValidate={true}>
                <div className="form-group">
                  <input type="text" className="form-control" id="contact_name" placeholder="Your Name..." required="" />
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <input type="email" className="form-control" id="contact_email" placeholder="Your Email..." required="" />
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <input type="text" className="form-control" id="contact_subject" placeholder="Subject..." />
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <textarea id="contact_message" className="form-control" rows="6" placeholder="Your Message"></textarea>
                  <div className="help-block with-errors"></div>
                </div>
                <div className="form-group">
                  <div id="success"></div>
                  <button type="submit" className="btn btn-primary">SEND MESSAGE</button>
                </div>
              </form>
            </div>
            <div className="col-md-6">
              <h3 className="section-heading">Our Information</h3>
              <ul className="list-info">
                <li><span className="fa fa-map-marker"></span> 99 S.t Jomblo Park, Pekanbaru 28292. Indonesia</li>
                <li><span className="fa fa-phone"></span> +62 1234 567 8910</li>
                <li><span className="fa fa-envelope"></span> <a href="mailto:info@finanzi.com">info@finanzi.com</a></li>
                <li><span className="fa fa-clock-o"></span> Mon - Fri: 08:00 - 20:00</li>
              </ul>
              <div className="spacer-30"></div>
              {/* This is a placeholder for a map or other contact elements */}
              <div className="map-placeholder" style={{ height: '300px', backgroundColor: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#888' }}>
                Map / Location placeholder
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ContactPage;