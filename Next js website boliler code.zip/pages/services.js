import Layout from '../components/Layout';

const ServicesPage = () => {
  return (
    <Layout title="Realnet Technology - Our Services">
      <div className="section">
        <div className="container">
          <h2 className="section-heading center">Our Services</h2>
          <p className="subheading text-center">
            Explore the comprehensive range of services offered by Realnet Technology. We provide tailored solutions to meet your business needs.
          </p>
          <div className="spacer-30"></div>
          <div className="row">
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-area-chart"></i>
                </div>
                <div className="body">
                  <h4>Financial Analysis</h4>
                  <p>In-depth analysis of financial data to help you make informed decisions for growth and stability.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-briefcase"></i>
                </div>
                <div className="body">
                  <h4>Business Solutions</h4>
                  <p>Strategic solutions designed to optimize your business operations and enhance overall efficiency.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-users"></i>
                </div>
                <div className="body">
                  <h4>Client Management</h4>
                  <p>Effective strategies for building and maintaining strong client relationships, ensuring satisfaction.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-comments"></i>
                </div>
                <div className="body">
                  <h4>Online Consulting</h4>
                  <p>Expert advice and guidance provided remotely to address your specific business challenges.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-lightbulb-o"></i>
                </div>
                <div className="body">
                  <h4>Business Opportunities</h4>
                  <p>Identifying and capitalizing on new market trends and growth opportunities for your business.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-sm-6">
              <div className="box-icon-1">
                <div className="icon">
                  <i className="fa fa-laptop"></i>
                </div>
                <div className="body">
                  <h4>IT Consulting</h4>
                  <p>Specialized IT consulting services to help you leverage technology for competitive advantage.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ServicesPage;