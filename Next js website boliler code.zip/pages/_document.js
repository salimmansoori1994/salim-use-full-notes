// pages/_document.js
import Document, { Html, Head, Main, NextScript } from 'next/document';

class MyDocument extends Document {
  render() {
    return (
      <Html>
        <Head>
          {/* महत्वपूर्ण, ग्लोबल स्क्रिप्ट्स यहां जोड़ें। jQuery बहुत पहले चाहिए। */}
          {/* Modernizr भी यहां जा सकता है यदि यह वास्तव में ग्लोबल है और इंटरैक्टिव से पहले चाहिए */}
          <script src="/js/vendor/modernizr.min.js"></script>
          <script src="/js/vendor/jquery.min.js"></script>
          {/* ध्यान दें: यहां next/script कंपोनेंट का उपयोग नहीं किया गया है, यह एक मानक HTML script टैग है */}
        </Head>
        <body>
          <Main />
          <NextScript /> {/* यह अन्य next/script कंपोनेंट्स और Next.js के अपने JS को संभालता है */}
        </body>
      </Html>
    );
  }
}

export default MyDocument;