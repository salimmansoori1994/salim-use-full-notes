import Layout from '../components/Layout';

const ProjectsPage = () => {
  return (
    <Layout title="Realnet Technology - Our Projects">
      <div className="section">
        <div className="container">
          <h2 className="section-heading center">Our Recent Projects</h2>
          <p className="subheading text-center">
            Discover some of the successful projects Realnet Technology has completed for clients across various industries.
          </p>
          <div className="spacer-30"></div>
          <div className="row">
            {/* Project Item 1 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Alpha</h4>
                  <p>Web Development & Design</p>
                </div>
                <img src="/images/portfolio-1.jpg" alt="Project Alpha" className="img-responsive" />
              </div>
            </div>
            {/* Project Item 2 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Beta</h4>
                  <p>Mobile App Solutions</p>
                </div>
                <img src="/images/portfolio-2.jpg" alt="Project Beta" className="img-responsive" />
              </div>
            </div>
            {/* Project Item 3 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Gamma</h4>
                  <p>IT Infrastructure Setup</p>
                </div>
                <img src="/images/portfolio-3.jpg" alt="Project Gamma" className="img-responsive" />
              </div>
            </div>
            {/* Project Item 4 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Delta</h4>
                  <p>Cloud Integration</p>
                </div>
                <img src="/images/portfolio-4.jpg" alt="Project Delta" className="img-responsive" />
              </div>
            </div>
            {/* Project Item 5 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Epsilon</h4>
                  <p>Data Analytics</p>
                </div>
                <img src="/images/portfolio-5.jpg" alt="Project Epsilon" className="img-responsive" />
              </div>
            </div>
            {/* Project Item 6 */}
            <div className="col-md-4 col-sm-6">
              <div className="box-image-5">
                <div className="info-box">
                  <h4 className="title">Project Zeta</h4>
                  <p>Cybersecurity Solutions</p>
                </div>
                <img src="/images/portfolio-6.jpg" alt="Project Zeta" className="img-responsive" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProjectsPage;