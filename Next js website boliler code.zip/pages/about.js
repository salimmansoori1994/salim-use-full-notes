import Layout from '../components/Layout';

const AboutPage = () => {
  return (
    <Layout title="Realnet Technology - About Us">
      <div className="section">
        <div className="container">
          <h2 className="section-heading center">About Realnet Technology</h2>
          <p className="subheading text-center">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
          </p>
          <div className="spacer-30"></div>
          <p>
            This is the About Us page for Realnet Technology. Here you can provide detailed information about your company's history, mission, vision, values, and team. You can also include information about your partners and how you collaborate to deliver exceptional services.
          </p>
          <p>
            We are dedicated to providing innovative solutions and building strong relationships with our clients. Our team of experts is committed to excellence and strives to exceed expectations in every project.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default AboutPage;