import '../public/css/vendor/bootstrap.min.css';
import '../public/css/vendor/font-awesome.min.css';
import '../public/css/vendor/owl.carousel.min.css';
import '../public/css/vendor/owl.theme.default.min.css';
import '../public/css/vendor/magnific-popup.css';
import '../public/css/vendor/animate.min.css';
import '../public/css/vendor/bootstrap-dropdownhover.min.css';
import '../public/css/style.css'; // Your main style.css


function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}

export default MyApp;