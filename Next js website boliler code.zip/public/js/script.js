// public/js/script.js

"use strict"; // इसे फ़ाइल के शीर्ष पर रखें

// थीम के सभी आरंभिकरण को एक वैश्विक फ़ंक्शन में लपेटें
window.initThemeScripts = function() {
    // LOADER को छोड़कर सभी मौजूदा कोड यहां ले आएं,
    // क्योंकि लोडर को अक्सर केवल प्रारंभिक पेज लोड पर ही चलना चाहिए,
    // या Next.js राउटर इवेंट्स द्वारा नियंत्रित किया जाना चाहिए।

    /* =================================
    NAVBAR
    =================================== */
    // यह स्क्रोल-आधारित है, इसलिए इसे प्रत्येक नेविगेशन पर पुन: असाइन करने की आवश्यकता नहीं है,
    // लेकिन यदि क्लास जोड़ने/हटाने में कोई समस्या आती है, तो इसे फिर से चलाने से मदद मिल सकती है।
    // इसे सीधे useEffect में हैंडल करना बेहतर हो सकता है, लेकिन अभी के लिए इसे यहीं रखते हैं।
    var top = jQuery(document).scrollTop();
    var batas = 200;
    var navbar = jQuery('.navbar-main');

    // इस स्क्रॉल इवेंट हैंडलर को केवल एक बार अटैच करना सुनिश्चित करें।
    // मल्टीपल अटैचमेंट से बचने के लिए, आप पहले इसे 'off' कर सकते हैं, फिर 'on' कर सकते हैं।
    jQuery(window).off('scroll').on('scroll', function () {
        top = jQuery(document).scrollTop();
        if ( top > batas ) {
            navbar.addClass('stiky');
        }else {
            navbar.removeClass('stiky');
        }
    });
    // प्रारंभिक स्थिति सेट करें
    if (top > batas) {
        navbar.addClass('stiky');
    } else {
        navbar.removeClass('stiky');
    }


    /* =================================
    BANNER ROTATOR IMAGE
    =================================== */
    // Superslides को केवल तभी आरंभ करें जब तत्व मौजूद हो
    if ($.fn.superslides && $('#slides').length) {
        $('#slides').superslides({
            //animation: "fade",
            play: 5000,
            slide_speed: 800,
            pagination: true,
            hashchange: false,
            scrollable: true,
        });
    }

    /* =================================
    BACK TO TOP
    =================================== */
    // यह स्क्रोल इवेंट भी, इसे केवल एक बार अटैच करना सुनिश्चित करें।
    var offset = 300,
        offset_opacity = 1200,
        scroll_top_duration = 700,
        $back_to_top = $('.cd-top');

    // पहले से मौजूद स्क्रॉल हैंडलर को हटा दें और फिर से जोड़ें
    $(window).off('scroll.cdtop').on('scroll.cdtop', function(){ // एक namespace 'cdtop' का उपयोग करें
        ( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
        if( $(this).scrollTop() > offset_opacity ) {
            $back_to_top.addClass('cd-fade-out');
        }
    });

    // क्लिक हैंडलर को भी केवल एक बार अटैच करें
    $back_to_top.off('click').on('click', function(event){
        event.preventDefault();
        $('body,html').animate({
            scrollTop: 0 ,
            }, scroll_top_duration
        );
    });

    /* =================================
    OWL CAROUSEL
    =================================== */
    // Owl Carousel को केवल तभी आरंभ करें जब तत्व मौजूद हो
    var caro = $("#caro");
    if ($.fn.owlCarousel && caro.length) {
        caro.owlCarousel({
            items: 1,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            loop: true,
        });
    }

    var caro2 = $("#caro-2");
    if ($.fn.owlCarousel && caro2.length) {
        caro2.owlCarousel({
            autoplay: true,
            margin: 30,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            dots: true,
            loop: true,
            nav: true,
            navText: ["<span class='fa fa-chevron-left'></span>", "<span class='fa fa-chevron-right'></span>"],
            items : 2,
        });
    }

    var caro3 = $("#caro-3");
    if ($.fn.owlCarousel && caro3.length) {
        caro3.owlCarousel({
            autoplay: true,
            margin: 30,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            items : 3,
            dots: true,
            loop: true,
            responsive:{
                0:{
                    items:1
                },
                768:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
    }

    var caro4 = $("#caro-4");
    if ($.fn.owlCarousel && caro4.length) {
        caro4.owlCarousel({
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            items : 4,
            dots: true,
            loop: true,
            responsive:{
                0:{
                    items:1
                },
                768:{
                    items:2
                },
                1000:{
                    items:4
                }
            }
        });
    }

    var testimony = $("#owl-testimony");
    if ($.fn.owlCarousel && testimony.length) {
        testimony.owlCarousel({
            items: 1,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            loop: true,
            nav: true,
            navText: ["<span class='fa fa-chevron-left'></span>", "<span class='fa fa-chevron-right'></span>"],
            dots: false,
        });
    }


    /* =================================
    ISOTOPE
    =================================== */
    var $grid = $('.grid');
    if ($.fn.isotope && $grid.length) {
        // सुनिश्चित करें कि Isotope को केवल एक बार आरंभ किया गया है, या इसे नष्ट करके पुन: आरंभ करें
        // यदि पहले से आरंभ किया गया है तो इसे नष्ट करें
        if ($grid.data('isotope')) {
             $grid.isotope('destroy');
        }
        $grid.isotope({
            itemSelector: '.grid-item',
            isFitWidth: true,
            masonry: {
                columnWidth: '.grid-sizer'
            }
        });

        // imagesLoaded() को Isotope आरंभ होने के बाद चलाएं
        $grid.imagesLoaded().progress( function() {
            $grid.isotope('layout');
        });
    }


    /* =================================
    FAQ
    =================================== */
    // बूटस्ट्रैप कोलैप्स इवेंट्स को अटैच करें
    $(".panel").off("show.bs.collapse hide.bs.collapse").on("show.bs.collapse hide.bs.collapse", function(e) {
        if (e.type=='show'){
          $(this).addClass('active');
        }else{
          $(this).removeClass('active');
        }
    });

    /* =================================
    MAGNIFIC POPUP
    =================================== */
    if ($.fn.magnificPopup) {
        $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
          disableOn: 700,
          type: 'iframe',
          mainClass: 'mfp-fade',
          removalDelay: 160,
          preloader: false,
          fixedContentPos: false
        });

        $('.gallery-1, .gallery-2').magnificPopup({
            delegate: 'a',
            type: 'image',
            tLoading: 'Loading image #%curr%...',
            mainClass: 'mfp-img-mobile',
            gallery: {
                enabled: true,
                navigateByImgClick: true,
                preload: [0,1] // Will preload 0 - before current, and 1 after the current image
            },
            image: {
                tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
                titleSrc: function(item) {
                    return item.el.attr('title') + '';
                }
            }
        });
    }

    /* =================================
    GOOGLE MAPS
    =================================== */
    // Google Maps को तभी आरंभ करें जब तत्व और Google Maps API दोनों उपलब्ध हों।
    // Google Maps API को script src="https://maps.google.com/maps/api/js?sensor=false&ver=4.1.5"
    // से लोड करने के कारण 'google' ऑब्जेक्ट हमेशा तुरंत उपलब्ध नहीं हो सकता है।
    // एक बेहतर तरीका है कि Google Maps API को `script.js` से अलग लोड करें
    // और सुनिश्चित करें कि `google` ऑब्जेक्ट उपलब्ध है।

    // यहाँ एक सामान्य समाधान है, लेकिन अगर समस्या बनी रहती है,
    // तो Google Maps API लोडिंग रणनीति को फिर से देखना पड़ सकता है।
    if (typeof google !== 'undefined' && typeof google.maps !== 'undefined' && $('#maps').length) {
        function CustomZoomControl(controlDiv, map) {
            var controlUIzoomIn= document.getElementById('cd-zoom-in'),
                controlUIzoomOut= document.getElementById('cd-zoom-out');
            if(controlUIzoomIn) controlDiv.appendChild(controlUIzoomIn);
            if(controlUIzoomOut) controlDiv.appendChild(controlUIzoomOut);

            google.maps.event.addDomListener(controlUIzoomIn, 'click', function() {
                map.setZoom(map.getZoom()+1)
            });
            google.maps.event.addDomListener(controlUIzoomOut, 'click', function() {
                map.setZoom(map.getZoom()-1)
            });
        }

        var myLat = $('#maps').data('lat'),
        myLng = $('#maps').data('lng'),
        myMarkerx = $('#maps').data('marker');


        var latitude = myLat,
            longitude = myLng,
            markerx = myMarkerx,
            map_zoom = 14;

        var is_internetExplorer11= navigator.userAgent.toLowerCase().indexOf('trident') > -1;
        var marker_url = ( is_internetExplorer11 ) ? markerx : markerx;

        var main_color = '#000000',
            saturation_value= -80,
            brightness_value= 5;

        var style= [
            { elementType: "labels", stylers: [{saturation: saturation_value}] },
            { featureType: "poi", elementType: "labels", stylers: [{visibility: "off"}] },
            { featureType: 'road.highway', elementType: 'labels', stylers: [{visibility: "off"}] },
            { featureType: "road.local", elementType: "labels.icon", stylers: [{visibility: "off"}] },
            { featureType: "road.arterial", elementType: "labels.icon", stylers: [{visibility: "off"}] },
            { featureType: "road", elementType: "geometry.stroke", stylers: [{visibility: "off"}] },
            { featureType: "transit", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "poi", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "poi.government", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "poi.sport_complex", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "poi.attraction", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "poi.business", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "transit", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "transit.station", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "landscape", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "road", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "road.highway", elementType: "geometry.fill", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] },
            { featureType: "water", elementType: "geometry", stylers: [{ hue: main_color }, { visibility: "on" }, { lightness: brightness_value }, { saturation: saturation_value }] }
        ];

        var map_options = {
            center: new google.maps.LatLng(latitude, longitude),
            zoom: map_zoom,
            panControl: false,
            zoomControl: false,
            mapTypeControl: false,
            streetViewControl: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            scrollwheel: false,
            styles: style,
        }
        var map = new google.maps.Map(document.getElementById('maps'), map_options);
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(latitude, longitude),
            map: map,
            visible: true,
            icon: marker_url,
        });

        var zoomControlDiv = document.createElement('div');
        var zoomControl = new CustomZoomControl(zoomControlDiv, map);

        map.controls[google.maps.ControlPosition.LEFT_TOP].push(zoomControlDiv);
    }
};

// पेज के प्रारंभिक लोड पर इस फ़ंक्शन को चलाएं
$(document).ready(function(){
    // LOADER को यहां रखें ताकि यह केवल प्रारंभिक पेज लोड पर ही चले
    $(".loader").delay(400).fadeOut();
    $(".animationload").delay(400).fadeOut("fast");

    window.initThemeScripts(); // यह सुनिश्चित करेगा कि पारंपरिक डॉक्यूमेंट रेडी पर इनिशियलाइज़ेशन होता है।
});